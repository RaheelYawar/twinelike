import eslint from '@eslint/js'
import tslint from 'typescript-eslint'
import stylistic from '@stylistic/eslint-plugin'
import globals from "globals"

const config = tslint.config(
	eslint.configs.recommended,
	...tslint.configs.recommended,
	/*
		TS folder linting
	*/
	{
		plugins: {
			'@typescript-eslint': tslint.plugin,
			'@stylistic': stylistic,
		},
		languageOptions: {
			globals: {
                ...globals.browser,
				StoryFormat: "readonly",
				CodeMirror: "readonly",
				_: "readonly",
			},
			parserOptions: {
				"project": ["./tsconfig.json", "./ts/markup/codemirror/tsconfig.json"]
			}
		},
		files: [ "ts/**" ],
		ignores: [ "**/*.js", "**/*.d.ts" ],
		rules:  {
			"@stylistic/arrow-parens": [ "warn", "as-needed", ],
			"@stylistic/dot-location": ["warn", "property"],
			"@stylistic/linebreak-style": [ "warn", "unix", ],
			"@stylistic/member-delimiter-style": ["warn", {
					"multiline": {
						"delimiter": "none"
					},
					"singleline": {
						"delimiter": "comma",
						"requireLast": false
					},
					"multilineDetection": "brackets"
				}
			],
			"@stylistic/no-extra-parens": [ "warn", "all", {
					"ternaryOperandBinaryExpressions": false,
					"enforceForArrowConditionals": false,
					"enforceForSequenceExpressions": false,
					"nestedBinaryExpressions": false,
					"returnAssign": false,
					"conditionalAssign": false
				}
			],
			"@stylistic/no-mixed-spaces-and-tabs": "warn",
			"@stylistic/no-multiple-empty-lines": [ "warn", { "max": 1 } ],
			"@stylistic/no-tabs": [ "warn", { "allowIndentationTabs": true } ],
			"@stylistic/no-trailing-spaces": [ "warn", { "skipBlankLines": true, "ignoreComments": true } ],
			"@stylistic/no-whitespace-before-property": "warn",
			"@stylistic/quote-props": [ "warn", "as-needed", ],
			"@stylistic/quotes": [ "warn", "backtick", ],
			"@stylistic/rest-spread-spacing": "warn",
			"@stylistic/semi": [ "warn", "never",
				{ "beforeStatementContinuationChars": "always" }
			],
			"@stylistic/semi-style": ["warn", "first"],
			"@stylistic/template-curly-spacing": [ "warn", "never", ],
			"@typescript-eslint/ban-types": "error",
			"@typescript-eslint/consistent-generic-constructors": [ "warn", "constructor", ],
			"@typescript-eslint/consistent-indexed-object-style": [ "warn", "record", ],
			"@typescript-eslint/consistent-type-definitions": [ "warn", "type", ],
			"@typescript-eslint/no-explicit-any": [ "error",
				{ "ignoreRestArgs": true }
			],
			"@typescript-eslint/no-extraneous-class": [ "warn" ],
			"@typescript-eslint/no-this-alias": 0,
			"@typescript-eslint/no-unnecessary-type-assertion": "warn",
			"@typescript-eslint/no-unused-vars": "warn",
			"@typescript-eslint/no-use-before-define": [ "error", {
					"functions": false,
					"classes": false
				}
			],
			"@typescript-eslint/prefer-string-starts-ends-with": [ "warn" ],
			"@typescript-eslint/prefer-readonly": [ "warn" ],
			//"@typescript-eslint/prefer-nullish-coalescing": [ "warn" ],
			"@typescript-eslint/prefer-optional-chain": [ "warn" ],
			"@typescript-eslint/prefer-reduce-type-parameter": [ "warn" ],
			"@typescript-eslint/prefer-return-this-type": [ "warn" ],
			"default-case-last": "warn",
			"dot-notation": "warn",
			"eqeqeq": "error",
			"grouped-accessor-pairs": "warn",
			"logical-assignment-operators": "warn",
			"no-array-constructor": "warn",
			"no-await-in-loop": "warn",
			"no-caller": "error",
			"no-constant-binary-expression": "error",
			"no-constructor-return": "warn",
			"no-debugger": 0,
			"no-else-return": "warn",
			"no-empty": [ "warn",
				{ "allowEmptyCatch": true }
			],
			"no-extra-bind": "warn",
			"no-extra-semi": "warn",
			"no-fallthrough": [ "error",
				{ "allowEmptyCase": true }
			],
			"no-irregular-whitespace": [ "error", {
					"skipComments": true,
					"skipStrings": true,
					"skipTemplates": true
				}
			],
			"no-lone-blocks": "warn",
			"no-lonely-if": "warn",
			"no-new": "warn",
			"no-new-native-nonconstructor": "warn",
			"no-prototype-builtins": 0,
			"no-self-compare": "warn",
			"no-template-curly-in-string": "warn",
			"no-undef-init": "warn",
			"no-unexpected-multiline": 0, // Use semi-style instead.
			"no-unreachable-loop": "warn",
			"no-unused-expressions": [ "error", {
					"allowShortCircuit": true,
					"allowTernary": true
				}
			],
			"no-unused-private-class-members": "warn",
			"no-useless-computed-key": "warn",
			"no-var": "warn",
			"object-shorthand": [ "warn", "always", ],
			"operator-assignment": "warn",
			"prefer-arrow-callback": [ "warn", {
				"allowNamedFunctions": true
				}
			],
			"prefer-const": 0, // Use let for brevity.
			"prefer-exponentiation-operator": "warn",
			"prefer-numeric-literals": "warn",
			"prefer-object-has-own": "warn",
			"prefer-object-spread": "warn",
			"prefer-regex-literals": "warn",
			"prefer-rest-params": 0, // This could have runtime performance issues.
			"prefer-template": "warn",
			"require-atomic-updates": "error",
			"space-before-blocks": "warn",
			"strict": [ "error", "global", ],
			"wrap-iife": [ "error", "any", ]
		}
	},
	/*
		Test folder linting
	*/
	{
		files: ["test/**"],
		plugins: {
			'@stylistic': stylistic,
		},
		languageOptions: {
			sourceType: "script",
			globals: {
                ...globals.browser,
				"$": "readonly",
				"jQuery": "readonly",
				// Jasmine features
				"describe": "readonly",
				"expect": "readonly",
				"it": "readonly",
				"xit": "readonly",
				"spyOn": "readonly",
				"afterEach": "readonly",
				"afterAll": "readonly",
				"beforeEach": "readonly",
				"beforeAll": "readonly",
				// Harlowe functionality exposed to tests by test_suite.html
				"Engine": "readonly",
				"Passages": "readonly",
				"Utils": "readonly",
				"deserialiseState": "readonly",
				"clearState": "readonly",
				"loadAssets": "readonly",
				// test_suite.html functions
				"createPassage": "readonly",
				"deletePassage": "readonly",
				"runPassage": "readonly",
				"goToPassage": "readonly",
				"waitForGoto": "readonly",
			}
		},
		rules: {
			"@typescript-eslint/no-unused-vars": "warn",
			"linebreak-style": 2,
			"new-cap": 0,
			"no-irregular-whitespace": ["error", { "skipStrings": true }],
			"strict": [
			  2,
			  "function"
			],
			"no-useless-escape": "warn",
			"no-var": "warn",
			"no-lonely-if": "warn",
			"object-shorthand": [
			  "warn",
			  "always"
			],
			"prefer-arrow-callback": ["warn", {
			  "allowNamedFunctions": true
			}],
			"prefer-exponentiation-operator": "warn",
			"prefer-numeric-literals": "warn",
			"prefer-object-spread": "warn",
			"prefer-object-has-own": "warn",
			"prefer-regex-literals": "warn",
			"prefer-template": "warn",
			"dot-notation": "warn",
			"no-extra-bind": "warn",
			"no-lone-blocks": "warn",
			"no-array-constructor": "warn",
			"no-extra-semi": "warn",
			"@stylistic/semi": ["warn", "never", { "beforeStatementContinuationChars": "always"}],
			"@stylistic/no-tabs": [
			  "warn",
			  { "allowIndentationTabs": true }
			],
			"@stylistic/no-trailing-spaces": [
			  "warn",
			  { "skipBlankLines": true, "ignoreComments": true }
			],
			"@stylistic/no-whitespace-before-property": "warn",
			"@stylistic/rest-spread-spacing": "warn",
			"logical-assignment-operators": "warn",
			"no-undef-init": "warn",
			"no-useless-computed-key": "warn",
			"quotes": ["warn", "backtick"],
			"no-unused-expressions": [
				"error",
				{
					"allowShortCircuit": true, 
					"allowTernary": true
				}
			]
		}
	}
);
export default config