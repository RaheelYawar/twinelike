import { ConditionalExcept } from "type-fest"
import { JQueryCSSParameter } from "./datatypes.js"
import $ from "jquery"

const
	{fromCharCode} = String,
	// These two are used by childrenProbablyInline (see below).
	usuallyBlockElements = (
		// The most common block HTML tags that would be used in passage source.
		`audio,blockquote,canvas,div,h1,h2,h3,h4,h5,hr,ol,p,pre,table,ul,video,`
		// And the one(s) that Harlowe itself creates through its syntax.
		// <tw-consecutive-br> and <tw-dialog> are deliberately not included.
		+ `tw-align,tw-story,tw-passage,tw-sidebar,tw-columns,tw-column,tw-meter`
	).split(`,`),
	
	usuallyInlineElements = (
		// The most common inline HTML tags that would be created from passage source
		`a,b,i,em,strong,sup,sub,abbr,acronym,s,strike,del,big,small,script,img,button,input,`
		// And the ones that Harlowe itself creates through its syntax.
		// Note that <tw-hook> and <tw-expression> aren't included.
		+ `tw-link,tw-broken-link,tw-verbatim,tw-collapsed,tw-error,tw-colour,tw-icon`
	).split(`,`),

	// Certain HTML elements cannot have their parents unwrapped: <audio>, for instance,
	// will break if it is ever detached from the DOM.
	nonDetachableElements = [`audio`,],

	// These produce long RegExp strings of every lowercase/uppercase/caseSensitive character, defined as "any character in
	// the Basic Multilingual Plane which doesn't round-trip through toUpperCase/toLowerCase".
	// Note that this is computed based on the player's locale, which is coincidentally consistent with (uppercase:),
	// (lowercase:), and the 'uppercase' and 'lowercase' datatypes.
	[anyUppercase, anyLowercase, anyCasedLetter] = ([
		(e:number) => fromCharCode(e) !== fromCharCode(e).toLowerCase(),
		(e:number) => fromCharCode(e) !== fromCharCode(e).toUpperCase(),
		(e:number) => fromCharCode(e).toLowerCase() !== fromCharCode(e).toUpperCase(),
	] as const).map(filter => `[${Array.from(Array(0xDFFF)).map((_,i) => i)
		.filter(filter)
		.map((e,i,a) => (e === a[i-1]+1 && e === a[i+1]-1) ? `-` : fromCharCode(e)).join(``).replace(/-+/g, `-`)}]`)

/*
	Hard-coded default time for transitions, in milliseconds.
*/
function defaultTransitionTime(transIndex: string) {
	return transIndex === `instant` ? 0 : 800
}

/*
	Takes a string argument, expressed as a CSS time,
	and returns the time in milliseconds that it equals.

	If the string can't be parsed as a time, then this returns 0.
*/
function cssTimeUnit(s: string) {
	s = s.toLowerCase()

	if (s.endsWith(`ms`))
		return +s.slice(0, -2) || 0
	if (s.endsWith(`s`))
		return +s.slice(0, -1) * 1000 || 0
	return 0
}

/*
	A type for void functions.
*/
type StoryOptions = {
	// Set by its presence on <tw-storydata>
	debug?: boolean
	// Set to true or false by Debug Mode.
	evalReplay?: boolean
	// Set to true or false by Debug Mode.
	ignoreClickEvents?: boolean
	// Set to true or false by Debug Mode.
	ignoreGotos?: boolean
	// A num used to adjust the speed of `time`, (live:) and (after:) (but not transitions).
	speedMultiplier: number
	ifid: string

	uncompressedStructures?: boolean
	uncompressedPureValues?: boolean
}

let
	//A binding for the cached <tw-story> reference (see below).
	storyElement: JQuery,
	// Used for detaching and reattaching the storyElement.
	storyElementParent: JQuery,
	options = <StoryOptions>{
		speedMultiplier: 1,
	},
	/*
		An array of functions to run only after page load. This is set to null
		once page load has completed, causing onStartup() to just run the passed function
		immediately.
	*/
	startupCallbacks: VoidFunction[] | null = [],
	/*
		A map of held-down keyboard keys, and a count of how many keys are held down concurrently.
	*/
	keysHeld: Obj<boolean> = {},
	keysHeldCount = 0,
	/*
		And, the same for mouse buttons.
	*/
	buttonsHeld: Obj<boolean>  = {},
	buttonsHeldCount = 0,
	/*
		Finally, mouse coordinates.
	*/
	mouseCoords = {x:0,y:0}

/*
	A convenience function for transitionIn and transitionOut, which calls a function
	when a transition is complete, and also potentially accelerates the end
	of the transition if it can be skipped and an input is being held.
*/
function onTransitionComplete(el: JQuery, time: number, delay: number, transitionSkip: number, endFn: VoidFunction) {
	/*
		Each frame, reduce the duration, and potentially reduce it further if this
		transition can be skipped and an input is being held.
	*/
	let previousTimestamp = 0, elapsedVisibleTime = 0, duration = time + delay
	function animate(timestamp = 0) {
		if (el[0].compareDocumentPosition(document) & 1) {
			duration = 0
		}
		let delta
		if (previousTimestamp) {
			delta = timestamp - previousTimestamp
			duration -= delta
		}
		previousTimestamp = timestamp
		/*
			The test for whether a transition can be skipped is simply that any key is being held.
		*/
		if (transitionSkip > 0 && (keysHeldCount + buttonsHeldCount) > 0) {
			el.data(`expediteAnim`)(transitionSkip)
		}
		/*
			If the remaining duration exceeds the initial delay (that is, if it's currently eating into the "time" interval rather than
			the "delay" interval), remove the 'visibility:hidden' guard and start the animation
		*/
		if (duration <= time) {
			elapsedVisibleTime += delta || 0
			if (el.css(`animation-play-state`) === `paused`) {
				el.css({visibility:``, 'animation-play-state':`running`})
			}
		}
		if (duration <= 0) {
			el.removeData(`expediteAnim`)
			endFn()
		}
		else {
			requestAnimationFrame(animate)
		}
	}
	/*
		A method that allows the animation to be expedited by a certain amount of time, which is currently only required
		for cases when an animating parent has finished and is unwrapping.
	*/
	el.data(`expediteAnim`, (expedite: number) => {
		/*
			If no expedite time is given, assume the animation has been force-restarted by its parents being unwrapped.
			Thus, expedite it by its own elapsedVisibleTime.

		*/
		if (expedite === undefined) {
			expedite = elapsedVisibleTime
		}
		duration -= expedite
		if (el.css(`animation-play-state`) === `running`) {
			el.css(`animation-delay`, `${(cssTimeUnit(el.css(`animation-delay`)) || 0) - expedite}ms`)
		}
	})
	!duration ? animate() : requestAnimationFrame(animate)
}

const underscoresAndHyphens = /-|_/g,

/*
	Weak/fast string hashing function (used solely by valueRef computation in Runner and State).
	This is a trivially modified TinySimpleHash (public domain).
*/
	hash = (str:string) => {
		let h = 9
		for(let i = str.length; i > 0;) {
			i -= 1
			h = Math.imul(h ^ str.charCodeAt(i), 9**9)
		}
		return (h ^ h >>> 9) >>> 0
	},

	/*
		Returns an array of every permutation of the given sequence.
	*/
	permutations = <T>(...list: T[]) => {
		const {length} = list,
			result = [[...list]],
			c = Array(length).fill(0)
		let i = 1, k, p

		while (i < length) {
			if (c[i] < i) {
				k = i % 2 && c[i]
				p = list[i]
				list[i] = list[k]
				list[k] = p
				++c[i]
				i = 1
				result.push([...list])
			} else {
				c[i] = 0
				++i
			}
		}
		return result
	},

	/*
		A quick method for turning a number into an "nth" string.
	*/
	nth = (num:number) => {
		const numStr = `${+num}`
		return num + (
			numStr.endsWith(`1`) && (numStr.length === 1 || numStr[numStr.length-2] !== `1`) ? `st` :
			numStr.endsWith(`2`) && (numStr.length === 1 || numStr[numStr.length-2] !== `1`) ? `nd` :
			numStr.endsWith(`3`) && (numStr.length === 1 || numStr[numStr.length-2] !== `1`) ? `rd` : `th`)
	},

	/*
		A quick method for adding an 's' to the end of a string
		that comes in the form "[num] [noun]". Used exclusively for
		error messages.
	*/
	plural = (num:number, noun:string, plural = ``) => {
		return `${num} ${Math.abs(num) !== 1 ? plural ? plural : `${noun}s` : noun}`
	},

	/*
		A quick method for joining a string array with commas and "and".
	*/
	andList = (array: unknown[]) => {
		return array.length <= 1 ? array[0]
			: `${array.slice(0,-1).join(`, `)} and ${array.at(-1)}`
	},

	/*
		These two strings are modified copies of regex components from markup/patterns.js.
	*/
	// This includes all forms of Unicode 6 whitespace (including \n and \r) except Ogham space mark.
	realWhitespace = `[ \\n\\r\\f\\t\\v\\u00a0\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000]`,

	// This handles alphanumeric ranges not covered by \w. Doesn't include hyphens or underscores.
	anyRealLetter =  `[\\dA-Za-z\\u00c0-\\u00de\\u00df-\\u00ff\\u0150\\u0170\\u0151\\u0171\\uD800-\\uDFFF]`,

	anyNewline = `(?:\\n|\\r|\\r\\n)`,

	/*
		HTML utilities
	*/

	/*
		Unescape HTML entities.
	*/
	unescape = (text:string) => {
		return text.replace(/&(?:amp|lt|gt|quot|nbsp|zwnj|#39|#96);/g,
			e => ({
				'&amp;'  : `&`,
				'&gt;'   : `>`,
				'&lt;'   : `<`,
				'&quot;' : `"`,
				'&#39;'  : `'`,
				"&nbsp;" : String.fromCharCode(160),
				"&zwnj;" : String.fromCharCode(8204)
			}[e] || ``)
		)
	},

	/*
		HTML-escape a string.
	*/
	escape = (text:string) => {
		return text.replace(/[&><"']/g,
			e => ({
				'&' : `&amp;`,
				'>' : `&gt;`,
				'<' : `&lt;`,
				'"' : `&quot;`,
				"'" : `&#39;`,
			}[e] || ``)
		)
	},

	/*
		Some names (namely macro names) are case-insensitive, AND dash-insensitive.
		This method converts such names to all-lowercase and lacking
		underscores and hyphens.
	*/
	insensitiveName = (e:string) => {
		return `${e}`.toLowerCase().replace(underscoresAndHyphens, ``)
	},

	/*
		Input utilities
	*/

	/*
		Provides access to the keysHeld map, which tracks keyboard input.
	*/
	allKeysDown = (...keys: string[]) => keys.every(key => keysHeld[key]),
	someKeysDown = (...keys: string[]) => keys.some(key => keysHeld[key]),

	/*
		Provides access to the buttonsHeld map, which tracks button input.
	*/
	buttonsDown = (...buttons: string[]) => buttons.every(b => buttonsHeld[b]),

	anyInputDown = () => keysHeldCount + buttonsHeldCount > 0,

	/*
		Element utilities
	*/

	/*
		Determines the colours of an element (both colour and backgroundColour) by
		scanning all of its parent elements, ignoring transparency.
		Used only by command macros and style changer macros.
	*/
	parentColours = (elem: JQuery) => {
		const ret = { colour: <string|null>null, backgroundColour: <string|null>null }
		/*
			Browsers represent the colour "transparent" as either "transparent",
			hsla(n, n, n, 0) or rgba(n, n, n, 0).
		*/
		const transparent = /^\w+a\(.+?,\s*0\s*\)$|^transparent$/
		/*
			To correctly identify the colours of this element, iterate
			upward through all the elements containing it.
		*/
		for (; elem.length && (<JQuery<Element|Document>>elem)[0] !== document; elem = elem.parent()) {
			if (!ret.backgroundColour) {
				const colour = elem.css(`background-color`)
				if (!colour.match(transparent)) {
					ret.backgroundColour = colour
				}
			}
			if (!ret.colour) {
				const colour = elem.css(`color`)
				if (!colour.match(transparent)) {
					ret.colour = colour
				}
			}
			if (ret.colour && ret.backgroundColour) {
				return ret
			}
		}
		/*
			If there's no colour anywhere, assume this is a completely unstyled document.
		*/
		return { colour: `#fff`, backgroundColour: `#000` }
	},

	/*
		childrenProbablyInline: returns true if the matched elements probably only contain elements that
		are of the 'inline' or 'none' CSS display type.
		
		This takes some shortcuts to avoid use of the costly getComputedStyle() function as much as possible,
		hence, it can only "probably" say so.
		
		This is used to crudely determine whether to make a <tw-transition-container> inline or block,
		given that block children cannot inherit opacity from inline parents in Chrome (as of April 2015).

		Used only in style changer macros, and here.
	*/
	childrenProbablyInline = (jq: JQuery) => {
		/*
			This is used to store elements which daunted all of the easy tests,
			so that $css() can be run on them after the first loop has returned all-true.
		*/
		const unknown: Element[] = []
		for (const elem of jq.findAndFilter(`*`)) {
			/*
				If it actually has "style=display:inline", "hidden", or "style=display:none"
				as an inline attribute, well, that makes life easy for us.
			*/
			if (elem.hidden || /none|inline/.test(elem.style.display)
					|| /display: (none|inline)/.test(elem.getAttribute(`style`) || ``)) {
				continue
			}
			/*
				If the children contain an element which is usually block,
				then *assume* it is and return false early.
			*/
			if (usuallyBlockElements.includes(elem.tagName.toLowerCase())
					/*
						If it has an attribute style which is verifiably block (NOT none, inline, unset or inherit),
						then go ahead and return false.
					*/
					|| /display: (?!none|inline|inherit|unset)/.test(elem.getAttribute(`style`) || ``)) {
				return false
			}
			/*
				If the child's tag name is that of an element which is
				usually inline, then *assume* it is and return true early.
			*/
			if (usuallyInlineElements.includes(elem.tagName.toLowerCase())) {
				continue
			}
			/*
				For all else, we fall back to the slow case.
			*/
			unknown.push(elem)
		}
		return unknown.every(a => /inline|none/.test(window.getComputedStyle(a).display))
	},

	/*
		Transition an element out.
		Used only by Engine?
	*/
	transitionOut = (el: JQuery, transIndex: string, transitionTime?: number, transitionDelay = 0, transitionSkip = 0, expedite = 0, transitionOrigin?: string | (() => string) | JQueryCSSParameter) => {
		/*
			Quick early exit.
		*/
		if (el.length === 0) {
			return
		}
		// This can't be inlined into the call as a default, because it references transIndex.
		transitionTime ||= defaultTransitionTime(transIndex)

		/*
			If the element is not a tw-hook, tw-passage, tw-sidebar or tw-expression, we must
			wrap it in a temporary element first, which can thus be
			animated using CSS.
		*/
		const mustWrap = el.length > 1 || !childrenProbablyInline(el) || ![`tw-hook`,`tw-passage`,`tw-sidebar`,`tw-expression`].includes(el.tag())
		/*
			As mentioned above, we must, in some cases, wrap the nodes in containers.
		*/
		if (mustWrap) {
			el = el.wrapAll(`<tw-transition-container>`).parent()
		}
		/*
			Now, apply the transition.
			The transitionOrigin must be applied before the rest of the attributeds, as it may
			be a function.
		*/
		if (transitionOrigin) {
			if (typeof transitionOrigin === `string` || transitionOrigin instanceof Function) {
				el.css(`transform-origin`, transitionOrigin)
			}
			else {
				el.css(transitionOrigin)
			}
		}
		el.attr(`data-t8n`, transIndex).addClass(`transition-out`).css({
			'animation-duration': `${transitionTime}ms`,
			'animation-delay':   `${-expedite}ms`,
			'animation-play-state': `paused`,
		})

		/*
			To give newly-created sections time to render and apply changers, such as (box:) to hooks,
			this code, which gives the transition element the correct display property, is crudely placed in a delayed timeout.
		*/
		requestAnimationFrame(() => {
			/*
				Special case: due to <tw-backdrop> having display:flex, getComputedStyle() will always report 'display:block' for
				each child element of it, even if it's a <tw-dialog>. So, ignore childrenProbablyInline() and simply assume that block positioning mustn't be applied.
				Note that the other two elements that have display:flex, <tw-story> and <tw-columns>, don't have this concern due to their children
				being part of usuallyBlockElements.
			*/
			if (childrenProbablyInline(el)) {
				el.css(`display`,`inline`)
			}
			/*
				Special case: due to <tw-backdrop> and <tw-story> having display:flex, getComputedStyle() will always report 'display:block' for
				each child element of it, even though flex elements are positioned differently and don't need width:100%.
			*/
			else if (!el.parent().is(`tw-backdrop,tw-story`)) {
				/*
					Both of these are necessary for overriding "display:inline-block" for certain transitions,
					including those that use transform.
					setAttribute() must be used to add "!important".
				*/
				el[0].setAttribute(`style`, `${el[0].getAttribute(`style`)}display:block !important;width:100%`)
			}
		})
		onTransitionComplete(el, transitionTime, transitionDelay - expedite, transitionSkip, () => {
			/*
				As a transition-out, all that needs to be done at the end is remove the element.
			*/
			el.remove()
		})
	},

	/*
		Transition an element in.
		Used only by ChangeDescriptor.
	*/
	transitionIn = (el: JQuery, transIndex: string, transitionTime?: number, transitionDelay = 0, transitionSkip = 0, expedite = 0, transitionOrigin?: string | (() => string) | JQueryCSSParameter) => {
		/*
			Quick early exit.
		*/
		if (el.length === 0) {
			return
		}
		// This can't be inlined into the call as a default, because it references transIndex.
		transitionTime ||= defaultTransitionTime(transIndex)
		/*
			If the element is not a tw-hook, tw-passage, tw-sidebar or tw-expression, we must
			wrap it in a temporary element first, which can thus be
			animated using CSS.
		*/
		const mustWrap = el.length > 1 || !childrenProbablyInline(el) || ![`tw-hook`,`tw-passage`,`tw-sidebar`,`tw-expression`].includes(el.tag())
		/*
			As mentioned above, we must, in some cases, wrap the nodes in containers.
		*/
		if (mustWrap) {
			el = el.wrapAll(`<tw-transition-container>`).parent()
		}
		/*
			Now, apply the transition.
			The transitionOrigin must be applied before the rest of the attributes, as it may
			be a function.
		*/
		if (transitionOrigin) {
			if (typeof transitionOrigin === `string` || transitionOrigin instanceof Function) {
				el.css(`transform-origin`, transitionOrigin)
			}
			else {
				el.css(transitionOrigin)
			}
		}
		el.attr(`data-t8n`, transIndex).addClass(`transition-in`).css({
			'animation-duration': `${transitionTime}ms`,
			'animation-delay':    `${-expedite}ms`,
		/*
			For delayed animations, initially hide the transitioning element using visiblity:hidden and animation-play-state:paused.
			onTransitionComplete will then remove this at the correct time.
		*/
		...(transitionDelay - expedite) ? { visibility: `hidden`, 'animation-play-state': `paused` } : {}})

		/*
			To give newly-created sections time to render and apply changers, such as (box:) to hooks,
			this code, which gives the transition element the correct display property, is crudely placed in a delayed timeout.
		*/
		requestAnimationFrame(() => {
			if (childrenProbablyInline(el)) {
				el.css(`display`,`inline`)
			}
			/*
				Special case: due to <tw-backdrop> and <tw-story> having display:flex, getComputedStyle() will always report 'display:block' for
				each child element of it, even though flex elements are positioned differently and don't need width:100%.
			*/
			else if (!el.parent().is(`tw-backdrop,tw-story`)) {
				/*
					Both of these are necessary for overriding "display:inline-block" for certain transitions,
					including those that use transform.
					setAttribute() must be used to add "!important".
				*/
				el[0].setAttribute(`style`, `${el[0].getAttribute(`style`)}display:block !important;width:100%`)
			}
		})

		onTransitionComplete(el, transitionTime, transitionDelay - expedite, transitionSkip, () => {
			/*
				Unwrap the wrapping... unless it contains a non-unwrappable element,
				in which case the wrapping must just have its attributes removed.
			*/
			const detachable = el.filter(nonDetachableElements.join(`,`)).length === 0
			if (mustWrap && detachable) {
				/*
					Nested transitioning elements restart their animations when they're momentarily
					detached from the DOM by unwrap().
					For each nested transition, expedite its animation.
				*/
				el.find(`tw-transition-container, .transition-in, .transition-out`).each((_,Child) => {
					let child = $(Child)
					/*
						This method is attached and removed by onTransitionComplete().
					*/
					;(child.data(`expediteAnim`) || Object)()
				})
				/*
					Because detaching elements (using unwrap()) resets the scroll positions of an element,
					which the (scroll:) macro could have changed, there's nothing for it but to save and restore
					these scroll positions ourselves.
				*/
				const scrolledElems = []
				const allElems = el.find(`*`)
				for(let i = 0; i < allElems.length; i += 1) {
					const child = allElems[i]
					if (child.scrollTop !== 0 || child.scrollLeft !== 0) {
						scrolledElems.push([child, child.scrollLeft, child.scrollTop] as const)
					}
				}
				/*
					Additionally, if the wrapper contains the active element, save it and 
				*/
				const activeElem = document.activeElement && el.find(document.activeElement)

				/*
					Now, unwrap, and restore the scroll positions and focused elements.
				*/
				el.contents().unwrap()
				for (let [elem, scrollLeft, scrollTop] of scrolledElems) {
					elem.scrollLeft = scrollLeft
					elem.scrollTop = scrollTop
				}
				if (activeElem?.length) {
					activeElem[0].focus()
				}
			}
			/*
				Otherwise, remove the transition attributes.
			*/
			else {
				el.removeClass(`transition-in`).removeAttr(`data-t8n`)
			}
		})
	},

	/*
		A simple debouncing function that causes a function's call to only run 300ms after the last time it was called.
		If batching is enabled, arguments from repeated calls are batched together.
		Recursion (which would cause the function to enqueue itself) is disabled by default.
	*/
	debounce = (fn: Callback, { batch = false, recur = false, maxWait = Infinity } = {}) => {
		let animFrameID: number, args: unknown[][] | unknown[] = [], lastInvokeTime = 0, waitTime = 0, suppress = false
		const maybeRun = () => {
			// Run it if enough debouncing time has passed, or the maximum wait
			// has elapsed.
			if (Date.now() - lastInvokeTime > 300 || waitTime >= maxWait) {
				animFrameID = 0
				waitTime = 0
				suppress = !recur
				if (batch) {
					fn(args)
					args = []
				}
				else {
					fn(...args)
				}
				suppress = false
			}
			else {
				animFrameID = requestAnimationFrame(maybeRun)
			}
		}
		return (...args2: unknown[]) => {
			if (suppress) {
				return
			}
			const now = Date.now()
			waitTime += now - lastInvokeTime
			lastInvokeTime = now
			/*
				Batching slowly builds a buffer of arguments objects, whereas
				non-batching simply throws away all but the last one.
			*/
			if (batch) {
				args.push(args2)
			} else {
				args = args2
			}
			if (animFrameID) {
				cancelAnimationFrame(animFrameID)
			}
			animFrameID = requestAnimationFrame(maybeRun)
		}
	},

	/*
		Other modules which need to run startup initialisers involving the <tw-story> element
		can register them with Utils, so that they're run only on starting up.
	*/
	onStartup = (fn: VoidFunction) => {
		if (startupCallbacks) {
			startupCallbacks.push(fn)
		}
		else fn()
	},

	/*
		Detach the <tw-story> element when some complicated DOM manipulation is in order.
		Note that this does not preserve wrapping <tw-enchantment>s.
	*/
	detachStoryElement = () => {
		if (document.documentElement.contains(storyElement[0])) {
			storyElementParent = storyElement.parent()
			storyElement.detach()
		}
	},
	/*
		Reattach the <tw-story> and any <tw-enchantment> elements (or whatnot)
		that now surround it.
	*/
	reattachStoryElement = () => {
		if (!document.documentElement.contains(storyElement[0])) {
			(storyElementParent || $(document.body)).append(storyElement.parents().length ? storyElement.parents().last() : storyElement)
		}
	}

/*
	This simple event keeps both of the input maps and counts live.
*/
$(document.documentElement).on(`keydown keyup mousedown mouseup`, ({key, button, type}) => {
	const down = type.includes(`down`),
		map = key ? keysHeld : buttonsHeld,
		/*
			Keys are indexed by insensitiveName, as this allows keys to be referenced by authors
			without keeping track of capitalisation, or whether Shift is being held.
			There are no specified utility key names which collide under this.
		*/
		which = (key && insensitiveName(key)) || `${button}` || ``
	if (map[which] && !down) {
		key ? keysHeldCount = Math.max(keysHeldCount - 1, 0) : buttonsHeldCount = Math.max(buttonsHeldCount - 1, 0)
	}
	else if (!map[which] && down) {
		key ? keysHeldCount += 1 : buttonsHeldCount += 1
	}
	map[which] = down
})
.on(`mousemove`, ({pageX, pageY}) => {
	mouseCoords.x = pageX
	mouseCoords.y = pageY
})

/*
	The reference to the <tw-story> should be set at startup, so that it can be
	used even when it is disconnected from the DOM (which occurs when a new
	passage is being rendered into it).
*/
$(() => {
	storyElement = $(`tw-story`)
	// Run all the callbacks registered in startupCallbacks by other modules.
	startupCallbacks?.forEach(e => e())
	// Release startupCallbacks, causing onStartup() to no longer register functions,
	// instead just calling them immediately.
	startupCallbacks = null
})

// Basic type utilities.
type Obj<T> = Record<string, T>
type Callback = (...args:any[]) => void
type ExceptMethods<T> = ConditionalExcept<T, Callback>

// A basic asserter.
function assert(cond: unknown, message: string): asserts cond {
	if (!cond) {
		const e = Error(`Assertion failed: ${message}`)
		/*
			These traces make it easier to examine the errors when they appear during the test specs.
		*/
		console.error(e)
		throw e
	}
}

/*
	This is used exclusively by State deserialisation to denote deserialisation errors,
	which, unlike normal errors, are user-facing and can arise from adversarial save-file input.
*/
const LoadGameError = class extends Error {}

export {
	hash, permutations, nth, plural, andList, realWhitespace, anyRealLetter, anyLowercase, anyUppercase,
	anyCasedLetter, anyNewline, unescape, escape, insensitiveName, allKeysDown, someKeysDown, buttonsDown,
	anyInputDown, mouseCoords, parentColours, childrenProbablyInline, transitionIn, transitionOut, debounce,
	assert, onStartup, storyElement, detachStoryElement, reattachStoryElement, options, LoadGameError, StoryOptions,
	Obj, Callback, ExceptMethods
}
