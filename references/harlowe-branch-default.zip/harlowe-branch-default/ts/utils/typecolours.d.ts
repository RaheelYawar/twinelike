export const CSS: string
export const Colours: {
	boolean: string
	array: string
	dataset: string
	number: string
	datamap: string
	changer: string
	lambda: string
	hookName: string
	string: string
	identifier: string
	variable: string
	tempVariable: string
	datatype: string
	colour: string
	comment: string
	image: string
	macro: string
	twineLink: string
	gradient: string
	command: string
	instant: string
	metadata: string
	any: string
	customMacro : string
}
export const versionClass: string