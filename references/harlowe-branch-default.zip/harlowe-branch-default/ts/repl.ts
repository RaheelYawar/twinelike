import { onStartup, options } from "./utils.js"
import {Markup} from "./markup/markup.js"
import {Section} from "./section.js"

onStartup(() => setTimeout(() => {
	/*
		Here, it only matters if the story started in debug mode. Subsequent mode
		changes aren't important.
	*/
	if (options.debug) {
		/*
			REPL
			These are debugging functions, used in the browser console to inspect the output of
			TwineMarkup and the Harlowe compiler.
		*/
		Object.assign(globalThis, {
			REPL(a:string) {
				let s = new Section()
				let r = s.eval(Markup.lex(`(print:${a})`))
				return typeof r === `object` && `runCommand` in r && typeof r.runCommand === `function` ? (<{source: string}>r.runCommand(s)).source : r
			},
			LEX(a:string) {
				let r = Markup.lex(a)
				return r.children?.length === 1 ? r.children[0] : r
			}
		})
	}
}))