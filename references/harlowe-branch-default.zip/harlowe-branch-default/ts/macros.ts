/*
	This contains a registry of macro definitions, and methods to add to that registry.
*/
import { TaggedUnion } from "type-fest"
import {insensitiveName, nth, andList, Obj, assert} from "./utils.js"
import {objectName, typeName, toSource, spreadSet} from "./utils/operationutils.js"
import {
	AssignmentRequest,
	Changer,
	Command,
	CodeHook,
	Colour,
	Gradient,
	ImageAsset,
	HookSet,
	CustomMacro,
	Datatype,
	TypedVar,
	VarBind,
	Lambda,
	TwineError,
	Spreader,
	AnyValue,
	CommandReturnValue,
	CommandRunFn,
	FullChangeDescriptor,
	ChangerFn,
	AnyStorable,
	Measure,
} from './datatypes.js'
import {Section} from './section.js'

type singleOrArray<T> = T | Array<T>
const {isArray} = Array
const {hasOwn} = Object
const
	// Private collection of registered macros.
	macroRegistry: Obj<MacroRegistration> = {}

type MacroRegistration = {
	fn: (section:Section, ...args: AnyValue[]) => unknown
	typeSignature: Readonly<Signature[]>
	returnType: string
}

type FullSignature = Readonly<singleOrArray<Signature>>

/*
	These helper functions/constants are used for defining semantic type signatures for
	standard library macros.
*/
type Signature = typeof String | typeof Number | typeof parseInt | typeof Boolean | typeof Array | typeof Map | typeof Set | typeof AssignmentRequest | typeof Measure
	| typeof CodeHook | typeof Datatype | typeof Changer | typeof Colour | typeof CustomMacro | typeof Gradient | typeof ImageAsset | typeof HookSet | typeof TypedVar | typeof VarBind
	/*
		Actually, no signatures should use the plain Lambda class as a signature (instead of a Lambda.TypeSignature() value),
		but this is necessary for innerType type-checking to succeed.
	*/
	| typeof Lambda
	| TaggedUnion<`pattern`, {
		optional: { innerType: Signature }
		"zero or more": { innerType: Signature }
		rest: { innerType: singleOrArray<Signature> }
		either: { innerType: Signature[] }
		lambda: { innerType: typeof Lambda, clauses: Array<`where` | `each` | `making` | `via` | `with` | `when`>, typeName: string }
		"insensitive set": { innerType: string[] }
		range: { range: (s:unknown) => boolean | TwineError, min?: number, max?: number, name?: string }
		wrapped: { innerType: singleOrArray<Signature> }
		/*
			This is currently (Jul 2024) only used for generating TypedVars' signatures.
		*/
		matches: { value: AnyStorable }
	}>
	| { typeName: string }

const numberRange = (min = 0, max = Infinity) =>
	({pattern: `range`, min, max, range: (arg: unknown) => typeof arg === `number` && !Number.isNaN(arg) && arg >= min && arg <= max } as const)

const TypeSignature = {
	
	optional: (type: Signature) => ({pattern: `optional`, innerType: type } as const),
	
	zeroOrMore: (type: Signature) => ({pattern: `zero or more`, innerType: type } as const),
	
	either: (...innerType: Signature[]) => ({pattern: `either`, innerType } as const),
	
	/**
		One or more of the given datatype.
	*/
	rest: (type: singleOrArray<Signature>) => ({pattern: `rest`, innerType: type } as const),
	
	/*
		Note that "innerType" here isn't actually a valid type, but simply a set of
		recognised values. #awkward
	*/
	insensitiveSet: (...values: string[]) => ({pattern: `insensitive set`,   innerType: values } as const),

	numberRange,

	nonNegativeInteger:
		{ pattern: `range`, integer: true, min:0, max: Infinity, range: (arg:unknown) => typeof arg === `number` && !Number.isNaN(arg) && arg >= 0 && !`${arg}`.includes(`.`) } as const,

	positiveInteger:
		{ pattern: `range`, integer: true, min:1, max: Infinity, range: (arg:unknown) => typeof arg === `number` && !Number.isNaN(arg) && arg >= 1 && !`${arg}`.includes(`.`) } as const,
	
	positiveNumber:      numberRange(Number.EPSILON, Infinity),
	nonNegativeNumber:   numberRange(0, Infinity),
	percent:             numberRange(0, 1),

	/*
		This is used exclusively to provide custom error messages for particular
		type constraints.
	*/

	wrapped(innerType: singleOrArray<Signature>, message: string) {
		return {pattern: `wrapped`, innerType, message } as const
	},
	
	/*d:
		Any data
		
		A macro that is said to accept "Any" will accept any kind of data
		without complaint, as long as the data does not contain any errors.
	*/
	Any: {
		typeName: `anything`,
	},
	/*
		This very rare type is necessary to allow (ignore:) to replace commands which take unstorable data, such as hooks.
	*/
	Everything: {
		typeName: `everything`,
	}
}

/*
	This function checks the type of a single macro argument. It's run
	for every argument passed into a type-signed macro.
*/
function singleTypeCheck(arg?: AnyValue, type?: singleOrArray<Signature>) {
	/*
		First, check if it's a None type.
	*/
	if (!type) {
		return arg === undefined
	}

	const jsType = typeof arg
	/*
		Now, check if the signature is an Optional, Either, Wrapped, or a Range type.
	*/
	if (typeof type !== `function` && `pattern` in type) {
		/*
			Optional signatures can exit early if the arg is absent.
		*/
		if (type.pattern === `optional` || type.pattern === `zero or more`) {
			if (arg === undefined) {
				return true
			}
			return singleTypeCheck(arg, type.innerType)
		}
		/*
			Either signatures must check every available type.
		*/
		if (type.pattern === `either`) {
			/*
				The arg passes the test if it matches some of the types.
			*/
			for (let i = 0; i < type.innerType.length; i += 1) {
				if (singleTypeCheck(arg, type.innerType[i])) {
					return true
				}
			}
			return false
		}
		/*
			If the type expects a lambda, then check the clauses and kind.
		*/
		if (type.pattern === `lambda` && typeof arg === `object` && singleTypeCheck(arg, type.innerType)) {
			return (
					/*
						Every type signature permitting a 'where' macro also permits an 'each'
						macro.
					*/
					type.clauses.includes(`where`)  === (`where` in arg || `each` in arg)
				)
				&& type.clauses.includes(`making`) === `making` in arg
				&& type.clauses.includes(`via`)    === `via`    in arg
				&& type.clauses.includes(`with`)   === `with`   in arg
		}
		/*
			If the type expects an insensitive set of values, check if there's a match.
		*/
		if (type.pattern === `insensitive set`) {
			return typeof arg === `string` && type.innerType.includes(insensitiveName(arg))
		}
		/*
			If the type expects a limited range defined by a function, check if there's a match.
		*/
		if (type.pattern === `range`) {
			return type.range(arg)
		}
		/*
			Otherwise, if this is a Wrapped signature, ignore the included
			message and continue.
		*/
		if (type.pattern === `wrapped`) {
			return singleTypeCheck(arg, type.innerType)
		}
	}

	// If Type but no Arg, then return an error.
	if(type !== undefined && arg === undefined) {
		return false
	}
	
	if (`typeName` in type) {
		// The Any type permits any accessible argument, as long as it's present.
		if (type.typeName === `anything` && arg !== undefined && !(arg && typeof arg === `object` && (`unstorable` in arg) && arg.unstorable)) {
			return true
		}
		// This very rare type should be used only for (ignore:), as well as (test-false:) and (test-true:) changers.
		if (type.typeName === `everything` && arg !== undefined) {
			return true
		}
	}

	/*
		The built-in types. Let's not get tricky here.
	*/
	if (type === String) {
		return jsType === `string`
	}
	if (type === Boolean) {
		return jsType === `boolean`
	}
	if (type === parseInt) {
		return jsType === `number` && !Number.isNaN(arg) && !`${arg}`.includes(`.`)
	}
	if (type === Number) {
		return jsType === `number` && !Number.isNaN(arg)
	}
	if (type === Array) {
		return isArray(arg)
	}
	if (typeof type === `function` && Object.hasOwn(type, `prototype`)) {
		return arg instanceof type
	}
	return false
}

function spreadArguments<T>(args: T[]) {
	const newArgs = []
	for(let i = 0; i < args.length; i += 1) {
		/*
			Elisions (like (a:1,,2)) are to be ignored. Note that these aren't
			just undefineds, but array holes.
		*/
		if (!(i in args)) {
			continue
		}
		let el = args[i]
		if (el instanceof Spreader) {
			const value = `value` in el && el.value
			/*
				TwineErrors, obviously, can't be spread.
			*/
			const error = TwineError.containsError(value)
			if (error) {
				return error
			}
			/*
				Currently, the full gamut of spreadable
				JS objects isn't available - only arrays, sets, and strings.
			*/
			else if (isArray(value)
					|| typeof value === `string`) {
				newArgs.push(...value)
			}
			else if (value instanceof Set) {
				newArgs.push(...spreadSet(value))
			}
			else {
				throw Error(`${value} is not a string, dataset or array`)
			}
		}
		else {
			newArgs.push(el)
		}
	}
	return newArgs
}

/*
	A convenience check to see whether a type signature *contains* TypeSignature.Any anywhere in it.
*/
function typeTakesAny(e: unknown):boolean {
	return e === TypeSignature.Any || (!!e && typeof e === `object` && `innerType` in e && (isArray(e.innerType) ? e.innerType.some(typeTakesAny) : e.innerType ? typeTakesAny(e.innerType) : false))
}

/*
	This takes a macro entry (which is passed in along with its name),
	and type-checks the args passed to it before running it (or, alternatively, returning
	an error.)
*/
function typeCheckAndRun(name: string | CustomMacro, {fn, typeSignature, returnType = ``}: MacroRegistration | (CustomMacro & {returnType?: string}), section: Section, Args:AnyValue[]) {
	let args = spreadArguments(Args)
	if (args instanceof TwineError) {
		return args
	}
	/*
		Custom macros are passed in as-is, not referred to by name.
	*/
	let custom: object | undefined
	if (typeof name !== `string`) {
		custom = name
		name = ``
	}
	/*
		The invocation (its name in "(name:)" format) is used solely for error message generation.
		If the macro has more than one name, we'll (often incorrectly, but still informatively)
		use the first name, as we have no other information about which macro name was used.
		It's an uncomfortable state of affairs, I know.
	*/
	const invocation = custom ? `` : `(${isArray(name) && name.length > 1 ? name[0] : name}:)`
	name = custom ? `knownName` in custom ? `the custom macro, ${custom.knownName}` : `an unnamed custom macro` : `the ${invocation} macro`
	/*
		This is also used for error message generation: it provides the author with
		a readable sentence about the type signature of the macro.
	*/
	let signatureInfo: string
	if (typeSignature.length > 0) {
		if (typeSignature.length === 1 && typeTakesAny(typeSignature[0])) {
			signatureInfo = args.length === 1 ? `That value can't be given to macros as-is.` : `Give only a single value to this macro.`
		}
		else {
			signatureInfo = `${name} must only be given ${
					// Join [A,B,C] into "A, B, and C".
					andList(typeSignature.map(typeName))
				}${typeSignature.length > 1 ? `, in that order` : `.`}`
		}
	} else {
		signatureInfo =
			`${name} must not be given any data.${custom ? `` : ` Just write ${invocation}`}`
	}
	type Sig = Signature | Signature[] | undefined
	let rest:Sig

	for(let ind = 0, end = Math.max(args.length, typeSignature.length); ind < end; ind += 1) {
		let type: Sig = typeSignature[ind]
		let arg = args[ind]

		/*
			This is where the majority of errors are propagated, freeing up individual macros from the burden of
			doing so.
		*/
		if (TwineError.containsError(arg)) {
			return arg
		}

		/*
			A rare early error check can be made up here: if ind >= typeSignature.length,
			and Rest is not in effect, then too many params were supplied.
		*/
		if (!type && !rest) {
			return new TwineError(
				`datatype`,
				`${args.length - typeSignature.length
					} too many values were given to ${name}.`,
				signatureInfo
			)
		}
		
		/*
			If a Rest type has already come before, then it will fill in for
			the absence of a type now.
		*/
		// eslint-disable-next-line logical-assignment-operators
		type ||= rest
		/*
			Conversely, if the rest type is being introduced now,
			we now note it down and extract the type parameter...
		*/
		if (type && `innerType` in type && type.innerType && (type.pattern === `rest` || type.pattern === `zero or more`)) {
			rest = type.innerType
			/*
				...but, we only extract the type parameter if it's a Rest.
				ZeroOrMore is used in singleTypeCheck as a synonym for Optional,
				and should remain boxed.
			*/
			if (type.pattern === `rest`) {
				type = type.innerType
			}
		}
		// Now do the check.
		if (!singleTypeCheck(arg,type)) {
			/*
				If the check failed, an error message must be supplied.
				We can infer the reason why singleTypeCheck returned just by
				examining arg.
				
				For instance, if the arg is undefined, then the problem is a
				"not enough values" error.
			*/
			if (arg === undefined) {
				let mandatory = typeSignature.filter((e: Signature) => !(`pattern` in e && (e.pattern === `optional` || e.pattern === `zero or more`))).length
				return new TwineError(
					`datatype`,
					`${name} was given ${!args.length ? `nothing` : andList(args.map(objectName))}, but needs ${
						mandatory - ind} more value${(mandatory - ind) > 1 ? `s` : ``}.`,
					signatureInfo
				)
			}
			/*
				Unstorable data types are the only kinds which Any signatures will not
				match. Produce a special error message in this case.
			*/
			if (typeof arg === `object` && `unstorable` in arg && arg.unstorable && typeTakesAny(type)) {
				return new TwineError(
					`datatype`,
					`${name}'s ${nth(ind + 1)} value, ${objectName(arg)}, is not valid data for this macro.`,
					signatureInfo
				)
			}

			/*
				Passing a hook as an argument to a changer gives a unique hint.
			*/
			if (arg instanceof CodeHook && returnType === `Changer`) {
				return new TwineError(
					`syntax`, `Please put this hook outside the parentheses of ${name}, not inside it.`,
					`Hooks should appear after a macro${custom ? `.` : `: ${invocation}[Some text]`}`
				)
			}

			/*
				If the data type is a lambda, produce special error messages.
			*/
			if (arg && (arg instanceof Lambda) && type && `pattern` in type && type.pattern === `lambda`) {
				/*
					Print an error comparing the expected clauses with the actual ones.
				*/
				let t = type
				return new TwineError(`datatype`,
					`${name}'s ${nth(ind + 1)} value (a lambda) should have ${
						andList(([`where`,`when`,`making`,`via`,`with`] as const).filter(e => t.clauses.includes(e)).map(e => `a '${e}' clause`))
					}, not ${
						andList([`where`,`when`,`making`,`via`,`with`].filter(e => typeof arg === `object` && e in arg).map(e => `a '${e}' clause`))
					}.`)
			}

			/*
				Insensitive set patterns also have a special error description.
			*/
			if (type && `pattern` in type && type.pattern === `insensitive set`) {
				return new TwineError(`datatype`, `${objectName(arg)} is not a valid name string for ${name}.`,
					`Only the following names are recognised (capitalisation and hyphens ignored): ${andList(type.innerType)}.`
				)
			}

			/*
				Otherwise, give the generic data type error message.
			*/
			return new TwineError(
				`datatype`,
				`${name}'s ${nth(ind + 1)} value is ${objectName(arg)}, but should be ${typeName(type!)}.`,
				signatureInfo
			)
		}
	}
	/*
		Type checking has passed - now let the macro run.
	*/
	return fn(section, ...args)
}

/*
	The bare-metal macro registration function.
	If an array of names is given, an identical macro is created under each name.
*/
function privateAdd(name: singleOrArray<string>, returnType: string, fn: MacroFn, typeSignature: FullSignature | null) {
	/*
		The typeSignature *should* be an Array, but if it's just one item,
		we can normalise it to Array form.
		If the item is null or undefined, then that means it should be a 0-length type signature.
	*/
	let typeSignatureArray: FullSignature = typeSignature ? (<Readonly<Signature>[]>[]).concat(typeSignature) : []
	// Add the fn to the macroRegistry, plus aliases (if name is an array of aliases)
	const obj = <MacroRegistration>{ fn, typeSignature: typeSignatureArray, returnType }
	Object.freeze(obj)
	;(<string[]>[]).concat(name).forEach(n => Object.defineProperty(macroRegistry, insensitiveName(n), { value: obj }))
}

type UnattachableCommandRunFn = (section: Section, ...args: any[]) => CommandReturnValue
type MacroFn = (section: Section, ...args: any[]) => TwineError | { typeID: `instant`|`metadata` } | AnyValue

/*
	Takes a function, and produces a Command macro. A checkFn does preliminary type-checking and bounds-checking when the macro is called,
	and the runFn defines what the command performs when it's used in passage prose.
*/
type CommandCheckFn = (...args: any[]) => TwineError | undefined
/*
	Options for the Command objects produced by this command macro.
	Both of these default to true in Command.ts.
*/
type CommandDescOptions = { attachable?: boolean, storable?: boolean }

function addCommand(name: singleOrArray<string>, checkFn: CommandCheckFn, runFn: CommandRunFn, typeSignature: FullSignature): typeof addCommand
/*
	attachable: false actually changes the type signature of the runFn.
*/
function addCommand(name: singleOrArray<string>, checkFn: CommandCheckFn, runFn: UnattachableCommandRunFn, typeSignature: FullSignature, options: { attachable: false, storable?: boolean}): typeof addCommand
function addCommand(name: singleOrArray<string>, checkFn: CommandCheckFn, runFn: CommandRunFn, typeSignature: FullSignature, options: { attachable?: true, storable: boolean}): typeof addCommand
function addCommand(name: singleOrArray<string>, checkFn: CommandCheckFn, runFn: CommandRunFn | UnattachableCommandRunFn, typeSignature: FullSignature, options?: CommandDescOptions) {
	/*
		Commands need a canonical name for their print() methods.
		Since name can be either a single string or an array, this is needed
		to unwrap it.
	*/
	const firstName = (<string[]>[]).concat(name)[0]
	privateAdd(name, `Command`, (_, ...args: any[]) => {
		const error = checkFn(...args)
		if (error) {
			return error
		}
		return Command.create({
			...options ?? {},
			runFn: (cd: FullChangeDescriptor, section: Section) => options?.attachable !== false ? (<CommandRunFn>runFn)(cd, section, ...args) : (<UnattachableCommandRunFn>runFn)(section, ...args),
			name: firstName,
			source: `(${firstName}:${args.map(toSource)})`
		})
	}, typeSignature)
	// Return the function to enable "bubble chaining".
	return addCommand
}

const Macros = {
	/*
		Checks if a given macro name is registered.
	*/
	has(e: string) {
		e = insensitiveName(e)
		return hasOwn(macroRegistry, e)
	},
	
	/*
		Retrieves a registered macro definition by name, or false if it isn't defined.
	*/
	get(e: string) {
		e = insensitiveName(e)
		assert(e in macroRegistry, `No macro named ${e} registered!`)
		return macroRegistry[e]
	},
	
	/*
		A wrapper for privateAdd() that can be chained.
	*/
	add: function add(name: singleOrArray<string>, returnType: string, fn: MacroFn, typeSignature: FullSignature | null) {
		privateAdd(name, returnType, fn, typeSignature)
		// Return the function to enable "bubble chaining".
		return add
	},
	
	/*
		Takes two functions, and registers them as a live Changer macro.
		
		Changers return a transformation function (a Changer) that is used to mutate
		a ChangeDescriptor object, that itself is used to alter a Section's rendering.
		
		The second argument, ChangerFn, is the "base" for the Changers returned
		by the macro. The Changers are partial-applied versions of it, pre-filled
		with author-supplied parameters.
		
		For instance, for (font: "Skia"), the changerCommandFn is partially applied with "Skia"
		as an argument, augmented with some other values, and returned as the Changer
		result.
	*/
	addChanger: function addChanger(name: singleOrArray<string>, fn: (section: Section, ...args: any[]) => Changer | TwineError, changerCommandFn: ChangerFn, typeSignature: FullSignature | null) {
		privateAdd(name, `Changer`, fn, typeSignature)
		Changer.register(isArray(name) ? name[0] : name, changerCommandFn)
		
		// Return the function to enable "bubble chaining".
		return addChanger
	},

	addCommand,
	
	TypeSignature,

	/*
		Runs a built-in macro.
		
		In compile(), the myriad arguments given to a macro invocation are
		converted to 2 arguments to runMacro.
	*/
	run(name: string, section:Section, args: AnyValue[]) {
		/*
			Check if the macro exists as a built-in.
		*/
		if (!Macros.has(name)) {
			return new TwineError(`macrocall`,
				`I can't run the macro '${name}' because it doesn't exist.`,
				`Did you mean to run a macro? If you have a word written like (this:), it is regarded as a macro name.`
			)
		}
		return typeCheckAndRun(name, Macros.get(name), section, args)
	},
	
	/*
		Runs a custom macro, whose definition is passed in instead of a name.
	*/
	runCustom(obj: unknown, section: Section, args: AnyValue[]) {
		/*
			First, check that the variable is indeed a macro.
		*/
		if (!(obj instanceof CustomMacro)) {
			return (obj instanceof TwineError) ? obj : new TwineError(`macrocall`, `I can't call ${objectName(obj)} because it isn't a custom macro.`)
		}
		return typeCheckAndRun(obj, obj, section, args)
	},
} as const

Object.freeze(Macros)

export { Signature, Macros, MacroFn }
