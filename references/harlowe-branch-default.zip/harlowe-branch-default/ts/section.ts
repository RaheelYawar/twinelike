import $ from "jquery"
import {assert, insensitiveName, options, storyElement, reattachStoryElement, Obj} from "./utils.js"
import run from './twinescript/runner.js'
import Operations from './twinescript/operations.js'
import State from "./state.js"
import {printBuiltinValue,objectName,typeID,isObject}  from "./utils/operationutils.js"
import RenderUtils from "./utils/renderutils.js"
import runScriptTag from "./utils/scripttag.js"
import { Enchantment, Changer, Lambda, ChangeDescriptor, VarScope, TwineError, TwineNotifier, AnyValue, CustomCommandDesc, Command, AnyStorable, HarloweValue, PropertyContainer } from "./datatypes.js"
import { AnyToken } from "./markup/markup.js"

const {collapse} = RenderUtils

const {assign, keys} = Object

/*
	Each Section has a stack housing runtime data that is local to the expression/passage being
	evaluated. It is used by macros such as "display" and "if" to
	keep track of prior evaluations - e.g. display loops, (else:).
*/
class StackFrame {
	desc?: ChangeDescriptor
	tempVariables: VarScope
	// Used for infinite loop checks
	finalIter?: boolean
	// Used for producing error messages during Section's speculate()
	// TODO: When evaluateTwineMarkup() is removed, change this to just the macro name, so that error messages can be localised better.
	evaluateOnly?: string
	// Used by collapsing markup
	collapses?: boolean
	// Used during Section's speculate()
	speculativePassage?: string
	// Used by blockers; a jQuery denotes the blocking element
	blocked?: boolean|JQuery
	// Used by blockers
	dom?: JQuery
	// Used by blockers
	blockedValues?: (AnyValue | TwineError)[]
	// Only used by lambdas and the "pos" identifier
	lambdaPos?: number
	// Used by (else:) and (elseif:)
	lastHookShown?: boolean
	/*
		Used for both the values returned by (output:) and the ChangeDescriptors returned by (output-hook:).
	*/
	declare output: (data: AnyValue | CustomCommandDesc | TwineError) => void

	constructor({desc = undefined, tempVariables, finalIter = false, evaluateOnly = undefined, collapses = false, speculativePassage = undefined}:
			Pick<StackFrame, `desc` | `tempVariables` | `finalIter` | `evaluateOnly` | `collapses` | `speculativePassage`>) {
		/*
			Special case for hooks inside existing collapsing syntax:
			their whitespace must collapse as well.
			(This may or may not change in a future version).
			
			Important note: this uses the **original** target, not desc.target,
			to determine if it's inside a <tw-collapsed>. This means that
			{(replace:?1)[  H  ]} will always collapse the affixed hook regardless of
			where the ?1 hook is.
		*/
		this.desc = desc
		this.finalIter = finalIter
		this.tempVariables = tempVariables
		this.collapses = collapses
		this.evaluateOnly = evaluateOnly
		this.speculativePassage = speculativePassage
	}
}

/*
	This function selects the next sibling element which isn't a whitespace text node,
	nor a <br>. It also returns the intervening whitespace.
	Currently only used by #runExpression()
*/
function nextNonWhitespace(e: JQuery | Node): { whitespace: JQuery, nextElem: JQuery } {
	const {nextSibling} = `jquery` in e ? e[0] : e
	if (nextSibling &&
			((nextSibling instanceof Text && !nextSibling.data.trim())
			|| [`br`,`tw-consecutive-br`].includes(((<HTMLElement>nextSibling).tagName || ``).toLowerCase()))) {

		const { whitespace, nextElem } = nextNonWhitespace(nextSibling)
		return { whitespace: <JQuery>$(nextSibling).add(whitespace), nextElem }
	}
	return { whitespace: $(), nextElem: $(<HTMLElement>nextSibling) }
}

/*
	The debug-only eval replay button is appended to both <tw-expression>s and <tw-error>s, with the replay data attached.
	Since the consumer is always $().append(), returning undefined is fine.
*/
const makeReplayButton = (replay?: EvalReplayFrame[]) => {
	if (replay?.length) {
		return $(`<tw-open-button replay label='🔍'>`).data(`evalReplay`, replay)
	}
	return $()
}

/*
	This special button is appended to (go-to:), (redirect:), (restart:) and (undo:),
	and is normally only useful if the corresponding Debug Mode tool disables it.
*/
const makeActivateGotoButton = (section: Section, result?: unknown) => {
	if (result instanceof Command && /a \((go-to|undo|redirect|restart):\) command/.exec(result.typeName)) {
		/*
			This {section, command} object is later used in mode.js.
		*/
		return $(`<tw-open-button goto label='GO'>`).data(`goto`, {section, command: result})
	}
	return $()
}

/*
	Debug Mode event handlers (for adding and removing enchantments) are stored here by onEnchant().
*/
type EnchantmentEventCallback = (s: Section, e: Enchantment) => void
const eventHandlers: Obj<EnchantmentEventCallback[]> = {
	add: [], remove: [],
}

/*
	The Eval Replays used in Debug Mode allow each step of code execution to be examined by the author.
*/
type EvalReplayFrame = {
	code: string
	/*
		Each step depicts either the permutation of a code structure into a Harlowe value, or an error being produced.
	*/
	fromCode: string
	/*
		Code transformations (such as by inferred 'it') are described using the resultant transformed code.
		Plain evaluations are described using only the object name of the result value.
	*/
	toCode?: string
	toDesc?: string
	start: number
	end: number
	diff: number
	reason?: string | false
	it?: Section[`Identifiers`][`it`]
	itIdentifier?: string
	error?: JQuery
	/*
		The basis is used to convert string indexes from passage-wise to expression-wise.
		It equals the passage-wise index of the expression's first element.
	*/
	basis?: number
	/*
		Lambda loops, in a frame where a lambda was called, have their own sub-table of frames.
	*/
	lambda?: {
		obj: Lambda
		loops: LambdaReplayFrame[]
	}
}
type LambdaReplayFrame = {
	it?: AnyValue | TwineError
	pos: number
	making?: AnyStorable
	viaReplay?: EvalReplayFrame[]
	viaResult?: AnyValue | TwineError
		/*
			'null' refers to cases where a `where` clause filtered out a loop value before `via` could act on it.
		*/
		| null
	whereReplay?: EvalReplayFrame[]
	whereResult?: boolean | TwineError
}

/*
	TODO: Remove this in 4.0.
*/
type HTMLWithCachedData = HTMLElement & { cachedData?: {
	code?: AnyToken
	blockers: AnyToken[]
	source?: AnyToken[]
}}

/*
	Each Section has its own store of Identifiers keywords, due to the fact that many of them
	reference their parent Section's stack.
*/
class Identifiers implements HarloweValue, PropertyContainer {

	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly objectName: string
	declare readonly properties: string[]
	static { Object.assign(this.prototype, {
		typeID: `keywords`,
		/*
			These should normally only appear during type signature error messages.
		*/
		typeName: `the keywords`,
		objectName:`the keywords`,
		properties: [`it`,`time`,`turn`,`turns`,`visit`,`visits`,`exits`,`exit`,`pos`,`user`]
	})}

	getProperty(prop: string) {
		assert(prop in this && typeof this[<keyof Identifiers>prop] !== `function`, `No Section.Identifiers value named ${prop}!`)
		return <string|number>this[<keyof Identifiers>prop]
	}

	readonly #section: Section
	constructor(section: Section) {
		this.#section = section
	}
	/*d:
		it -> Any

		Like all identifiers, `it` is case-insensitive: `IT`, `iT` and `It` are all acceptable as well.

		This keyword is usually a shorthand for the most recently evaluated expression's leftmost value. It lets you write
		`(if: $candles < 2 and it > 5)` instead of `(if: $candles < 2 and $candles > 5)`, or `(set: $candles to it + 3)`
		instead of `(set: $candles to $candles + 3)`. (You can't, however, use it in a (put:) or (move:) macro:
		`(put:$red + $blue into it)` is invalid.)

		Since `it` uses the most recent expression's leftward value, `(print: $red > 2 and it < 4 and $blue > 2 and it < 4)` is the same as
		`(print: $red > 2 and $red < 4 and $blue > 2 and $blue < 4)`. This value of `it` changes to $blue in `it < 4` because
		the expression `$blue > 2` was evaluated by Harlowe just before, and $blue is the leftmost value inside that expression.
		(To get a greater sense of how Harlowe evaluates expressions, use Debug View in Harlowe's Debug Mode, then click on a 🔍
		button in the passage. "Record expression replays" must be enabled in the Debug Mode's options first.)

		### Inferred `it`:

		In some situations, the `it` keyword will be *inserted automatically* by Harlowe when the story runs. If you write an
		incomplete comparison expression where the left-hand side is missing, like `(print: $red > 2 and < 4)`,
		then, when running, the `it` keyword will automatically be inserted into the absent spot - producing, in this case,
		`(print: $red > 2 and it < 4)`.

		### Inferred comparisons:

		In addition to the above, there are some situations involving chains of `and` and `or` operators where Harlowe can insert
		a missing `it` keyword *and the most recently-evaluated comparison operator*. If you write `(if: $a > 2 and 3)`, then Harlowe
		will decide, since it is incorrect to use `and` directly with numbers, that what you *actually* meant was `(if: $a > 2 and it > 3)`.

		### Special case - right-side inferred comparisons:

		Harlowe will make inferences even if the comparison is on the right side of the chain of `and` and `or` operators, such as `(if: 3 and 4 < $a)`.
		In these cases, however, Harlowe will slightly change the rules of the `it` keyword to conform to English grammar intuitions. `(if: 3 and 4 < $a)`
		intuitively means "if both 3 and 4 are less than $a" in English. So, it is interpreted by Harlowe as follows.
		Since `4 < $a` is the only complete expression, it is evaluated first. Then, the *rightmost* value, $a, becomes the `it` identifier's value.
		Then, `3` becomes `3 < it`. The macro call is now equivalent to `(if: 3 < $a and 4 < $a)`.

		Note that, since this special case **only** applies to `it` keywords that Harlowe inserts by itself, you shouldn't really worry about it when
		writing your stories. Just be aware of how right-side inferred comparisons work.

		### Special case - `it` in lambdas:

		There is another special case regarding the `it` identifier: inside `where`, `via` or `making` lambdas, if `it` is used **before** any other
		expressions, then `it` refers to the data value that the lambda is currently operating on, saving you from having to write it, or, in some cases, name it at all.
		A lambda like `_num where _num > 4` can be shortened to just `where it > 4` - the `it` identifier in this case replacing the `_num` temp variable entirely.

		The design intent of this special case is to make it easier to write very short `where` lambdas, such as would be given to the (find:) macro.

		**Note:** As stated above, this special case *only* applies when `it` is used before any other expressions that would provide context. For instance,
		in the lambda `where its 1st < 3 and it < 4`, the first `it` uses this special case and refers to the data value, but the second `it` refers to the
		*left hand side of the previous expression*, `its 1st`.

		### The `its` variant:

		If the `it` keyword equals a datamap, string, array, or other "collection" data type, then you can access data values
		using the `its` variant - `(print: $red is 'egg' and its length is 3)` or `(set:$red to its 1st)`. Much like the `'s`
		operator, you can use computed values with `its` - `(if: $red's length is 3 and its $position is $value)` will work as
		expected.

		Added in: 1.0.0
	*/
	/*
		The "it" keyword is bound to whatever the last left-hand-side value
		in a comparison operation was. Since its scope is so ephemeral,
		it can just be a shared identifier right here.

		Its initial value is undefined, which should never be user-visible.
	*/
	it?: AnyValue | TwineError

	/*d:
		time -> Number

		This keyword evaluates to the number of milliseconds passed since the passage
		was displayed. Its main purpose is to be used alongside changers
		such as (live:), (event:) or (link:). `(link:"Click")[(if: time > 5s)[...]]`, for instance,
		can be used to determine if 5 seconds have passed since this passage was displayed,
		and thus whether the player waited 5 seconds before clicking the link.

		It's recommended that you compare values of time using the `ms` or `s` suffixes for number data.
		See the article on number data for more information.

		When the passage is initially being rendered, `time` will be 0.

		`time` used in (display:) macros will still produce the time of the host passage, not the
		contained passage. So, you can't use it to determine how long the (display:)ed passage
		has been present in the host passage.

		As of Harlowe 3.3.4, when testing your story in Debug Mode, you can add a multiplier to `time` (so as to quickly advance
		the passage to an important part, or linger on an important part) by using the "Speed" dropdown in the Tools panel. If you change it to 0.5x,
		`time`'s number will be multiplied by 0.5, and so forth. Note that this option will currently not affect the speed of
		transitions (using (t8n-delay:) or (t8n-time:)).

		Added in: 1.0.0
	*/
	/*
		The "time" keyword binds to the number of milliseconds since the passage
		was rendered.

		It might be something of a toss-up whether the "time" keyword should
		intuitively refer to the entire passage's lifetime, or just the nearest
		hook's. I believe that the passage is what's called for here.
	*/
	get time() {
		/*
			This can't be used during storylet speculation, for obvious reasons.
		*/
		if (this.#section.stackTop?.evaluateOnly) {
			return new TwineError(`operation`, `'time' can't be used in ${this.#section.stackTop.evaluateOnly}.`)
		}
		// The speed multiplier debug cheat is applied here.
		// TODO: figure out a way for this to work without causing the time to "jump around"
		// as soon as multipliers are changed.
		return (Date.now() - this.#section.timestamp) * (options.debug && options.speedMultiplier !== undefined ? options.speedMultiplier : 1)
	}

	/*d:
		turns -> Number

		Also known as: turn

		This keyword (which can alternatively be written as "turn") evaluates to the number of turns that have occurred in this game. A "turn" is any movement to a
		passage, including movements back to the same passage, by passage links or by various (go-to:)-related macros.
		(redirect:) does not cause a new turn to occur, so using it will not increase this value.

		Much like the "visits" keyword, its main purpose is to be used with simple macros like (nth:) or (if:) to change what
		text is displayed, such as by `(if: turns > 7)`. It is also useful in (storylet:) lambdas, such as `(storylet: when turns > 7)`,
		for storylets that should only be available when a certain number of turns have elapsed.

		For testing purposes, it can be convenient to temporarily alter `turns`'s value, so as to recreate a
		certain game state. The (mock-turns:) macro, usable only in debug mode, lets you artificially increase the number
		that this evaluates to.

		Added in: 3.3.0
	*/
	get turns() {
		return State.turns
	}

	get turn() {
		return State.turns
	}

	/*d:
		visits -> Number

		Also known as: visit

		This keyword (which can alternatively be written as "visit") always equals the number of times
		the current passage has been visited this game, including the current visit.

		Much like the "turns" keyword, its main purpose is to be used in (if:) macros, such as `(if: visits is 1)`,
		or `(if: visits > 4)`. If you use one particular formulation a lot in your story, such as `(if: visits is 1)`, you can (set:) the (if:)
		into a variable using `(set: $first to (if:visits is 1))` and then use $first in its place, such as in
		`$first[You've discovered a new island.]`.

		Similarly, it is also useful with the (cond:) and (nth:) macros - the latter letting you simply use `visit`
		as its first value to vary the results based on the number of times the passage is visited.

		This can also be used to great effect in (storylet:) macros, such as `(storylet: when visits is 0)` - in this case, it will always refer to the containing
		passage itself. When Harlowe decides whether this passage is available to (open-storylets:), this will often be 0, but when
		actually visiting the passage, it will be at least 1.

		`visits` used in (display:) macros will still produce the number of times the *host* passage was visited,
		not the contained passage. So, you can't use it to determine how many times the (display:)ed passage
		has been (display:)ed.

		Using (redirect:) to go to a passage will count as a "visit" for that passage, even though it doesn't start a new turn.

		For testing purposes, it can be convenient to temporarily alter `visits`'s value, so as to recreate a
		certain game state. The (mock-visits:) macro, usable only in debug mode, lets you increase the number of
		times certain passages have been "visited", so that this keyword produces higher numbers when in those passages.

		By default, Harlowe records an unlimited amount of passage visits. However, you can use the (forget-visits:) macro to
		make Harlowe "forget" visits that are a certain number of turns old.

		Added in: 3.1.0
	*/
	get visits() {
		const {stackTop:{speculativePassage}} = this.#section
		return State.history().filter(name => name === (speculativePassage || State.passage)).length
			// Only add 1 (counting the current visit) if this isn't speculation, or the speculative passage equals State.passage (i.e. we're at that passage now).
			+ +(!speculativePassage || speculativePassage === State.passage)
	}

	get visit() {
		return this.visits
	}

	/*d:
		exits -> Number

		Also known as: exit
		
		This keyword (which can alternatively be written as "exit") evaluates to the number of currently available "exits"
		in a passage - the number of link, mouseover, and mouseout elements that are active on the page, which could lead to new content and progress.

		This keyword is designed to be used with (live:) and (event:) - you can make a hook only
		be revealed when a certain number of exits are available, with `(event: when exits < 3)` and similar. The (more:) macro is a shorthand
		form for `(event: when exits is 0)`.

		The complete list of elements considered to be "exit" elements is as follows:
		* Links created by (link:), (link-repeat:), (link-reveal:), (link-goto:), (link-reveal-goto:), and (link-show:).
		* Passage links (which are the same as (link-goto:) links).
		* Links created by (click:), (click-replace:), (click-append:), (click-prepend:), and (click-goto:).
		* Mouseover areas created by (mouseover:), (mouseover-replace:), (mouseover-append:), (mouseover-prepend:), and (mouseover-goto:).
		* Mouseout areas created by (mouseout:), (mouseout-replace:), (mouseout-append:), (mouseout-prepend:), and (mouseout-goto:).

		Do note the following, however.
		* Multiple passage links that lead to the same passage (such as `[[A->Dead]] [[B->Dead]] [[C->Dead]]`) are all counted separately.
		* As of Harlowe 3.1.0, this does not consider (link-undo:) macros to be exits, as they tend to only undo game progress.
		* This will also not consider (event:) or (live:) macros to be exits, even if they are guaranteed to display their hooks
		eventually.
		* As with macros like (replace:), the `exits` keyword can't see forward to forthcoming elements, unless they've
		already appeared. For instance, the (print:) in `(print:exits is 1) [[Retreat->Hall]]` will show `false`, because the link after it
		hasn't appeared in the passage yet, but the (print:) in `(live:20s)[(print:exits is 1)] [[Retreat->Hall]]`
		will show `true`.
		* This can't be used in a (storylet:)'s lambda, because those lambdas are only checked when you're outside the passage.

		Finally, the "undo" and "redo" links in the sidebar will not be counted, either.

		Added in: 3.1.0
	*/
	get exits() {
		/*
			This can't be used during storylet speculation, for obvious reasons.
		*/
		if (this.#section.stackTop?.evaluateOnly) {
			return new TwineError(`operation`, `'exit' and 'exits' can't be used in ${this.#section.stackTop.evaluateOnly}.`)
		}
		return this.#section.dom.find(`tw-enchantment, tw-link`)
			.filter((_,E) => {
				let e = $(E)
				return e.data(`enchantmentEvent`) ||
					e.parent().data(`linkPassageName`)  ||
					/*
						Currently, (link:) <tw-link>s' parent <tw-hook>s have the clickEvent on them,
						which makes sense in the context of changeDescriptors (the link is created by
						replacing the <tw-hook>'s contents with the <tw-link> and giving the hook the
						clickEvent) but does feel a little #awkward.
					*/
					e.parent().data(`clickEvent`)
			})
			.length
	}

	get exit() {
		return this.exits
	}

	/*d:
		pos -> Number

		Used exclusively in lambdas, this keyword evaluates to the position of the current data value that this lambda is processing.

		Consider a macro that uses lambdas, such as (altered:) - you give it a lambda, and then one or more data values, such as
		in `(altered: via it + (str:pos), "A","B","C")`. When the lambda is processing "A", the pos identifier is 1, for "B" it's 2, and for
		"C" it's 3. This can be used for a number of purposes. You can attach an ascending number to each data value, as in that example.
		You can make only odd-numbered values be altered by using `(cond: pos is an odd, it, it + (str:pos))` (which uses the "odd" datatype).
		You can make every third value be followed by a comma, by using `(cond: pos % 3 is 2, it, it + ',')`.

		Note that this only corresponds to the position of the values when given to the macro - if you use the `...` operator to spread arrays'
		values into a macro, such as `(find: where it is > pos, ...$array1, ...$array2, ...$array3)`, then values from $array2 and $array3 will not
		have a pos that corresponds to their placement inside those arrays, but rather relative to all of the values, including those in $array1.

		Make sure you do NOT write this as `its pos` - the pos is not a data value of the data itself! If `it` was `(dm:'HP',20,'XP',12)`, `its pos`
		would cause an error, as there is no "pos" value in that datamap.

		Using this anywhere other than a lambda, or using it in a 'when' lambda (which doesn't operate over a sequence of values), will cause an error.

		Added in: 3.1.0
	*/
	get pos() {
		if (!this.#section.stackTop || this.#section.stackTop.evaluateOnly || !this.#section.stackTop.lambdaPos) {
			return new TwineError(`operation`, `'pos' can only be used in lambdas that aren't 'when' lambdas.`)
		}
		/*
			This really, really should never be a non-number, but just in case...
		*/
		return +this.#section.stackTop.lambdaPos || 1
	}

	/*
		user -> Datamap

		This keyword evaluates to a datamap holding various information about the player's screen and their screen preferences
		(which relate to the "user interface" of the story). It provides data values about what kind of display the player has,
		what their input device is capable of, and whether they have
		any visual preferences regarding high contrast or motion animations, allowing you to potentially automatically customise or adjust
		your story's style changers to match.

		The reason that this is a keyword, instead of a zero-argument macro (such as (weekday:)) is because these values are not intended for use
		in story text as-is (such as by placing a call to (weekday:) among prose) - `user` should be used inside (if:), (cond:) and other such macros
		to make decisions about how the story is displayed, what style changers are used in it, and so on.

		The datamap contains the following data names and data values:

		| Data name | Example | Meaning
		| --- | --- | ---
		| `width` | `1920` | The current width of the browser window in pixels
		| `height` | `1280` | The current height of the browser window in pixels
		| `orientation` | `"landscape"` | This is the string `"landscape"` if the user's browser window is wider than it is high, and `"portrait"` otherwise (including if the window width equals its height).
		| `motion` | `"reduced"` | This is the string `"reduced"` if the user's browser has a "prefer reduced motion" setting enabled, and `"any"` otherwise.
		| `contrast` | `"more"` | This is the string `"more"` if the user's browser or OS specifies increased contrast, `"less"` if it specifies decreased contrast, and `"any"` otherwise.
		| `hover` | `true` | This is `true` if the user's browser has hover capabilities (to interact with (hover-style:), `(action:"mouseover")`, etc.) and `false` if it does not.

		You can, for example, choose not to use an animated text style if the user's motion preferences are reduced, by writing something like this:
		```
		(set: $shockStyle to (text-style: (cond: user's motion is "reduced", "italic", "shudder")))
		```

		Bear in mind that the width, height and orientation are, in many browsers, liable to change significantly as the player resizes the window or re-orients
		their device. It can, however, be useful as a general hint about what size the reader prefers their browser window to be.

		Added in: 4.0.0
	*/
	get user() {
		return new Map<string, string | boolean | number>([
			[`width`, window.innerWidth],
			[`height`, window.innerHeight],
			[`orientation`, window.innerWidth > window.innerHeight ? `landscape` : `portrait`],
			[`hover`, matchMedia(`(any-hover: hover)`)?.matches ?? false],
			[`motion`, matchMedia(`(prefers-reduced-motion: true)`)?.matches ? `reduced` : `any`],
			[`contrast`, matchMedia(`(prefers-contrast: more)`)?.matches ? `more` : matchMedia(`(prefers-contrast: less)`)?.matches ? `less` : `any`],
		])
	}
}

class Section {
	/*
		The time this Section was rendered.
	*/
	declare timestamp: number
	/*
		The root element for this section. Macros, hookRefs, etc.
		can only affect those in this Section's DOM.
	*/
	declare dom: JQuery
	/*
		The expression stack.
		render() pushes a new StackFrame before
		running expressions, and pops it off again afterward.
	*/
	stack: StackFrame[] = []
	/*
		This is an enchantments stack. Enchantment objects (created by macros
		such as (click:)) are tracked here to ensure that post-hoc permutations
		of this enchantment's DOM are also enchanted correctly.
	*/
	enchantments: Enchantment[] = []
	/*
		When a section's execution becomes blocked, certain callbacks that need to run only
		once the section becomes unblocked (such as (event:) events) are registered here.
	*/
	unblockCallbacks: VoidFunction[] = []
	/*
		This is only used for a purely encapsulated mutation inside Runner to pass data up and down the
		run() calls. Nevertheless, it exists.

		See addFreeVariable() in Runner for details.
	*/
	freeVariables: {
		seed?: string
		seedIter?: number
		blockedValues?: (AnyValue | TwineError)[]
		/*
			Other kinds of free variables are currently not stored.
		*/
	} | true | null = null
	/*
		Only used in Debug Mode, this allows any <tw-expression>'s result evaluation to be reviewed step-by-step.
		See this.eval().
	*/
	evalReplay: EvalReplayFrame[] | undefined
	/*
		This is set by Engine whenever it navigates to a passage as a result of (load-game:). It prevents
		(load-game:) from running again in that passage until initial rendering ends.
	*/
	loadedGame = false
	/*
		The Identifiers keywords (see below).
	*/
	declare Identifiers: Identifiers
	/*
		When the Section is blocked, this becomes true.
	*/
	declare blocked?: boolean

	constructor(dom = storyElement) {
		assign(this, {
			/*
				Even though it's not been rendered yet, the timestamp needs to be recorded this early.
			*/
			timestamp: Date.now(),
			dom,
			/*
				The identifiers reference aspects of the currently rendered passage, such as the number of exits
				or the time since rendering.
			*/
			Identifiers: new Identifiers(this),
		})
	}

	/*
		Run a newly rendered <tw-expression> element's code, obtain the resulting value,
		and apply it to the next <tw-hook> element, if present.
	*/
	#runExpression(expr: JQuery, code: AnyToken | AnyToken[]) {
		/*
			Execute the expression, and obtain its result value.
		*/
		let result = this.eval(code)
		/*
			Add the replay button if replay data is available.
		*/
		expr.append(makeReplayButton(this.evalReplay))
		/*
			If it's a (go-to:), (redirect:), (restart:) or (undo:), create the button that activates it
			if Debug Mode disabled it.
		*/
		expr.append(makeActivateGotoButton(this, result))
		/*
			If this stack frame is being rendered in "evaluate only" mode (i.e. it's inside a link's passage name or somesuch)
			then it's only being rendered to quickly check what the resulting DOM looks like. As such, changers or commands which
			alter game state should not be run, and an error should be produced.
		*/
		if (this.stackTop.evaluateOnly && result && (result instanceof Changer
				|| (typeof result === `object` && `runCommand` in result && typeof result.runCommand === `function`))) {
			result = new TwineError(`syntax`,
				`I can't work out what ${this.stackTop.evaluateOnly} should evaluate to, because it contains a ${(result instanceof Changer) ? `changer.` : `command.`}`,
				`Please rewrite this without putting changers or commands here.`
			)
		}

		/*
			Consecutive changer expressions, separated with "+" and followed by a hook,
			will "chain up" into a single changer, which is then applied to that hook.

			As long as the result is a changer, it may link up with an expression following it
			if a "+" is placed between them.

			Note: If the result isn't a changer at all, then it might be another kind of value
			(a boolean, or a (live:) command) which still can be attached, but not chained.
		*/
		let nextElem = expr, nextHook = $()
		/*
			This CD is created upon encountering a command after a series of changers (i.e in attachment position).
			The changers are run against a fresh CD, and it's used later when finally running the command.
		*/
		let commandCD: ChangeDescriptor | undefined

		while(result instanceof Changer) {
			/*
				Check if the next non-whitespace element is a +, an attachable expression, or a hook.
			*/
			let whitespace: JQuery
			;({whitespace, nextElem} = nextNonWhitespace(nextElem))
			if (nextElem[0] instanceof Text && nextElem[0].data.trim() === `+`) {
				/*
					Having found a +, we must confirm the non-ws element after it is an expression.
					If it is, we try to + it with the changer.
					(If it's a Hook Expression, this + will fail and neither it nor the changer will be executed)
				*/
				let whitespaceAfter, plusMark = nextElem
				;({whitespace:whitespaceAfter, nextElem} = nextNonWhitespace(plusMark))
				if (nextElem.is(`tw-expression`)) {
					/*
						It's an expression - we can join them.
						Add the expressions, and remove the interstitial + and whitespace.
					*/
					/*
						TODO: Remove this cachedData manipulation in 4.0 (see Section.execute)
					*/
					const code = <AnyToken[]>nextElem.popData(`code`) || (<HTMLWithCachedData>nextElem[0])?.cachedData?.code
					;(<HTMLWithCachedData>nextElem[0])?.cachedData && ((<HTMLWithCachedData>nextElem[0]).cachedData!.code = undefined)

					const nextValue = this.eval(code)
					/*
						(But, don't join them if the nextValue contains its own error.)
					*/
					if (nextValue instanceof TwineError) {
						result = nextValue
						break
					}
					const newResult = Operations[`+`](result, nextValue)
					$(whitespace).add(plusMark).add(whitespaceAfter).remove()
					/*
						If this causes result to become an error, create a new error with a more appropriate
						message.
					*/
					if (newResult instanceof TwineError) {
						result = new TwineError(`operation`,
							`I can't combine ${objectName(result)} with ${objectName(nextValue)}.`,
							/*
								Because of the common use-case of attaching changers to commands, and the potential to confuse
								this with combining changers inline, a special elaboration is given for changer + command.
							*/
							typeof nextValue === `object` && `run` in nextValue && typeof nextValue.run === `function`
								? `If you want to attach this changer to ${objectName(nextValue)}, remove the + between them.`
								: `Changers can only be added to other changers.`
						)
					}
					else {
						result = newResult
					}
					/*
						Because changers cannot be +'d with anything other than themselves,
						this continue, jumping back to the while condition above, will always continue
						the loop.
					*/
					continue
				}
				/*
					If the next element wasn't an expression, fall down to the error below.
				*/
			}
			/*
				If instead of a +, it's another kind of expression, we determine if it's a Command.
				If not, then the changer's attempted attachment fails and an error results, and it doesn't matter if the expression
				is dropped (by us executing its js early) as well.
			*/
			if (nextElem.is(`tw-expression`)) {
				/*
					TODO: Remove this cachedData manipulation in 4.0 (see Section.execute)
				*/
				const code = <AnyToken[]>nextElem.popData(`code`) || (<HTMLWithCachedData>nextElem[0])?.cachedData?.code
				;(<HTMLWithCachedData>nextElem[0])?.cachedData && ((<HTMLWithCachedData>nextElem[0]).cachedData!.code = undefined)

				const nextValue = this.eval(code)
				nextElem.append(makeReplayButton(this.evalReplay))
				/*
					Errors produced by expression evaluation should be propagated above changer attachment errors, I guess.
				*/
				if (nextValue instanceof TwineError) {
					result = nextValue
					break
				}
				/*
					The changer (currently in result) is now run against a fresh CD,
					which will be used later in this function to change the command, completing the attachment.
				*/
				if (nextValue && typeof nextValue === `object` && nextValue instanceof Command) {
					commandCD ||= new ChangeDescriptor()
					commandCD.section = this
					/*
						The focus of attention (i.e. what is in result) switches to the command. However, if run() returns an error,
						then that should be considered instead.
					*/
					result = result.run(commandCD) || nextValue
					break
				}
				/*
					When the attachment can't happen, produce an error mentioning that only certain structures allow changers to attach.
					Again, potential confusion between attaching changers to commands and combining changers necessitates a special error
					message for this situation.
				*/
				else if (nextValue instanceof Changer) {
					expr.replaceWith(new TwineError(`operation`,
						`Changers like (${result.macroName}:) need to be combined using + between them.`,
						`Place the + between the changer macros, or the variables holding them. The + is absent only between a changer and its attached hook or command.`
					).render(expr.attr(`title`)))
					return
				}
				else {
					expr.replaceWith(new TwineError(`operation`,
						`${objectName(nextValue)} can't have changers like (${result.macroName}:) attached.`,
						`Changers placed just before hooks, links and commands will attempt to attach, but in this case it didn't work.`
					).render(expr.attr(`title`)))
					return
				}
			}
			if (nextElem.is(`tw-hook`)) {
				/*
					If it's an anonymous hook, apply the summed changer to it
					(and remove the whitespace).
				*/
				whitespace.remove()
				nextHook = nextElem
				break
			}
			/*
				If it's neither hook nor expression, then this evidently isn't connected to
				a hook at all. Produce an error.
			*/
			const macroCall = expr.attr(`title`) || `(${result.macroName}: ...)`
			expr.replaceWith(new TwineError(`syntax`,
				`The (${result.macroName}:) changer should be stored in a variable or attached to a hook.`,
				`Macros like this should appear before a hook: ${macroCall}[Some text]`
			).render(expr.attr(`title`)))
			return
		}

		/*
			If the above loop wasn't entered at all (i.e. the result wasn't a changer) then an error may
			be called for. For now, obtain the next hook anyway.
		*/
		nextHook = nextHook.length ? nextHook : nextNonWhitespace(expr).nextElem.filter(`tw-hook`)

		/*
			Print any error that resulted.
			This must of course run after the sensor/changer function was run,
			in case that provided an error.
		*/
		let error: TwineError | false
		if ((error = TwineError.containsError(result))) {
			/*
				Errors have the debug replay button attached, too, if replay data is available.
			*/
			expr.replaceWith(error.render(expr.attr(`title`)).append(makeReplayButton(this.evalReplay)))
			return
		}
		/*
			Apply the return type attribute, used by debug mode, to the expression.
			Note that this won't matter if the expr is replaced with an error later.
			Also, since debug mode can be enabled at any time via (debug:),
			we're doing this regardless of its current state.
		*/
		expr.attr(`return`, typeID(result))

		/*
			If we're in debug mode, a TwineNotifier may have been sent.
			In which case, print that *inside* the expr, not replacing it.
		*/
		if (result instanceof TwineNotifier) {
			expr.append(result.render())
		}
		/*
			If the expression is a Command, run it and, if it returns a ChangeDescriptor,
			run that against the expr.
		*/
		else if (typeof result === `object` && `runCommand` in result && typeof result.runCommand === `function`) {
			commandCD ||= new ChangeDescriptor()
			commandCD.section = this
			let commandResult = result.runCommand(this, commandCD)
			
			/*
				run() can also return TwineErrors (or TwineNotifiers) that only resulted
				from running the command (such as running (undo:) on the first turn).
			*/
			if (commandResult instanceof TwineError) {
				expr.replaceWith(commandResult.render(expr.attr(`title`)))
			}
			else if (commandResult instanceof TwineNotifier) {
				/*
					Don't bother rendering TwineNotifiers outside of Debug Mode.
				*/
				if (options.debug) {
					expr.replaceWith(commandResult.render())
				}
			}
			else if (commandResult instanceof ChangeDescriptor) {
				/*
					Unimplemented behaviour (2018-07-20): live changers can't be attached to commands, only
					proper hooks.
				*/
				if (commandResult.data?.live) {
					expr.replaceWith(new TwineError(`unimplemented`,
						`I currently can't attach (live:) or (event:) macros to commands - only hooks.`
					).render(expr.attr(`title`)))
					return
				}
				/*
					We need to update the ChangeDescriptor to have these fields, so
					that certain interaction macros that want to reuse it (such as (cycling-link:))
					can pass it to renderInto().
				*/
				commandResult.section = this
				commandResult.target = nextElem
				
				this.renderInto(``, nextElem, commandResult)
			}
			/*
				If runCommand returns a {blocked} object,
				then block control flow. This is usually caused by dialog macros like (alert:) or (confirm:),
				or interruption macros like (goto:).
			*/
			else if (isObject(commandResult) && `blocked` in commandResult && commandResult.blocked) {
				this.stackTop.blocked = commandResult.blocked
				/*
					This is the only way to get errors back from a command (i.e. not a value macro)
					that blocked the section, and put them in the original initiating <tw-expression>.
				*/
				expr.data(`code`, {
					type: `macro`,
					blockedValue: true,
					/*
						These three things are used only by the Debug Replay feature.
					*/
					text: expr.attr(`title`) || ``,
					start: 0,
					end: (expr.attr(`title`) || ``).length,
				})
				return
			}
			/*
				If nothing left, then the result should be undefined.
			*/
			else assert(commandResult === undefined, `runCommand() of ${objectName(result)} returned ${typeof commandResult}: ${commandResult}`)
		}
		/*
			Attempt to attach the expression to the next hook. If it succeeds, we're done.
		*/
		else if (nextHook.length && this.#applyExpressionToHook(expr, result, nextHook)) {
			return
		}
		/*
			Print the expression if it's a string, codehook, number, data structure,
			or is some other data type without runCommand().
		*/
		else if (
				/*
					If it's plain data, it shouldn't be attached to a hook.
					If it was attached, an error should be produced
					(by applyExpressionToHook) to clue the author into the correct attachable types.
				*/
				typeof result === `string`
				|| typeof result === `number`
				|| result instanceof Map
				|| result instanceof Set
				|| Array.isArray(result)
				|| (typeof result === `object` && `print` in result && typeof result.print === `function` && !(result instanceof Changer))) {
			/*
				print(), when called by printBuiltinValue(), typically emits
				side-effects. These will occur... now.
			*/
			let printResult = printBuiltinValue(result)
			/*
				Errors directly replace the element.
			*/
			if (printResult instanceof TwineError) {
				expr.replaceWith(printResult.render(expr.attr(`title`)))
			}
			else {
				assert(typeof printResult === `string` || Array.isArray(printResult), `printBuiltinValue() produced a non-string non-array ${typeof printResult}`)
				/*
					Transition the resulting Twine code into the expression's element.
				*/
				this.renderInto(printResult, expr)
			}
		}
		/*
			The only remaining values should be unattached changers, or booleans.
		*/
		else {
			assert(result instanceof Changer || typeof result === `boolean`, `The expression evaluated to an unknown value: ${result}`)
		}
	}

	/*
		A live hook is one that has the (live:) or (event:) macro attached.
		It repeatedly re-renders, allowing a passage to have "live" behaviour.
		
		The default delay for (live:), which is also used by (event:), is 20ms.

		This is exclusively called by runExpression().
	*/
	#runLiveHook(expr: JQuery, cd: ChangeDescriptor, target: JQuery) {
		/*
			Events given here MUST have a 'when' property.
		*/
		const {delay, event} = target.data(`live`)
		/*
			Prepare a new changeDescriptor to use once the hook is finally being run.
			This always has 'replace' because currently (Feb 2022) no live macros
			purely append or prepend.
		*/
		cd = Object.setPrototypeOf({ ...cd, append:`replace`, transitionDeferred: false, enabled:true }, ChangeDescriptor.prototype)
		/*
			But, remove the liveness from the new ChangeDescriptor, for obvious reasons.
		*/
		cd.data = { ...cd.data, live: undefined }
		/*
			Obtain the code of the hook that the (live:) or (event:) changer suppressed.
		*/
		const source = target.data(`originalSource`) || ``
		/*
			Similarly to the other delayed rendering macros like (link:) and (click:),
			this too must store the current stack tempVariables object, so that it can
			give the event access to the temp variables visible at render time.
		*/
		const {tempVariables} = this.stackTop
		/*
			Store the target's current parent, to check that it's still in the DOM.
		*/
		let previousTimestamp: number
		let duration = delay
		let recursive: VoidFunction
		const animFrameCallback: FrameRequestCallback = timestamp => {
			if (previousTimestamp) {
				duration -= (timestamp - previousTimestamp)
					// The speed multiplier debug cheat is applied here.
					* (options.debug && options.speedMultiplier !== undefined ? options.speedMultiplier : 1)
			}
			previousTimestamp = timestamp
			
			if (duration > 0) {
				requestAnimationFrame(animFrameCallback)
				return
			}
			duration = delay
			recursive()
		}
		/*
			The use of .bind() here is to save reinitialising the inner function on every call.
		*/
		recursive = this.whenUnblocked.bind(this, () => {
			/*
				We must do an inDOM check here in case a different (live:) macro
				(or a (goto:) macro) caused this to leave the DOM between
				previous runs, or if this was erroneously used in a (macro:) macro's code hook.
			*/
			if (!this.inDOM()) {
				return
			}
			/*
				If this is an (event:) command, check the event (which should be a "when" lambda)
				and if it's not happened yet, wait for the next timeout.

				Note: Lambda.filter() returns the passed-in array with values filtered out based on
				whether the lambda was false. So, passing in 'true' will return [true] if
				the lambda was true and [] (an empty array) if not.
			*/
			const eventFired = event?.filter(this, [true], tempVariables)
			if (TwineError.containsError(eventFired)) {
				eventFired.render(this, expr.attr(`title`)).replaceAll(expr)
				return
			}
			/*
				(live:) macros always render; (event:), (more:) and (after:) macros only render once the event fired.
			*/
			if (event && !eventFired[0]) {
				requestAnimationFrame(animFrameCallback)
				return
			}
			this.renderInto(source, target, cd, tempVariables)
			/*
				If the event DID fire, on the other hand, we should stop.
			*/
			if (eventFired) {
				return
			}
			/*
				The (stop:) command causes the nearest (live:) command enclosing
				it to be stopped. If a (stop:) is in the rendering target, we shan't continue running.
			*/
			if (target.find(`tw-expression[name='stop']`).length) {
				return
			}
			/*
				Re-rendering will also cease if this section was removed from the DOM,
				possibly by a (replace:) inside this hook.
			*/
			if (!this.inDOM()) {
				return
			}
			
			/*
				Otherwise, resume re-running.
			*/
			requestAnimationFrame(animFrameCallback)
		})
		requestAnimationFrame(animFrameCallback)
	}

/*
	Section objects represent a block of Twine source rendered into the DOM.
	It contains its own DOM, a reference to any enclosing Section,
	and methods and properties related to invoking code within it.
	
	The big deal of having multiple Section objects (and the name Section itself
	as compared to "passage" or "screen") is that multiple simultaneous passages'
	(such as stretchtext mode) code can be hygenically scoped. Hook references
	in one passage cannot affect another, and so forth. (This hygeine is currently
	not implemented, however, as neither is stretchtext.)

	After a section has finished rendering, one can expect it to be discarded.
	The following things allow a section object to persist:
	* Live hook macros (until they deactivate themselves when the section is removed from the DOM)
	* Saved (enchant:), (link-goto:) and other macros.
*/

	/*
		Apply the result of a <tw-expression>'s evaluation to the next hook.
		If the result is a changer, live command or boolean, this will cause the hook
		to be rendered differently.

		@param {jQuery} The <tw-expression> element.
		@param {Any} The result of running the expression.
		@param {jQuery} The next <tw-hook> element, passed in solely to save re-computing it.
	*/
	#applyExpressionToHook(expr: JQuery, result: AnyValue | TwineError, nextHook: JQuery) {
		/*
			If result is a Changer, please run it.
		*/
		if (result && typeof result === `object` && result instanceof Changer) {
			/*
				The use of popAttr prevents the hook from executing normally
				if it wasn't actually the eventual target of the changer function.
			*/
			/*
				TODO: Remove this cachedData manipulation in 4.0 (see Section.execute)
			*/
			const source = <AnyToken[]>nextHook.popData(`source`) || (<HTMLWithCachedData>nextHook[0]).cachedData?.source
			;(<HTMLWithCachedData>nextHook[0])?.cachedData && ((<HTMLWithCachedData>nextHook[0]).cachedData!.source = undefined)

			nextHook.data(`originalSource`, source)
			/*
				Rather than simply passing the changer to renderInto(),
				run a fresh CD through it. If it was a live changer, this will be re-used
				for each additional iteration.
			*/
			const desc = new ChangeDescriptor({
				/*
					Don't forget: nextHook may actually be empty.
					This is acceptable - the result changer could alter the
					target appropriately.
				*/
				target: nextHook, source, section: this, append: `append`})
			/*
				(for:) changers can produce errors on running instead of just on creation.
			*/
			const error = result.run(desc)
			if (error instanceof TwineError) {
				expr.replaceWith(error.render(expr.attr(`title`)))
			}

			const enabled = this.renderInto(
				source,
				/*
					Because we're passing in a ChangeDescriptor that has a target (posssibly altered by the changer above), the target can be undefined.
				*/
				undefined,
				desc
			)

			if (!enabled) {
				const name = insensitiveName(expr.attr(`name`)!)
				/*
					The 'false' class is used solely by debug mode to visually denote
					that a macro such as (if:) (but not (hidden:)) suppressed a hook.
				*/
				if ([`if`, `elseif`, `unless`, `else`, `testfalse`].includes(name)) {
					expr.addClass(`false`)
					/*
						Unfortunately, (else-if:) must be special-cased, so that it doesn't affect
						lastHookShown, instead preserving the value of the original (if:).
					*/
					if (name !== `elseif`) {
						this.stackTop.lastHookShown = false
					}
				}
				/*
					If the changer included a (live:) or (event:) command,
					set up the intervals to live-update the attached macro.
				*/
				if (nextHook.data(`live`)) {
					this.#runLiveHook(expr, desc, nextHook)
				}
				return true
			}
			/*
				Do note: renderInto(), via ChangeDescriptor.render(), installs the 'hidden' and 'originalSource'
				attributes on the non-enabled hook by itself, thus not requiring this function to do it.
			*/
		}
		/*
			Attached false values hide hooks as well.
			This is special: as it prevents hooks from being run, an (else:)
			that follows this will pass.
		*/
		else if (result === false) {
			/*
				Removing the 'source' attribute is necessary to prevent this from being rendered
				by Section.
			*/
			/*
				TODO: Remove this cachedData manipulation in 4.0 (see Section.execute)
			*/
			const source = <AnyToken[]>nextHook.popData(`source`) || (<HTMLWithCachedData>nextHook[0]).cachedData?.source
			;(<HTMLWithCachedData>nextHook[0])?.cachedData && ((<HTMLWithCachedData>nextHook[0]).cachedData!.source = undefined)

			if (source) {
				nextHook.data(`originalSource`, source)
				nextHook.data(`hidden`,true)
			}
			expr.addClass(`false`)
			
			this.stackTop.lastHookShown = false
			return true
		}
		/*
			If the result isn't a boolean, simply decline to attach it, and allow Section to print it where it is.
		*/
		else if (result !== true) {
			return false
		}
		/*
			The (else:) and (elseif:) macros require a little bit of state to be
			saved after every hook interaction: whether or not the preceding hook
			was shown or hidden by the attached expression.
			Sadly, we must oblige with this overweening demand.
		*/
		this.stackTop.lastHookShown = true
		return true
	}

	/*
		Lexer tokens, usually from <tw-expression> elements, are evaluated here.
	*/
	eval(args: AnyToken | AnyToken[]) {
		/*
			This sets up the debug-only evalReplay array, which records each step of the evaluation process
			for viewing when the player clicks the replay button. Runner checks for the mere presence of this
			array, and populates it itself. Because of the number of varied eval() consumers out there,
			the replay data can't be succinctly included as a return value of this, but is instead
			left as a mutated property on this section.
		*/
		if (options.debug && options.evalReplay) {
			/*
				The initial code listing is the full text of all tokens.
			*/
			const code = Array.isArray(args) ? args.reduce((a,e) => a + e.text, ``) : args.text || ``
			this.evalReplay = [{
				code,
				fromCode: code,
				/*
					Because tokens' starts and ends are in passage-wise coordinates,
					recording the passage-wise start of the first token allows Runner to
					convert them to expression-wise coordinates.
				*/
				basis:(Array.isArray(args) ? args[0] : args).start,
				start: 0,
				end: code.length,
				diff: 0,
			}]
		}
		let ret: AnyValue | TwineError
		try {
			ret = run(this, args)
		} catch(e) {
			window.console?.error(e)
			this.evalReplay = undefined
			return new TwineError(`other`, `An internal error occurred while trying to run ${(<AnyToken[]>[]).concat(args).map(e=>e.text).join(``)}.`,
				`The error was "${(<Error>e).message}".\nIf this is the latest version of Harlowe, please consider reporting a bug (see the documentation).`)
		}
		/*
			For replays with only two frames, remove the first "Once upon a time" frame.
		*/
		if (this.evalReplay && this.evalReplay.length === 2) {
			this.evalReplay.shift()
		}
		return ret
	}

	/*
		This is an alias for the top of the expression stack, used mainly to access the "blocked"
		and "blockedValues" properties.
	*/
	get stackTop() {
		return this.stack[0]
	}
	
	/*
		A quick check to see if this section's DOM is connected to the story's DOM.
		Currently only used by runLiveHook().
	*/
	inDOM() {
		return storyElement.find(this.dom).length > 0
	}
	
	/*
		This function allows an expression of TwineMarkup to be evaluated as data, and
		determine the content within it.
		This is currently only used by (link-goto:), to determine the link's passage name.
	*/
	evaluateTwineMarkup(expr: string, evalName: string) {
		/*
			The expression is rendered into this loose DOM element, which
			is then discarded after returning.
		*/
		const p = $(`<p>`)
		
		/*
			Render the text, using this own section as the base (which makes sense,
			as the recipient of this function is usually a sub-expression within this section).
		
			No changers, etc. are capable of being applied here.
		*/
		this.stack.unshift(new StackFrame({
			desc: new ChangeDescriptor({ target: p, source: expr, section: this, append:`append` }),
			tempVariables: this.stackTop.tempVariables || undefined,
			/*
				This special string (containing the reason we're evaluating this markup)
				causes all command and changer values in the markup to become errors,
				and suppress all blockers. This forcibly prevents [[(set: $a to it+1)Beans]] from being
				written.
			*/
			evaluateOnly: evalName,
			finalIter: true,
		}))
		this.execute()
		
		/*
			But first!! Pull out any errors that were generated.
			We return the plain <tw-error> elements in order to save re-creating
			them later in the pipeline, even though it makes the type signature of
			this function {String|jQuery} somewhat #awkward.
		*/
		let errors
		if ((errors = p.find(`tw-error`)).length > 0) {
			return errors
		}
		return p
	}

	/*
		This is a counterpart to evaluateTwineMarkup(): instead of taking markup and executing it as HTML,
		this takes macro arguments and evaluates them in this section's context, in a separate stack frame which
		is discarded afterward (hence that it is "speculative" execution). As you can tell, this is
		used for (storylet:) and (metadata:) execution during startup and when running (open-storylets:).
	*/
	speculate(code:AnyToken | Lambda, speculativePassage:string, evalName:string) {
		this.stack.unshift(new StackFrame({
			tempVariables: new VarScope(evalName),
			/*
				As with evaluateTwineMarkup(), above, finalIter and evaluateOnly are used to suppress command, blocker and changer values, which
				should not appear in any code which needs to be evaluated speculatively.
			*/
			finalIter: true,
			evaluateOnly: evalName,
			/*
				This string is used by storylet metadata macros like (storylet: when visits is 0),
				which, when run via speculation by (open-storylets:), need "visits" to mean visits of
				their containing passage, and not the currently visited passage. And, when run normally,
				they need to return an unstorable object instead of their lambda's result.
			*/
			speculativePassage,
		}))
		
		/*
			Cache the evalReplay of section, so that the speculative execution doesn't clobber it.
		*/
		const {evalReplay} = this
		this.evalReplay = undefined

		/*
			Passages can speculatively execute either code (that is, (metadata:) calls) or compiled lambdas
			(that is, when storylet lambdas are run.)
		*/
		let ret
		if (code instanceof Lambda) {
			/*
				"when" storylets don't have loop vars.
			*/
			ret = code.apply(this, { loop: undefined, pos: 1 })
		}
		else if (code) {
			ret = run(this, code)
		}
		/*
			Restore the state of this section before the execution.
		*/
		this.stack.shift()
		this.evalReplay = evalReplay
		return ret
	}
	
	/*
		Renders the given markup, or a lexed tree, into a given element,
		transitioning it in. A Changer can be provided to
		modify the ChangeDescriptor object that controls how the code
		is rendered.
		
		This is used primarily by Engine.showPassage() to render
		passage data into a fresh <tw-passage>, but is also used to
		render TwineMarkup into <tw-expression>s (by runExpression())
		and <tw-hook>s (by render() and runLiveHook()).
	*/
	renderInto(source: string | AnyToken[], t?: JQuery, changer?: Changer | Partial<ChangeDescriptor>, tempVariables: VarScope | null = null) {
		/*
			This is the ChangeDescriptor that defines this rendering.
		*/
		const desc = new ChangeDescriptor({ target:t, source, section: this, append: `append`})

		/*
			Run the changer function, if given, on that descriptor.
		*/
		if (changer) {
			/*
				If a non-changer object (such as another descriptor) was passed in, assign its values,
				overwriting the default descriptor's.
				Honestly, having non-changer descriptor-altering objects
				is a bit displeasingly rough-n-ready, but it's convenient...
			*/
			if (!(changer instanceof Changer)) {
				assign(desc, changer)
			}
			else {
				const error = changer.run(desc)
				if (error instanceof TwineError
						/*
							It should not be possible that both the passed-in ChangeDescriptor
							and the t argument are undefined.
						*/
						&& t) {
					error.render(t.attr(`title`)).replaceAll(t)
					return false
				}
			}
		}

		/*
			The changer may have altered the target - update the target variable to match.
		*/
		const target =
			/*
				See ChangeDescriptor#update(). I'm not entirely sure if this is necessary here, though…
			*/
			typeof desc.target === `function` ? desc.target() : desc.target
		
		assert(target, `No target!`)

		/*
			Infinite regress can occur from a couple of causes: (display:) loops, or evaluation loops
			caused by something as simple as (set: $x to "$x")$x.
			So: bail if the stack length has now proceeded over 50 levels deep, ignoring extra iterations of the same for-loop.
		*/
		if (this.stack.length >= 50) {
			const depth = this.stack.reduce((a, {finalIter}) =>
				/*
					Ignore all iteration stack frames except for the final iteration. This permits (for:) (which
					needs all its stack frames put on at once due to some implementation kerfuffle involving flow blockers)
					to loop over 50+ elements without being a false positive.
				*/
				a + +!!finalIter, 0)
			if (depth >= 50) {
				new TwineError(`infinite`, `Printing this expression may have trapped me in an infinite loop.`)
					.render(target.attr(`title`)).replaceAll(target)
				return false
			}
		}

		/*
			If no temp variables store was created for the child stack frames of this render, create one now.
			Rather than a proper constructor, it is currently initialised in here.
		*/
		if (!tempVariables) {
			/*
				For debug mode, the temp variables store needs to also carry the name of its enclosing lexical scope.
				We derive this from the current target.

				(The target should always be truthy, but, just in case...)
			*/
			const targetTag = target?.tag()
			
			tempVariables = new VarScope(
				targetTag === `tw-hook` ? target.attr(`name`) ? `?${target.attr(`name`)}` : `an unnamed hook` :
					targetTag === `tw-expression` ? `a ${target.attr(`type`)} expression` :
					targetTag === `tw-passage` ? `this passage` :
					`an unknown scope`,
					`temp`,
					/*
						The temp variable scope of the rendered DOM inherits from the current
						stack, or, if absent, the base VarScope class.
					*/
					this.stack.length ? this.stackTop.tempVariables : null
			)
		}

		/*
			We need to check if the subsequent this.execute() call will block the stack - hence, here's a quick
			confirmation whether it is currently blocked beforehand.
		*/
		const isBlockedBefore = this.stackTop?.blocked

		/*
			If the descriptor features a loopVar, we must loop - that is, render and execute once for
			each value in the loopVars, assigning the value to their temp. variable names in a new data stack per loop.

			For a loopVars such as {
				a: [1,2,3],
				b: [5,6],
			},
			the created tempVariables objects' variableStores should be these two:
			{ a: 2, b: 6 }.
			{ a: 1, b: 5 },
		*/
		if (desc.loopVars && keys(desc.loopVars).length) {
			// Find the shortest loopVars array, and iterate that many times
			let len = Math.min(...Object.values(desc.loopVars).map(value => value.length))

			// A gentle debug notification to remind the writer how many loops the (for:) executed,
			// which is especially helpful if it's 0.
			new TwineNotifier(`${len} loop${len !== 1 ? `s` : ``}`).render().prependTo(target)

			if (len) {
				for(let i = len - 1; i >= 0; i -= 1) {
					const loopVarScope = new VarScope(`a (for:) loop's variables`, `temp`, tempVariables)
					for (let prop in desc.loopVars) {
						loopVarScope.variableStore[prop] = desc.loopVars[prop][i]
					}
					/*
						All the stack frames need to be placed on the stack at once so that blocked flow (from (alert:))
						can resume seamlessly by just continuing to read from the stack.
					*/
					this.stack.unshift(new StackFrame({
						desc,
						tempVariables: loopVarScope,
						finalIter: i === len - 1,
						evaluateOnly: this.stackTop?.evaluateOnly,
						/*
							Special case for hooks inside existing collapsing syntax:
							their whitespace must collapse as well.
							(This may or may not change in a future version).
							
							Important note: this uses the **original** target, not desc.target,
							to determine if it's inside a <tw-collapsed>. This means that
							{(replace:?1)[  H  ]} will always collapse the affixed hook regardless of
							where the ?1 hook is.
						*/
						collapses: `jquery` in target && target.is(`tw-hook`) && target.parents(`tw-collapsed,[collapsing=true]`).length > 0
					}))
				}
				/*
					Having populated the stack frame with each individual loop variable, it's now time to
					run them, checking after each iteration to see if a flow control block was caused.
				*/
				for (let i = len - 1; i >= 0 && !this.stackTop.blocked; i -= 1) {
					this.execute()
				}
			}
		}
		/*
			Otherwise, just render and execute once normally.
		*/
		else {
			this.stack.unshift(new StackFrame({
				desc,
				tempVariables,
				finalIter: true,
				evaluateOnly: this.stackTop?.evaluateOnly,
				collapses: `jquery` in target && target.is(`tw-hook`) && target.parents(`tw-collapsed,[collapsing=true]`).length > 0
			}))
			this.execute()
		}
		
		/*
			Finally, update the enchantments now that the DOM is modified.
			We should only run updateEnchantments in the "top level" render call,
			to save on unnecessary DOM mutation.
			This can be determined by just checking that this Section's stack is empty or blocked.
		*/
		if (this.stack.length === 0 || (!isBlockedBefore && this.stackTop?.blocked)) {
			this.updateEnchantments()
		}

		/*
			This return value is solely used by debug mode to colour <tw-expression>
			macros for (if:) in cases where it suppressed a hook.
		*/
		return desc.enabled
	}

	/*
		This runs a single flow of execution throughout a freshly rendered DOM,
		replacing <tw-expression> and <tw-hook> elements that have "source"
		or "code" data with their renderings. It should be run whenever renderInto()
		creates new DOM elements, and whenever a blocker finishes and calls unblock().
	*/
	execute() {
		let {desc, dom, collapses, evaluateOnly} = this.stackTop

		if (!dom) {
			assert(desc, `No dom or desc!`)
			/*
				Run the changeDescriptor, and get all the newly rendered elements.
				Then, remove the desc from the stack frame and use the DOM from now on
				(which won't be very long unless a blocker appears).
				The reason the desc is stored in the stack at all is because of (for:) macros -
				it puts multiple frames on the stack at once, and it's memory-efficient to have
				a single descriptor for each of them rather than a pre-rendered DOM.
			*/
			dom = desc.render()

			this.stackTop.dom = dom
			this.stackTop.desc = undefined
		}
		/*
			Execute the expressions immediately.
		*/
		dom.findAndFilter(`tw-hook,tw-expression,script[type="application/x-harlowe"]`)
				/*
					For compatibility with 3.2, each expression's data is backed up as a DOM element expando property, in case they are removed from the DOM
					before running. This should be removed in 4.0, so that the more intuitive behaviour (removing from the DOM
					prevents expressions from running) is used instead.
				*/
				.each((_, expr) => {
					let d = $(expr).data()
					/*
						These should be the same 3 data values assigned to freshly-created elements in Renderer.
					*/
					;(<HTMLWithCachedData>expr).cachedData = {
						blockers: d.blockers,
						code: d.code,
						source: d.source,
					}
				})
				.each((_, Expr:HTMLWithCachedData) => {
			/*
				This is used to halt the loop if a hook contained a blocker - the call to renderInto()
				would've created another stack frame, which, being blocked, hasn't been removed yet.
				This needs to be at the start of the function, not the end, or else (output:)'s blocking
				won't work, for reasons I do not understand.
			*/
			if (this.stackTop.blocked) {
				return false
			}
			/*
				Retrieve the backed-up jQuery data().
			*/
			let {cachedData} = Expr
			cachedData && (Expr.cachedData = undefined)

			const expr = $(Expr)
			
			switch(expr.tag()) {
				case `tw-hook`:
				{
					/*
						Since hooks can be re-ran with (rerun:), their original content AST needs to be stored.
					*/
					let src = <AnyToken[]>expr.popData(`source`) || cachedData?.source
					if (src) {
						expr.data(`originalSource`, src)
					}
					/*
						Also, much as I'd prefer not to do this, the (show:) and (rerun:) macro needs to have access to any given <tw-hook>'s
						temp variables store, so that rerunning it will cause the correct temp variables to be used, rather than those
						available at the (show:) callsite.
					*/
					expr.data(`tempVariables`, this.stackTop.tempVariables)
					/*
						First, hidden hooks should not be rendered.
						The 'hidden' data value is used by (show:) and (link-show:). If it's a boolean, then it hasn't been shown (run) yet.
						If it's a jQuery, it has been shown, and its contents should be used instead of rendering.
					*/
					if (expr.popAttr(`hidden`)) {
						expr.data(`hidden`,true)
						break
					}
					/*
						Now we can render visible hooks.
						Note that hook rendering may be triggered early by attached expressions, so a hook lacking 'content'
						data has probably already been rendered.
					*/
					if (src) {
						this.renderInto(src, expr)
					}
					break
				}
				case `tw-expression`:
				{
					/*
						Control flow blockers are sub-expressions which, when evaluated, block control flow
						until some signal, such as user input, is provided, whereupon control
						flow proceeds as usual. These have been extracted from the main expressions by Renderer,
						and are run separately before the main expression.

						Because there are no other side-effect-on-evaluation expressions in Harlowe (as other state-changers
						like (loadgame:) are Commands, which only perform effects in passage prose), we can safely
						extract and run the blockers' code separately from the parent expression with peace of mind.

						Blocker expressions are identified by having 'blockers' data, which should persist across
						however many executions it takes for the passage to become unblocked.
					*/
					const blockers: AnyToken[] = expr.data(`blockers`) || cachedData?.blockers
					if (blockers) {
						if (evaluateOnly) {
							expr.removeData(`blockers`).removeData(`code`).replaceWith(
								new TwineError(`syntax`,
									`I can't use a macro like (prompt:) or (confirm:) in ${evaluateOnly}.`,
									`Please rewrite this without putting such macros here.`
								).render(expr.attr(`title`))
							)
							return
						}
						if (blockers.length) {
							/*
								The first blocker can now be taken out and run, which
								blocks this section and ends execution.

								The blocker's own macro call may cause this.stackTop to become a jQuery of the blocked
								element, so that events can still fire within it. Thus, this setting is only a special backup.
							*/
							this.stackTop.blocked = true
							let error = this.eval(blockers.shift()!)
							/*
								If the blocker's code resulted in an error (such as a basic type signature error),
								this is the first occasion it'd become known. Display that error, if it is given,
								and unblock this section.
							*/
							if (error instanceof TwineError) {
								this.stackTop.blocked = false
								expr.removeData(`blockers`).replaceWith(error.render(expr.attr(`title`)))
							}
							return false
						}
						expr.removeData(`blockers`)
					}
					const code = <AnyToken[]>expr.popData(`code`) || cachedData?.code
					if (code) {
						this.#runExpression(expr, code)
					}
					break
				}
				case `script`:
				{
					/*
						So that jQuery and document.querySelector calls can access the entire DOM of the passage,
						the <tw-story> element is reattached early. This is a bit regrettable performance-wise,
						but it seems to be the only way to make these things work as expected.
					*/
					reattachStoryElement()

					/*
						Do nothing if there's no inner text (which would be the case if it has a [src]) attribute.
					*/
					if (!expr.text()) {
						break
					}
					try {
						runScriptTag(expr.text(), this.stackTop.tempVariables)
					} catch(e) {
						/*
							runScriptTag can throw either TwineErrors (such as errors from VarRef.set())
							or plain JS errors.
						*/
						if (e instanceof TwineError) {
							expr.replaceWith(e.render(expr.text()))
						}
						else {
							window.console?.error(e)
							expr.replaceWith(
								new TwineError(`other`,
									`A Javascript error occurred while running this <script> element.`,
									`The error was "${e}". Check the browser console for more details.`
								).render(expr.text())
							)
						}
					}
				}
			}
		})

		/*
			If the section was blocked, then don't shift() the stack frame, but leave it until it's unblocked.
		*/
		if (this.stackTop.blocked) {
			return
		}

		/*
			The collapsing syntax's effects are applied here, after all the expressions and sub-hooks have been
			fully rendered.
		*/
		if (dom.length && collapses) {
			collapse(dom)
		}
		dom.findAndFilter(`tw-collapsed,[collapsing=true]`).each((_,e) => {
			collapse($(e))
		})

		/*
			Focus any <input> elements (from (input:) and (input-box:)) that were added to the page.
			Regrettably, this arbitrary timeout seems to be the only reliable way to focus the <input>.
		*/
		setTimeout(() => dom.find(`input, textarea`).first().focus(), 100)
		
		/*
			After evaluating the expressions, pop the passed-in data stack object (and its scope).
			Any macros that need to keep the stack object (mainly interaction and deferred rendering macros like
			(link:) and (event:)) have already stored it for themselves.
		*/
		this.stack.shift()
	}
	
	/*
		Updates all enchantments in the section. Should be called after every
		DOM manipulation within the section (such as, at the end of .render()).
	*/
	updateEnchantments() {
		this.enchantments.forEach(e => {
			/*
				This first method removes old <tw-enchantment> elements...
			*/
			e.disenchant()
			/*
				...and this one adds new ones.
			*/
			e.enchantScope()
		})
	}

	/*
		This is used exclusively by Debug Mode to add the handlers for adding and removing enchantments.
	*/
	static on(event: keyof typeof eventHandlers, fn: EnchantmentEventCallback) {
		eventHandlers[event].push(fn)
		return this
	}

	addEnchantment(enchantment: Enchantment) {
		this.enchantments.push(enchantment)
		eventHandlers.add.forEach(fn => fn(this, enchantment))
	}

	removeEnchantment(enchantment: Enchantment) {
		const index = this.enchantments.indexOf(enchantment)
		this.enchantments.splice(index,1)
		enchantment.disenchant()
		eventHandlers.remove.forEach(fn => fn(this, enchantment))
	}

	/*
		Every control flow blocker macro needs to call section.unblock() with its return value (if any) when finished.
	*/
	unblock(value?: AnyValue | TwineError) {
		assert(this.stack.length, `stack is empty`)
		this.stackTop.blocked = false
		/*
			The value passed in is stored in the stack's blockedValues array, where it should
			be retrieved by other blockers, or the main expression, calling blockedValue().
			Only in rare circumstances (currently, just the (alert:) command) will no blocked value be passed in.
		*/
		if (value !== undefined) {
			this.stackTop.blockedValues = (this.stackTop.blockedValues || []).concat(value)
		}
		while (this.stack.length && !this.stackTop.blocked) {
			this.execute()
		}
		/*
			If the section became fully unblocked, it is time to run the "when unblocked"
			callbacks.
		*/
		if (!this.stack.length) {
			/*
				This is a "while" loop that uses .shift(), so that the state of
				this.unblockCallbacks remains valid after each iteration, in case another
				blockage occurs.
			*/
			while(this.unblockCallbacks.length > 0) {
				const callback = this.unblockCallbacks.shift()
				callback?.()
				/*
					If the callback caused the section to suddenly become blocked again, stop
					processing the callbacks.
				*/
				if (this.stackTop?.blocked) {
					return
				}
			}
		}
	}

	/*
		Callbacks that need to be run ONLY when the section is unblocked (such as (live:) events, interaction
		element events, and (goto:)) are registered here. Or, if it's already unblocked, they're run immediately.

		immediateFn is a variation of fn used when the section is already unblocked. Currently (March 2022), only runLiveHook()
		uses it.
	*/
	whenUnblocked(fn: VoidFunction, immediateFn = fn) {
		if (!this.stack.length || !this.stackTop.blocked) {
			immediateFn()
			return
		}
		this.unblockCallbacks = this.unblockCallbacks.concat(fn)
	}

	/*
		Renderer permutes control flow blocker tokens into blockedValue tokens, which are compiled into
		blockedValue() calls. After the control flow blockers' code is run, the blockedValues array has been populated
		with the results of the blockers, and each call places them back into the parent expression.
	*/
	blockedValue() {
		const {stackTop} = this
		assert(stackTop, `stack is empty`)
		assert(stackTop.blockedValues?.length, `blockedValues is missing or empty`)
		return stackTop.blockedValues.shift()
	}

}
Object.preventExtensions(Section)
Object.preventExtensions(Section.prototype)

export { Section, StackFrame, EvalReplayFrame, Identifiers }
