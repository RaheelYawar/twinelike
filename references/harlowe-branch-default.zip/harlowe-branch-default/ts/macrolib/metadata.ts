import {Macros} from "../macros.js"
import {clone, objectName, isValidDatamapName, toSource, spreadSet} from "../utils/operationutils.js"
import Lambda from "../datatypes/lambda.js"
import TwineError from "../internaltypes/twineerror.js"
import { AnyValue, AssignmentRequest, Datatype, ImageAsset, TypedVar } from "../datatypes.js"
import State from "../state.js"
import { nth } from "../utils.js"

/*d:
	Metadata data

	Certain kinds of macros are not used inside the passage itself, but are used to mark the passage as being special in some way, or having certain
	data available to other macros that inspect the story's state, such as (passages:) or (open-storylets:). These macros are "metadata" macros,
	because they attach metadata to the passage. These macros must appear at the very start of those passages, ahead of every other kind of macro.
	Using them in any other location will cause an error.

	Every valid metadata macro is run only once, when the story begins. As such, "metadata" is not a type of data that's available to other macros,
	and there is no need for a datatype called `metadata`.
*/
const {zeroOrMore, Any} = Macros.TypeSignature

/*
	The dual nature of metadata macros - that they aren't visible in the passage itself but
	produce a value when run by Renderer's speculation - is illustrated here.
	This object is returned by each metadata macro that is called outside of a speculative passage.
*/
const unstorableObject = (macroName:string) => ({
	typeID:       `metadata`,
	// Return a plain unstorable value that prints out as "".
	typeName:     `a (${macroName}:) macro`,
	objectName:   `a (${macroName}:) macro`,
	unstorable:   true,
	// Being unstorable and not used by any other data structures, this doesn't need a print() function.
	print:        () => ``,
} as const)

/*d:
	(storylet: Lambda) -> Metadata

	When placed in a passage, it marks that passage as the beginning of a storylet, using the lambda as the condition upon which it's available to the player,
	so that other macros, like (open-storylets:), can see and select the passage.

	Example usage:

	* `(storylet: when $season is "winter" and $married is false and visits is 0)`
	* `(storylet: when (visited: "mortuary"))`

	Rationale:
	Storylets are mini-stories within a story - disconnected sequences of passages that can be visited non-linearly when certain conditions are fulfilled.
	They allow a different way of writing interactive fiction than the rigid tree structure of typical Twine games: instead,
	simply write scenes and events that occur in the story, use this macro in the first passage of these mini-stories to write a programming condition that
	determines when it would make sense for that scene to occur, and use macros like (open-storylets:) or (link-storylet:) to dynamically create links to the storylets.
	This authoring style allows content to be added to the story without having to dramatically rearrange the story's structure.

	Examples of narrative structures that can be represented as storylets include: jobs on a job board that are available at different times but only
	acceptable once; encounters in a role-playing-game that vary based on randomness and location; random dream sequences between linear chapters;
	chores to perform in a housekeeping or farming simulation. Simply create clumps of passages containing each of these sequences, mark the first passage
	of each with this macro, and make the end of each (or a central "hub" passage that they link back to) with code that uses (open-storylets:)
	to create links elsewhere.

	Details:
	This macro adds a "storylet" data name to the (passages:) datamap for this passage, letting you access the passed-in lambda. In fact, you can use (metadata:)
	in place of (storylet:) if you wish - `(storylet: when $hour is 12)` is actually just a shorthand for `(metadata:"storylet", when $hour is 12)`. (metadata:)
	can be used instead if you're already using it to attach other data. if you use both (storylet:) and `(metadata: "storylet"`, an error will result.

	Being a metadata macro, a (storylet:) macro call must appear in the passage *before* every other non-metadata macro in the passage, such as (set:) and (if:).
	(This doesn't include macros inside a "header" tagged passage.) The recommended place to put it is at the top of the passage. This restriction is because
	the (storylet:) call's lambda is only ever checked outside the passage. Variable-changing macros in the passage, such as (set:), are not run until the
	passage is visited, even if they appear before a (storylet:) macro. So, the code `(set: $a to 2)(storylet: when $a is 2)` is misleading, because it won't
	cause $a to always be 2 when the lambda is checked.

	Inside a (storylet:) macro's lambda, the "visit" and "visits" identifiers refer to the containing passage, so they will often be 0. Checking visits
	(such as by `visits is 0`) allows you to make a storylet only be available once (because after that, it will have become visited). Also,
	the "exits" identifier cannot be used here (because it's meaningless in this context).

	See also:
	(open-storylets:), (passages:), (event:), (metadata:)

	Added in: 3.2.0
	#storylet 1
*/
/*d:
	(urgency: Number) -> Metadata

	When placed in a passage that also has a (storylet:) call, it marks that passage as being more or less "urgent", meaning that (open-storylets:)
	will sort it earlier or later than other passages.

	Example usage:
	`(urgency: 2)` causes this storylet to appear earlier in the (open-storylets:) than storylets with `(urgency:1)` or no urgency macro.

	Rationale:
	The (open-storylets:) macro provides you with an array of all currently-open storylets, but that typically isn't the amount of options
	you'd like to show to the player each time. Often you'll just limit it to a few values using array data names like `1stto4th`. In that case, the
	order of the returned array matters a lot - being one of the first few values determines whether it'll be seen among the others. In those cases,
	it can sometimes be helpful to guarantee a certain storylet or storylets, when available, are always present in the first few values.
	The (urgency:) macro allows for this - give it a number, and it will be sorted above open storylets with a lower or no urgency number.

	Details:
	This is essentially a shorthand for calling (metadata:) with "urgency" - it adds an "urgency" data name and value to the passage's (passage:)
	datamap - except that it will error if a non-number is given to it.

	Storylets without an "urgency" metadata number, added by this macro or by (metadata:), are treated as having `(urgency: 0)`. This means
	that a storylet with a negative urgency, such as `(urgency: -11)`, will appear at the end of the (open-storylets:) array, unless a storylet
	with an even lower urgency is also open.

	See also:
	(exclusivity:)

	Added in: 3.2.0
	#storylet 4
*/
/*d:
	(exclusivity: Number) -> Metadata

	When placed in a passage that also has a (storylet:) call, it marks that passage as being more or less "exclusive", meaning that if it's open,
	it will prevent storylets with lesser exclusivity from appearing in (open-storylets:).

	Example usage:
	`(exclusivity: 2)` means that, if this storylet is open, other storylets with exclusivity lower than this are closed, and can't
	appear in (open-storylets:)'s array.

	Rationale:
	Storylets are very useful for creating non-linear stories, in which the player's available choices and directions are determined entirely
	by the game state, rather than an explicit web of links. But, sometimes it's necessary to pen the player in and prevent them from having the same
	range of choices. An example is a climactic final event in a story, which has its own storylet lambda, but which, when available, shouldn't
	be avoidable by picking another storylet. While you could code this by wording each other passage's storylet lambdas very carefully, such that no
	others are open when the final event is open, that would be very cumbersome. The (exclusivity:) macro lets you specify that
	a storylet should be an *exclusive* option that prevents more common options from being available.

	Details:
	This is essentially a shorthand for calling (metadata:) with "exclusivity" - it adds an "exclusivity" data name and value to the passage's (passage:)
	datamap - except that it will error if a non-number is given to it.

	Storylets without an "exclusivity" metadata number, added by this macro or by (metadata:), are treated as having `(exclusivity: 0)`. This means
	that a storylet with a negative exclusivity, such as `(exclusivity: -0.001)`, will not be able to appear in (open-storylets:) if any other storylets
	lacking an explicit (exclusivity:) call are also open.

	See also:
	(urgency:)

	Added in: 3.2.0
	#storylet 3
*/
for (let [name, signature] of [
	[`storylet`, Lambda.TypeSignature(`when`)],
	[`urgency`, Number],
	[`exclusivity`, Number],
] as const) {
	Macros.add(name, `Metadata`, (section, arg) =>  !section.stackTop.speculativePassage ? unstorableObject(name) : arg, signature)
}

Macros.add
	/*d:
		(metadata: [...Any]) -> Metadata

		When placed in a passage, this adds the given names and values to the (passage:) datamap for this passage.

		Example usage:
		* `(metadata: "danger", 4, "hint", "Dragon teeth are fire-hardened.")` in a passage
		named "Dragon dentistry" causes `(passage:"Dragon dentistry")'s danger` to be 4, and `(passage:"Dragon dentistry")'s hint` to equal the given string.
		* `(metadata: "rarity", 5)` in a passage called "Adamantium" causes `(passage: "Adamantium")'s rarity` to be 5. You can then use
		`(find: where its rarity >= (random: 1, 10), ...(passages: where it contains "rarity"))` to get a list of passages that may randomly exclude the "Adamantium" passage.

		Rationale:

		While the (passage:) and (passages:) datamaps can provide the tags, name and source code of your story's passages by default,
		there are many cases when you need more specific data than just strings, such as a number or a changer. An example is when making links for
		passages that have been chosen non-deterministically, such as by (open-storylets:) - you may want the link to be accompanied with a short description fitting
		the passage, or you may want each passage to have a random chance of not appearing at all. Moreover, you want to be able to write this information inside
		the passage itself, as you write it, just as tags are written on the passage as you write it.

		The (metadata:) macro provides this functionality - it augments the (passage:) datamap for the current passage,
		adding extra data of your choosing to it, as if by adding a (dm:) to it at startup.

		Details:

		The data names and values are provided to (metadata:) as if it was a (dm:) macro call – first the string names, then the values, in alternation.

		Being a metadata macro, a (metadata:) macro call must appear in the passage *before* every other non-metadata macro in the passage, such as (set:) and (if:).
		(This doesn't include macros inside a "header" or "footer" tagged passage.) The recommended place to put it is at the top of the passage.

		Every passage's (metadata:) macro is run just once, at startup. If an error occurs while doing so (for instance, if a value is given without a matching name)
		then a dialog box will appear at startup, displaying the error.

		Since passages already have "source", "name" and "tags" data names in their datamap, trying to use these names in a (metadata:) macro will produce an error.

		Putting this in a "header", "startup" or "footer" tagged passage will NOT cause this metadata to be applied to every passage, much as how adding extra tags
		to a "header", "startup" or "footer" tagged passage will not cause those tags to apply to every passage.

		See also:
		(passage:), (passages:), (storylet:)

		Added in: 3.2.0
		#game state
	*/
	(`metadata`, `Metadata`,
		(section, ...args: AnyValue[]) => {
			let key: AnyValue | undefined
			const map = new Map()
			/*
				This takes the flat arguments "array" and runs map.set() with every two values.
				During each odd iteration, the element is the key. Then, the element is the value.
			*/
			const status = args.reduce((status: TwineError | true, element) => {
				/*
					Propagate earlier iterations' errors.
				*/
				if (status instanceof TwineError) {
					return status
				}
				if (key === undefined) {
					key = element
				}
				/*
					Key type-checking must be done here.
				*/
				else {
					let error = isValidDatamapName(map, key)
					if (error instanceof TwineError) {
						return error
					}
					/*
						Of course, you can't use the same key twice.
					*/
					else if (map.has(key)) {
						return new TwineError(`macrocall`,
							`You used the same data name (${objectName(key)}) twice in the same (metadata:) call.`
						)
					}
					map.set(key, clone(element))
					key = undefined
				}
				return status
			}, true)
			/*
				Return an error if one was raised during iteration.
			*/
			if (status instanceof TwineError) {
				return status
			}
			/*
				One error can result: if there's an odd number of arguments, that
				means a key has not been given a value.
			*/
			if (key !== undefined) {
				return new TwineError(`macrocall`, `This (metadata:) macro has a data name without a value.`)
			}
			/*
				If this is being run in its own passage (instead of by a storylet macro) then all of the above was executed
				just for error-checking. Exit out here.
			*/
			if (!section.stackTop.speculativePassage) {
				return unstorableObject(`metadata`)
			}
			return map
		},
		zeroOrMore(Any)
	)
	/*d:
		(define: ...VariableToValue) -> Metadata
		
		Stores data in a variable permanently, and make it available from the very start of the story, regardless of which passage
		this macro call appears in. It "defines" the variable to always mean that given data.

		Example usage:
		```
		--These variables are used as shorthands, to save needing to write out each value in full.
		(define:
			$fancyHeader to (font:"Arnold Bocklin") + (size:48px),
			$defaultName to "ANITA AMANITA",
			$rollD20 to (partial: "random", 1, 20)
		)
		```

		Rationale:

		This is similar to (set:), but designed to be used with data that should remain constant across the whole story. That is, it should be used
		for data which doesn't represent the game-state or the player's progress, but which is used in the story's code and styling.
		Changers that are attached to hooks throughout the story, or custom macros created with (macro:) or (partial:), are ideal data to be created using (define:).

		Although you can use (set:) to restrict a variable to `const-type` data, such as by `(set: const-type $rollD20 to (partial: "random", 1, 20)))`, using (define:)
		for this purpose is slightly shorter, and, moreover, allows Harlowe to optimise the save data created with (save-game:) (see below for more details).

		Details:

		The main differences between this and (set:) are as follows. First, this is a metadata macro, meaning that it is run *when the story
		begins*, before all non-metadata macros, regardless of which passage it is in. Second, the data stored in each variable becomes permanent, as if `const-type` was applied to it.

		Because these are run when the story begins, you *cannot* refer to any variables created with (set:), (put:), or any non-metadata macros. So,
		even if `(set: $maxCash to 99)` is in the starting passage or a header-tagged passage, you cannot write something like `(define: $maxDebt to -$maxCash)`,
		because $maxCash hasn't been set by the time the (define:) call runs.

		Note that using the `-type` syntax to restrict variables is not only unnecessary with (define:), it is by-and-large not allowed at
		all - `(define: num-type $b to 2)` will produce an error on startup until you remove `num-type`. The only restrictions permitted are `any-type` and `const-type`,
		but these are redundant (they have no effect), so it is recommended not to use them, either.

		Unlike other metadata macros, like (metadata:) or (storylet:), you *can* use multiple (define:) calls in a single passage. However, every
		(define:) call *must* come before any non-metadata macro calls in the passage

		Save file optimisation:

		Creating a variable using (define:) allows Harlowe to optimise the story's save files, by excluding the variable from it (as its value should be the same for every
		possible playthrough of the story). Normal variables created using (set:) or (put:), even if restricted to `const-type`, are still saved in save files.
		As a result, when you edit that variable's data partway through story testing (such as to fix a bug or adjust a changer) any existing save files are likely
		to become invalid (due to the old version of the variable still being recorded in it), and you would have to abandon it and start over. With (define:),
		however, the likelihood of this occuring is reduced significantly, making for a more robust editing experience.

		The additional effect of being excluded from the save file means that save files themselves become smaller and a little faster to save and restore.
		Very large custom macros, or very long strings, are *highly* recommended data values to store using (define:).

		See also:
		(set:), (put:), (unpack:)

		Added in: 4.0.0
		#basics 3
	*/
	/*
		Note that the most important aspect of (define:) - the State.addDefinitions() call - is hardcoded into Passages.loadMetadata().
	*/
	(`define`, `Metadata`, (section, ...assignmentRequests: AssignmentRequest[]) => {
		/*
			Don't run this outside of speculative execution, which only happens when the story is initialised
			(in Passages.loadMetadata()).
		*/
		if (!section.stackTop.speculativePassage) {
			return unstorableObject(`metadata`)
		}
		for(let ar of assignmentRequests) {
			if (ar.operator === `into`) {
				return new TwineError(`macrocall`, `Please say 'to' when using the (define:) macro.`)
			}
			/*
				Even though the author may not specify any type with a (define:) call,
				the Runner always compiles untyped AssignmentRequests into TypedVars with any typing.
				As a result, the assignmentRequest's dest should always be a TypedVar.
			*/
			if (!(ar.dest instanceof TypedVar)) {
				return new TwineError(`macrocall`, `Please use the (define:) macro with just single variables to the left of 'to'.`)
			}
			/*
				Other restrictions are enforced here.
			*/
			if (ar.dest.varRef.object !== State.variables) {
				return new TwineError(`macrocall`, `Please use the (define:) macro with story-wide variables (like $this), not temp variables.`)
			}
			if (ar.dest.varRef.propertyChain.length !== 1) {
				return new TwineError(`macrocall`, `You can't use the (define:) macro with data names of other variables.`)
			}
			/*
				But, as mentioned above, type restrictions are forbidden.
				const-type is permitted only because they are semantically redundant,
				and any-type is permitted only because it is not possible (yet) to distinguish them from the
				inferred any-type values (above).
			*/
			let datatypeName = ar.dest.datatype instanceof Datatype && ar.dest.datatype.name
			if (!datatypeName || !(datatypeName === `any` || datatypeName === `const`)) {
				return new TwineError(`macrocall`, `Don't use -type syntax with (define:) - each definition is always considered to be const-type.`)
			}
			let [propertyName] = ar.dest.varRef.propertyChain
			if (<string>propertyName in State.definitions.variableStore) {
				return new TwineError(`macrocall`, `The variable '$${propertyName}' has already been used in another (define:) call.`)
			}
			/*
				In order to assign the value to the definitions, the AssignmentRequest is modified in-place
				to point to it, and the datatype is changed to 'definition', a special datatype that is only used for Debug Mode.
			*/
			ar.dest.varRef.object = State.definitions
			ar.dest.datatype = new Datatype(`definition`)
			/*
				All of that being done, set() can now be called.
			*/
			const debugMessage = ar.set()
			if (debugMessage instanceof TwineError) {
				return debugMessage
			}
			/*
				Because assets can only be created using (define:), they can be serialised as a single path into the definition's data structures,
				that will work reliably anytime during the game.
				For instance, in (define: $a to (a: (image:'a'), (image:'b'))), the images can be serialised as `$a's 1st` and `$a's 2nd`.

				The main reason this is here and not in VarRef's .set() is because this should never be run except during (define:) calls.
			*/
			function setAssetKnownName(path:string, value:AnyValue) {
				/*
					When audio assets are implemented, this should be updated.
				*/
				if (value instanceof ImageAsset) {
					value.knownName = path
				}
				else if (Array.isArray(value)) {
					for(let i = 0; i < value.length; i += 1) {
						setAssetKnownName(`${path}'s ${nth(i+1)}`, value[i])
					}
				}
				else if (value instanceof Map) {
					for(let [k,v] of value.entries()) {
						setAssetKnownName(`${path}'s (${toSource(k)})`, v)
					}
				}
				/*
					For datasets (which is a terrible choice of structure for images, and thus very rare in practice),
					simply convert the set to array to get a path.
					Because defined datasets are immutable, this should remain stable.
				*/
				else if (value instanceof Set) {
					value = spreadSet(value)
					for(let i = 0; i < value.length; i += 1) {
						setAssetKnownName(`(a:...${path})'s ${nth(i)}`, value[i])
					}
				}
			}
			setAssetKnownName(`$${propertyName}`, ar.src)
		}
		/*
			This should not be used at all by preprocess() in Passages.ts.
		*/
		return unstorableObject(`metadata`)
	},
	[Macros.TypeSignature.rest(AssignmentRequest)])