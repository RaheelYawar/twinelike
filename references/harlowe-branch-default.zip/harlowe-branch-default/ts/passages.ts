import $ from "jquery"
import NaturalSort from "./utils/naturalsort.js"
import {insensitiveName,unescape,onStartup,assert, Obj}  from "./utils.js"
import {AnyToken, Markup} from "./markup/markup.js"
import TwineError from "./internaltypes/twineerror.js"
import Lambda from "./datatypes/lambda.js"
import { Section } from "./section.js"
import { HarloweValue, UserFacing } from "./datatypes.js"
import State from "./state.js"

const {assign} = Object
/*
	Passages
	A userland registry of Passage objects.
	Passage objects are simple Maps exposing passage data to public scripts.
	They have their string content (the "source"), their tags in an array, and their name.
*/

/*
	For a tiny bit of efficiency, the quick regexp used in preprocess() is stored here.
	This uses Patterns rather than Lexer's rules because those compiled RegExps for macroFront
	and macroName can't be combined into a single RegExp.
*/
const macroRegExp = RegExp(Markup.Patterns.macroFront + Markup.Patterns.macroName, `ig`)

/*
	This is used only to carry metadata macro tokens from preprocess() to loadMetadata().
	Each passage object has one of these as an expando value.
*/
type MetadataTokens = Obj<AnyToken[] | TwineError>
/*
	When the game starts, each passage is scanned for metadata macros using this method. An object
	holding one macro call for each metadata macro name is returned.
*/
function preprocess(src:string, name:string) {
	/*
		Metadata macros contain lambdas and other data, which is extracted from the passage
		code and attached to the passage map itself during startup.
		These names are hard-coded.
	*/
	const metadataMacros = [`metadata`,`storylet`,`exclusivity`,`urgency`,`define`] as const
	/*
		Since lexing all the passages at bootup is potentially rather expensive, these quick and hacky RegExp tests are
		used to check whether preprocessing is necessary.
	*/
	if (!
		/*
			This does a quick RegExp query for metadata macros, instead of lexing the entire source.
		*/
		(src.match(macroRegExp) || <string[]>[]).some(e => metadataMacros.some(f => insensitiveName(e.slice(1,-1)) === f ))
	) {
		return {}
	}
	/*
		For each macro:
		if it's a metadata macro outside macro scope, and NOT commented out, get its call.
			It's commented out if a comment token is before it, OR if a comment token is before any of its parent tokens.
		if it's a metadata macro inside macro scope, error
		if it's a non-metadata macro after a metadata macro outside macro scope, error
	*/
	let afterNonMetadataMacro = false
	const metadata: MetadataTokens = {}
	;(<AnyToken[]>Markup.lex(src,name).children).forEach(function outsideMacroFn(token, i, siblings) {
		/*
			If immediate previous token is the comment line, ignore this token and its children.
			This allows singly commented-out metadata macro calls to be ignored.
		*/
		if (siblings[i-1]?.type === `comment`) {
			return
		}
		if (token.type === `macro`) {
			const name = insensitiveName(token.name)
			if (metadataMacros.some(f => name === f)) {
				/*
					If an error was already reported for this metadata name, don't replace it.
				*/
				if (metadata[name] instanceof TwineError) {
					return
				}
				/*
					Metadata macros can't appear after non-metadata macros.
				*/
				if (afterNonMetadataMacro) {
					metadata[name] = new TwineError(`syntax`, `The (${token.name}:) macro can't appear after non-metadata macros.`)
					return
				}
				/*
					Having two metadata macros of the same unique kind is an error. If there was already a match, produce a TwineError about it
					and store it in that slot.
					Every metadata macro except (define:) is unique.
					Technically we don't need this, because Passage.loadMetadata() raises a separate error if two metadata macros
					override each other's data. But, this one is more incisively descriptive.
				*/
				if (metadata[name] && name !== `define`) {
					metadata[name] = new TwineError(`syntax`, `There is more than one (${token.name}:) macro in this passage.`)
					return
				}
				/*
					Store the token in the metadata store. Because there can be multiple (define:)s in one passage,
					this needs to be an array of tokens.
				*/
				(<AnyToken[]>(metadata[name] ||= [])).push(token)
			}
			else {
				afterNonMetadataMacro = true
			}
			/*
				Check that the metadata macro call contains no nested metadata macro calls.
			*/
			token.children.forEach(function nestedMacroFn(token: AnyToken) {
				const name = `name` in token && typeof token.name === `string` && insensitiveName(token.name)
				if (name && token.type === `macro` && metadataMacros.some(f => name === f)) {
					metadata[name] = new TwineError(`syntax`, `The (${token.name}:) macro can't be inside another macro.`)
				}
				else token.children.forEach(nestedMacroFn)
			})
		}
		else token.children.forEach(outsideMacroFn)
	})
	return metadata
}

/*
	Pass a <tw-passagedata> element into this constructor,
	and a Passage datamap will be produced.
*/

class Passage extends Map implements HarloweValue, UserFacing<Passage> {
	constructor(elem: JQuery) {
		super()
		const name = elem.attr(`name`) ||
			/*
				TODO: Add some proper verification for the <tw-passagedata> data.
			*/
			``
		const source = unescape(elem.html())
		/*
			Metadata macros (such as (storylet:)) need to be extracted and applied to the passage datamap itself.
			The source is exclusively used by error messages and Debug Mode.
		*/
		this.metadata = preprocess(source,name)

		this.set(`source`, source)
			.set(`tags`, (elem.attr(`tags`) || ``).split(/\s/) || [])
			.set(`name`, name)
	}
	declare readonly typeID: string
	declare readonly typeName: string
	static { Object.assign(this.prototype, {
		typeID: `datamap`,
		typeName: `a passage datamap`
	})}
	get objectName() { return `the "\`${this.get(`name`)}\`" passage's datamap` }
	toSource() {
		return this.get(`source`)
	}
	/*
		The following is a temporary store of metadata returned from Renderer.preprocess(),
		which is crunched during loadMetadata() and removed.
	*/
	declare metadata?: MetadataTokens
	/*
		This is used to cache the lexed syntax tree. However, to save memory, only header and footer passages
		have their tree permanently stored. The others use the limited cache below.
	*/
	declare tree: AnyToken
}
/*
	Since new passages can't ever be created (as of Dec 2021), it's safe to cache tag lookups.
*/
let tagCache = <Obj<Passage[]>>Object.create(null)
/*
	Cache of lexed passage trees, so that passages visited frequently aren't lexed repeatedly.
*/
let passageTreeCache:AnyToken[] = []
/*
	Cache of Passages.allStorylets(). This is used by Debug Mode. Unlike the above, an empty array
	is a valid final value, so the 'uninitialised' value is null.
*/
let storyletCache:Passage[] | undefined

type PassagesMap = Map<string, Passage>
const Passages = assign(new Map<string, Passage>(), {
	typeID: `datamap`,
	typeName: `the Passages datamap`,
	objectName: `the Passages datamap`,
	
	/*
		This method retrieves passages which have a given tag.
	*/
	getTagged(this: PassagesMap, tag:string) {
		/*
			Use the tag cache, if it exists.
		*/
		if (tagCache[tag]) {
			return tagCache[tag]
		}

		const tagSorter = NaturalSort(`en`, (p: Passage) => p.get(`name`))
		const ret: Passage[] = []
		this.forEach(v => {
			const tags = v instanceof Map && v.get(`tags`)
			if (Array.isArray(tags) && tags.includes(tag)) {
				ret.push(v)
			}
		})
		ret.sort(tagSorter)
		/*
			Cache this result, now that it's computed.
		*/
		tagCache[tag] = ret
		return ret
	},

	/*
		This is (currently) exclusively used by the Harlowe codebase test runner.
	*/
	clearTagCache() {
		tagCache = Object.create(null)
	},

	/*
		Overrides for clear() and delete() that wipe the caches. Note that only the test runner
		should call these.
	*/
	clear() {
		Map.prototype.clear.call(this)
		this.clearTagCache()
		this.clearTreeCache()
		this.clearStoryletCache()
	},

	delete(arg: unknown) {
		Map.prototype.delete.call(this, arg)
		this.clearTagCache()
		this.clearTreeCache()
		this.clearStoryletCache()
	},

	/*
		Retrieve a cached lexed code tree for this passage's source,
		or lex it here and now.
	*/
	getTree(this: PassagesMap, name:string) {
		assert(this.has(name), `No passage name!`)
		/*
			'header' and 'footer' passages are stored in their own cache which is never emptied.
		*/
		const p = this.get(name)
		assert(p, `No passage named '${p}'`)
		const tags = p.get(`tags`)
		if (tags.includes(`header`) || tags.includes(`footer`) || tags.includes(`debug-header`) || tags.includes(`debug-footer`)) {
			if (!p.tree) {
				p.tree = Markup.lex(p.get(`source`), name)
			}
			return p.tree
		}
		/*
			First, retrieve it from the cache if it exists for this name.
		*/
		for (let i = 0; i < passageTreeCache.length; i += 1) {
			if (passageTreeCache[i] && passageTreeCache[i].place === name) {
				/*
					In addition to finding the tree, move it to the front to make
					it quicker to find later. Since the cache's limit is only 16
					entries, it shouldn't be too costly to do this that often.
				*/
				const entry = passageTreeCache.splice(i, 1)[0]
				passageTreeCache.unshift(entry)
				return entry
			}
		}
		/*
			Entries in the cache are ordered by most recent retrieval, then by name.
			Again, the small size of the cache means that this shouldn't be too costly.
		*/
		const entry = Markup.lex(p.get(`source`), name)
		passageTreeCache.unshift(entry)
		/*
			This maximum cache size is hard-coded.
		*/
		if (passageTreeCache.length > 16) {
			passageTreeCache.pop()
		}
		return entry
	},

	clearTreeCache() {
		passageTreeCache = []
	},

	/*
		Storylet macros like (open-storylets:) query every passage's storylet condition code using this method.
		They may supply a lambda to filter the passages with, first.
		The results are sorted in the order expected by (open-storylets:).
	*/
	getStorylets(section: Section, passagesLambda?: Lambda) {
		/*
			For each passage that matches the lambda:
			If it has an "available" lambda, run the lambda. If the lambda returned true, put it on the list.
		*/
		const passages = passagesLambda ? passagesLambda.filter(section, [...Passages.values()]) : [...Passages.values()]
		if (passages instanceof TwineError) {
			return passages
		}
		const active: Passage[] = []
		let highestExclusivity = -Infinity
		/*
			Populate the result, or return the first error that appeared when evaluating a passage's lambda.
		*/
		const error = passages.reduce((error: TwineError | undefined, p) => {
			if (error) {
				return error
			}
			const storylet = p.get(`storylet`)
			if (storylet) {
				const available = section.speculate(storylet, p.get(`name`), `a (storylet:) macro`)
				if (available instanceof TwineError) {
					/*
						Alter the error's message to report the name of the passage from which it originated.
					*/
					available.message = `There's an error in the storylet passage "${p.get(`name`)}":\n${available.message}`
					/*
						The original source code of the lambda is used as the error's source, instead of that of
						the (open-storylets:) macro call.
					*/
					available.source = storylet.toSource()
					return available
				}
				if (available) {
					/*
						Record the highest exclusivity of this passage before adding it to the active storylets array,
						for use below.
					*/
					const excl = p.get(`exclusivity`)
					highestExclusivity = Math.max(highestExclusivity, typeof excl === `number` ? excl : 0)
					active.push(p)
				}
			}
		}, undefined)
		if (error) {
			return error
		}
		/*
			Filter results using the exclusivity restriction.
			Note that passages with no "exclusivity" metadata are treated as exclusivity 0,
			meaning giving a passage negative exclusivity causes all other passages to exclude it.
		*/
		const natSort = NaturalSort(`en`)
		return active.filter(p => {
				let excl = p.get(`exclusivity`)
				excl = typeof excl === `number` ? excl : 0
				return excl === highestExclusivity
			})
			/*
				Sort first by urgency, then by name.
			*/
			.sort((a,b) => {
				let aUrgency = a.get(`urgency`), bUrgency = b.get(`urgency`)
				aUrgency = typeof aUrgency === `number` ? aUrgency : 0
				bUrgency = typeof bUrgency === `number` ? bUrgency : 0
				if (aUrgency !== bUrgency) {
					return bUrgency - aUrgency
				}
				return natSort(a.get(`name`), b.get(`name`))
			})
	},

	/*
		A quick getter that provides every passage with storylet code.
	*/
	allStorylets() {
		if (!storyletCache) {
			storyletCache = [...Passages.values()].filter(e => e.get(`storylet`))
		}
		return storyletCache
	},

	clearStoryletCache() {
		storyletCache = undefined
	},

	/*
		This function finally executes the story's metadata macros and installs the results on the Passages datamap.
		This should only ever be run once by Harlowe.js in an onStartup call, and passed a fully synthetic section.
		Obviously, it needs to run after all of the Passages have been created.
		Worryingly, the ONLY thing that enforces this is that Passages's Utils.onStartup() call happens before Harlowe's
		because Harlowe requires Passages, and Utils.onStartup uses a FIFO stack for the callbacks passed to it.
	*/
	loadMetadata(section: Section) {
		const errors: TwineError[] = []
		/*
			This array stores all of the TwineErrors that resulted from attempting to execute the (metadata:) macros, which
			are then returned as the function's only output.

			Because the order of metadata resolution is author-observable, these must be sorted by name before iteration.
		*/
		for(const p of Array.from(Passages.values()).sort(NaturalSort(`en`, (p: Passage) => p.get(`name`)))) {
			if (!p.metadata) {
				continue
			}
			for(let [name,code] of Object.entries(p.metadata)) {
				/*
					The storylet code is already an error in one situation: when the passage had multiple same-named metadata macro calls in it,
					forcing Renderer to create this error rather than return one call's code.
				*/
				if (code instanceof TwineError) {
					errors.push(code)
					continue
				}
				for (let c of code) {
					const result = section.speculate(c, p.get(`name`), `a (${name}:) macro`)
					const passageErrorOpener = `In "${p.get(`name`)}":\n`
					if (result instanceof TwineError) {
						/*
							As in getStorylets, the error's message is altered to list the passage name of origin, although
							tweaked to account for the leading description in the metadata error dialog.
						*/
						result.message = passageErrorOpener + result.message
						result.source = c.text
						errors.push(result)
						break
					}
					/*
						(define:) metadata is not stored on the passage - speculate() simply loads it into State.definitions as a side-effect.
						Notice that this exit also precludes the error in installResult from arising.
					*/
					if (name === `define`) {
						/*
							After a (define:) call has been processed, add the newly-created definition(s) to the Current moment.
							This allows successive (define:) calls to reference the previous values.
						*/
						State.addDefinitions()
						continue
					}
					/*
						When attaching metadata to the passage datamap, make sure that, for instance, (storylet:) and (metadata: "storylet")
						don't override each other.
						This also indirectly ensures "tags", "name" and "source" are protected data names.
					*/
					const installResult = (k:string,v:unknown) => {
						if (p.has(k)) {
							errors.push(new TwineError(`syntax`, `This passage's datamap already has a '${JSON.stringify(k)}' data name.`))
						}
						else {
							p.set(k,v)
						}
					}
					/*
						The (metadata:) macro emits a Map, whereas other properties like (storylet:) emit single values.
					*/
					result instanceof Map ? result.forEach((v,k) => installResult(k,v)) : installResult(name, result)
				}
			}
			/*
				Having dealt with the metadata, it's now safe to delete it from the passage.
			*/
			p.metadata = undefined
		}
		return errors
	},

	/*
		This provides more data-checking than the built-in "has()".
	*/
	hasValid(this: Map<string, Passage>, name: string) {
		const passageData = this.get(name)
		return !!passageData && (passageData instanceof Map) && passageData.has(`source`)
	},
	
	create: (jq:JQuery) => new Passage(jq),
})

/*
	Unfortunately, the DOM isn't visible until the page is loaded, so we can't
	read every <tw-passagedata> from the <tw-storydata> HTML and store them in Passages until then.
*/
onStartup(() => {
	$(`tw-storydata > tw-passagedata`).get().forEach(E => {
		let e = $(E)
		Passages.set(e.attr(`name`) || ``, new Passage(e))
	})
})

export { Passage, Passages }
