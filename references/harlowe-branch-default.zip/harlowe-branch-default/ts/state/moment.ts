import { Passages } from "../passages.js"
import { VarScope } from "../datatypes.js"
import { Section } from "../section.js"
import { LoadGameError } from "../utils.js"

/*
	Moments store the game state at the START of a turn - global variables, the incoming passage, and so forth.
*/
class Moment {
	/*
		Name for the passage visited this turn.
	*/
	passage = ``
	/*
		This stores the changes to global variables across the timeline.
		State's special scope, CurrentVarScope, synchronises changes to it and the Present
		moment's variables.
	*/
	variables: VarScope
	/*
		This array of strings is only used for (redirect:)s, and represents each passage redirected to during the previous moment.
		These are added to (history:).
		When (forget-undos:) is used, it also holds erased visits.
	*/
	declare visits?: string[]

	/*
		Array of past visited passages. This normally appears only on the first moment in the timeline, after (forget-undos:) has erased past turns (and their visits[] arrays.)
		Subarrays represent turns in which (redirect:) was used (and thus multiple passages were visited).
	*/
	declare pastVisits?: (string | string[])[]
	/*
		A number of additional turns which were erased by (forget-undos:).
	*/
	declare turns?: number
	/*
		(seed:) calls produce these stateful changes, which are also recorded.
	*/
	declare seed?:string
	declare seedIter?:number
	/*
		For testing purposes, there needs to be a way to "mock" having visited certain passages a certain number of times.
		Because (mock-visits:) and (mock-turns:) calls should be considered modal, and can be undone, their effects need to be tied
		to the variable store.
	*/
	declare mockVisits?:string[]
	declare mockTurns?:number
	/*
		When (forget-visits:) is used, the preceding turns' (before the forgetVisits number) visits are to be ignored from now on.
	*/
	declare forgetVisits?:number

	constructor(p = ``,
			/*
				Constructors can pass in alternative VarScopes. This is currently only used during deserialise().
			*/
			variables = new VarScope(
				/*
					This name should never be displayed.
				*/
				`a past turn's variables`,
				`global`
			)) {
		this.passage = p
		this.variables = variables
	}

	/*
		This is used to flatten a timeline into a single moment, which is either the Current game state,
		or a past moment (for forgetUndos).

		Assumption: this always flattens onto a single moment at the "end" of the array of moments.
	*/
	flatten(timeline: Moment[]) {
		/*
			An array for gathering the VarScopes of each Moment, before flattening them all later.
		*/
		const pastVarScopes: VarScope[] = []
		/*
			flatten() changes this moment into the new "first" moment in the timeline.
			Only the "first" moment should have pastVisits and turns (which reflect visits and turns from erased Moments).

			forgetVisits is currently (Jan 2024) managed by State.forgetUndos() after this flatten() call finishes.
		*/
		this.forgetVisits = 0
		this.turns = 0
		this.pastVisits = []
		/*
			This iterates backwards through the timeline, adding missing variables to the flat dest moment.
		*/
		for (let i = timeline.length - 1; i >= 0; i -= 1) {
			const moment = timeline[i]
			/*
				mockVisits, mockTurns, seedIter and seed overshadow previous turns' values.
				Thus, since this loop iterates in reverse order, the most recent turn's assigment to them
				should "stick" through all the loops.
			*/
			for (let name of <(keyof MomentSerialised)[]>[`mockVisits`,`mockTurns`,`seed`,`seedIter`]) {
				name in moment && this[name] === undefined && (this[name] = moment[name])
			}
			moment.forgetVisits && (this.forgetVisits = Math.max(this.forgetVisits, moment.forgetVisits))
			/*
				These, however, are cumulative across turns.
			*/
			moment.turns !== undefined && (this.turns += moment.turns)
			/*
				"visits" only refers to past visits, such as those given to (history:),
				so the final moment's passage name shouldn't be included.
			*/
			if (i !== timeline.length-1) {
				/*
					If the next moment had visits, then that means this moment has redirects.
					So, bundle this passage name in with the redirects in the array on the front of pastVisits.
				*/
				if (timeline[i+1].visits !== undefined && Array.isArray(this.pastVisits[0])) {
					this.pastVisits[0].unshift(moment.passage)
				}
				else {
					this.pastVisits.unshift(moment.passage)
				}
			}
			/*
				If a moment has a pastVisits array, then it represents various turns erased with (forget-undos:).
				These go before its own visits (redirects).
			*/
			moment.pastVisits !== undefined && this.pastVisits.unshift(...moment.pastVisits)
			moment.visits !== undefined && this.pastVisits.unshift(moment.visits)

			/*
				Gather each VarScope…
			*/
			pastVarScopes.push(moment.variables)
		}
		/*
			…and then flatten them all into this Moment's VarScope.
		*/
		this.variables.flatten(pastVarScopes)
	}

	/*
		A Moment is considered "empty" for serialisation if no special values or variables are set on it.
	*/
	#isEmpty() {
		return this.visits === undefined
			&& this.turns === undefined
			&& this.mockVisits  === undefined
			&& this.forgetVisits === undefined
			&& this.pastVisits === undefined
			&& this.mockTurns  === undefined
			&& this.seed === undefined
			&& this.seedIter === undefined
			&& Object.keys(this.variables.variableStore).length === 0
	}

	serialise() {
		/*
			Special optimisation: when a Moment has no changed variables, redirects, seeds, or whatever,
			replace it with a string of just the passage name.
		*/
		if (this.#isEmpty()) {
			return this.passage
		}
		return { ...this, variables: this.variables.serialise() }
	}

	static deserialise(obj: MomentSerialised, pastTimeline: Moment[], section:Section) {
		/*
			If it's just a string, uncompress it into a full JSON "moment".
		*/
		if (typeof obj === `string`) {
			if (!Passages.hasValid(obj)) {
				throw new LoadGameError(`The data refers to a passage named \`"${obj}"\`, but it isn't in this story.`)
			}
			return new Moment(obj)
		}
		/*
			Here, we do some brief verification that the remaining moments in the array are
			objects with "passage" and "variables" keys.
		*/
		else if (typeof obj !== `object` || !(`variables` in obj)) {
			throw new LoadGameError(`One of the saved turns is unintelligible.`)
		}
		/*
			Check that the passage name in this moment corresponds to a real passage.
			As this is the most likely issue with invalid save data, this gets a precise message.
		*/
		if (!Passages.hasValid(obj.passage)) {
			throw new LoadGameError(`The data refers to a passage named \`"${obj.passage}"\`, but it isn't in this story.`)
		}
		let ret = new Moment(obj.passage,
			VarScope.deserialise(
				/*
					This name should never be displayed.
				*/
				`a past turn's variables`,
				`global`, obj.variables, pastTimeline.map(e=> e.variables), section)
		)
		for (let prop of <(keyof MomentSerialised)[]>[`turns`,`forgetVisits`,`seed`,`seedIter`,`mockVisits`,`mockTurns`,`visits`,`pastVisits`]) {
			if (prop in obj) {
				ret[prop] = obj[prop]
			}
		}
		return ret
	}
}
type MomentSerialised = ReturnType<typeof Moment.prototype.serialise>

export {Moment,MomentSerialised}
