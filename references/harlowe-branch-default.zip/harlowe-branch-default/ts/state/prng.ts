/*
	mulberry32 by Tommy Ettinger, seeded with MurmurHash3 by Austin Appleby.
	This is seeded with a single character to save space in save files (where this is saved
	alongside the seedIter).
*/
let seedIter: number
let seed: string
const {imul} = Math

function mulberryMurmur32(s = String.fromCodePoint(Date.now()%0x110000), iter=0) {
	seedIter = iter
	seed = s
	let k:number, i = 0, h = 2166136261
	for(; i < s.length; i+=1) {
		k = imul(s.charCodeAt(i), 3432918353)
		k = k << 15 | k >>> 17
		h ^= imul(k, 461845907)
		h = h << 13 | h >>> 19
		h = imul(h, 5) + 3864292196 | 0
	}
	h ^= s.length
	h ^= h >>> 16; h = imul(h, 2246822507)
	h ^= h >>> 13; h = imul(h, 3266489909)
	h ^= h >>> 16
	h = (h >>> 0) + 0x6D2B79F5 * iter
	return () => {
		/*
			So that the seedIter can be properly serialised, each mulberry32 iteration
			increases it even though it's not used in the calculation. (The actual
			PRNG state is stored in h.)
		*/
		seedIter += 1
		let t = h += 0x6D2B79F5
		t = imul(t ^ t >>> 15, t | 1)
		t ^= t + imul(t ^ t >>> 7, t | 61)
		return ((t ^ t >>> 14) >>> 0) / 4294967296
	}
}

let PRNG = mulberryMurmur32()

function setPRNG(seed?: string, seedIter?: number) {
	PRNG = mulberryMurmur32(seed,seedIter)
}

export {
	seedIter,
	seed,
	PRNG,
	setPRNG
}