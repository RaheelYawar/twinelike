import {Passages} from "../passages.js"
import {hash as Hash, LoadGameError} from "../utils.js"
import {Markup} from "../markup/markup.js"
import {Section} from "../section.js"
import {AnyStorable, AnyUnstorable, TwineError, VarScope} from "../datatypes.js"
import { is, objectName, toSource, unstorableValue } from "../utils/operationutils.js"
import { setPRNG } from "./prng.js"

const {lex} = Markup
const {isArray} = Array

type AtRef = {
	at: string
	from: number
	to: number
	/*
		This hash is a primitive error-checking feature.
	*/
	hash: string
	/*
		If PRNG was used to generate this, the seed is stored here.
	*/
	seed?: string
	seedIter?: number
}

type ViaRef = {
	/*
		The "via" string, named after via lambda clauses (but technically distinct), is of the form "it + " and a code expression.
	*/
	via: string
}
/*
	ValueRefs are used to reconstruct large and complicated values
	when loading the save file. The values are saved as references to the story's code
	where the value was originally assigned, so that they can be reconstructed by simply
	re-executing that span of code.

	There are two kinds: "at" ValueRefs, which refer to specific passages' code, and "via" ValueRefs, which
	refer to previous Moments' variables, in cases where data structures are subtly permuted
	across turns.
*/

/*
	This recursively creates the string portion of a modifier ValueRef.
*/
function recursiveModifierRef(oldVal: unknown, newVal: unknown, path:string) {
	const pathPossessive = path === `it` ? `its` : `${path}'s`
	let ret = ``
	if (isArray(newVal) && isArray(oldVal) && newVal.length) {
		/*
			This boolean checks, while the array is being serialised, whether the
			two arrays are equal. If so, then just the path to this array is returned (below).
		*/
		let equal = newVal.length === oldVal.length
		ret = `(a:`
		for(let i = 0; i < newVal.length; i += 1) {
			const v = newVal[i]
			/*
				Identical values are serialiased as either their source, or an "its" index,
				whichever is shorter.
			*/
			if (is(v, oldVal[i])) {
				const source = toSource(v)
				const pathIndex = `${pathPossessive} ${i+1}th`
				ret += `${source.length < pathIndex.length ? source : pathIndex},`
				continue
			}
			equal = false
			const ind = oldVal.indexOf(v)
			/*
				If this value can be found elsewhere in oldVal (potentially suggesting a deletion
				earlier in this array) then try to serialise as an index to that.
			*/
			if (ind > -1) {
				const source = toSource(v)
				const pathIndex = `${pathPossessive} ${ind+1}th`
				ret += `${source.length < pathIndex.length ? source : pathIndex},`
				continue
			}
			ret += `${recursiveModifierRef(oldVal[i], v, `${pathPossessive} ${i+1}th`)},`
		}
		
		if (equal) {
			ret = path
		}
		/*
			This completes the call while also trimming the final ','.
		*/
		else {
			ret = `${ret.slice(0,-1)})`
		}
	}
	else if (newVal instanceof Map && oldVal instanceof Map && newVal.size) {
		let equal = newVal.size === oldVal.size
		ret = `(dm:`
		for(let [k,v] of newVal.entries()) {
			ret += `${toSource(k)},`
			/*
				Identical values are serialiased as either their source, or an "its" index,
				whichever is shorter.
			*/
			if (is(v, oldVal.get(k))) {
				const source = toSource(v)
				const pathIndex = `${pathPossessive} (${toSource(k)})`
				ret += `${source.length < pathIndex.length ? source : pathIndex},`
				continue
			}
			equal = false
			ret += `${recursiveModifierRef(oldVal.get(k),v, `${pathPossessive} (${toSource(k)})`)},`
		}
		if (equal) {
			ret = path
		}
		/*
			This completes the call while also trimming the final ','.
		*/
		else {
			ret = `${ret.slice(0,-1)})`
		}
	}
	else if (newVal instanceof Set && oldVal instanceof Set && newVal.size) {
		/*
			We should do something a little different here… obtain the
			differences between each dataset, and then add or subtract them.
		*/
		const onlyInOld = new Set(), onlyInNew = new Set()
		for (let v of oldVal) {
			if (!newVal.has(v)) {
				onlyInOld.add(v)
			}
		}
		for (let v of newVal) {
			if (!oldVal.has(v)) {
				onlyInNew.add(v)
			}
		}
		if (!onlyInOld.size && !onlyInNew.size) {
			ret = path
		}
		/*
			TODO: a better check than this to see if the valueRef is longer than the string representation?
		*/
		if (onlyInOld.size + onlyInNew.size > newVal.size) {
			ret = toSource(newVal)
		}
		else {
			ret = path + (onlyInNew.size ? `+${toSource(onlyInNew)}` : ``) + (onlyInOld.size ? `-${toSource(onlyInOld)}` : ``)
		}
	}
	/*
		Strings are optimised only if they are appended or prepended versions of the previous string.
	*/
	else if (typeof newVal === `string` && typeof oldVal === `string` && newVal) {
		if (newVal.startsWith(oldVal)) {
			ret = `${path}+${toSource(newVal.slice(oldVal.length))}`
		} else if (newVal.endsWith(oldVal)) {
			ret = `${toSource(newVal.slice(0,newVal.length - oldVal.length))}+${path}`
		}
	}
	if (!ret) {
		/*
			Recursive calls on array values will result in non-Map non-Array values being passed in.
			These should just be serialised to their source.
		*/
		return toSource(newVal)
	}
	return ret
}

class ValueRef {
	at?: string
	from?: number
	to?: number
	hash?: string
	seed?: string
	seedIter?: number
	via?: string

	constructor(obj: ViaRef | AtRef) {
		Object.assign(this, obj)
	}

	/*
		When given two arrays or maps, this attempts to construct a {via} valueRef
		for the new value - a string of Harlowe source with "it" keywords referring to the old value
		used judiciously to save space.
	*/
	static modifierRef(oldVal: unknown, newVal: unknown, path = `it`) {
		let ret = recursiveModifierRef(oldVal, newVal, path)
		/*
			If there was no serialiased string constructed by recursiveModifierRef(), then this
			failed to create a meaningful valueRef. Simply return undefined.
		*/
		return !ret ? undefined : new ValueRef({via:ret})
	}

	isValueRefJSON(obj:unknown) {
		return typeof obj === `object` && obj && (`at` in obj || `via` in obj || `changer` in obj)
	}

	/*
		ValueRefs don't need a serialise() method because they are already serialisable.
	*/

	/*
		This is where ValueRefs are converted back to the values they reference. Their code strings are
		lexed and evaluated using a passed-in dummy Section.
	*/
	static dereference(key:string, value: AtRef | ViaRef, pastTimeline: VarScope[], section:Section): AnyStorable | TwineError {
		/*
			ValueRefs are objects consisting of { at, from, to } plus execution environment.
			whereas normal variables are strings of Harlowe source.

			Note that TypeDefs values can't be serialised as "reconstruct",
			so this check won't do anything unwanted to them.
		*/
		if (`at` in value) {
			const {at,from,to,hash,seed,seedIter} = value
			
			/*
				If the passage was renamed since this save file was saved, throw an error instead of trying
				to find the value somewhere else.
			*/
			if (!Passages.has(at)) {
				throw new LoadGameError(`The data refers to a passage named \`"${at}"\`, but it isn't in this story.`)
			}
			const source = Passages.get(at)!.get(`source`)!
			/*
				If there is a stored hash, check if the definition of the value is indeed in the indicated place.
				First, the hash of the slice of the source is compared to the stored hash.
				If it fails​, iterate all over the passage to find a possible match.
			*/
			let definition = source.slice(from, to)
			if (hash !== undefined) {
				let newFrom = 0
				let len = to - from
				while (Hash(definition).toString(16) !== hash) {
					/*
						If we can't find a matching definition anywhere, throw an error instead of continuing.
					*/
					if (newFrom + len >= source.length) {
						/*
							This message assumes recompileVariables() always operates on global variables.
						*/
						throw new LoadGameError(`The value (or type) of the variable \`$${key}\` couldn't be found in the passage \`"${at}"\`.`)
					}
					/*
						Check every other possible position exhaustively. This is slow, but should only occur in
						cases where save files from older versions of a story are being loaded in a newer version.
					*/
					newFrom += 1
					if (newFrom === from) {
						newFrom += 1
					}
					definition = source.slice(newFrom, newFrom + len)
				}
			}
			/*
				The tokens comprising the value ref are lexed. But, some preprocessing
				(currently, just blockedValues) must be done on them.
			*/
			const tokens = lex(definition, ``, `macro`)
			/*
				If the value contains any number of random features, set the PRNG
				to the state it was at from the start.
				Note that since every recompile consumer resets the PRNG afterward,
				this is safe.
			*/
			if (seed !== undefined && seedIter !== undefined) {
				setPRNG(seed,seedIter)
			}
			const ret = section.eval(tokens)
			/*
				Check that the value can, in fact, be stored in variables.
			*/
			let unstorable: AnyUnstorable
			if ((unstorable = unstorableValue(ret))) {
				throw new LoadGameError(`The data refers to a value that can't be stored in variables (${objectName(unstorable)})`)
			}
			return <AnyStorable | TwineError>ret
		}
		/*
			If this is a 'via' valueRef, then there SHOULD be a previous value for this
			variable in a preceding turn. Retrieve that, and set it to the 'it' value
			for the section.
		*/
		else if (`via` in value) {
			for (let i = pastTimeline.length-1; i >= 0; i -= 1) {
				if (key in pastTimeline[i].variableStore) {
					section.Identifiers.it = pastTimeline[i].variableStore[key] ?? undefined
					break
				}
			}
			let ret = section.eval(lex(value.via, ``, `macro`))
			let unstorable: AnyUnstorable
			if ((unstorable = unstorableValue(ret))) {
				throw new LoadGameError(`The variable data refers to a value that can't be stored in variables (${objectName(unstorable)})`)
			}
			section.Identifiers.it = undefined
			return <AnyStorable | TwineError>ret
		}
		throw new LoadGameError(`The value (or type) of the variable \`$${key}\` was malformed (no "at" or "via" property).`)
	}
}

type ValueRefSerialised = AtRef | ViaRef

export {ValueRef, ValueRefSerialised}