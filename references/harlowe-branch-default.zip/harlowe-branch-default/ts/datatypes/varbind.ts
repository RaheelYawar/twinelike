import $ from "jquery"
import {storyElement} from "../utils.js"
import {objectName} from "../utils/operationutils.js"
import { AnyValue, HarloweValue, UserFacing, VarRef, VarScope } from "../datatypes.js"
import TwineError from "../internaltypes/twineerror.js"
import { Identifiers } from "../section.js"

/*
	VarBinds provide a means for certain UI input macros like (textarea:) to bind changes to their contents
	to a variable.

	They are unobservable - attempts to store them or use them in any other macros must fail.
*/

/*
	Two-way binding macros work by waiting on this event handler, which fires when any variable set is
	performed. This only passes the object and name, as those macros can retrieve the current value
	from their own passed-in VarBind object.
*/
VarRef.on(`set`, (obj, name) => {
	/*
		For a deep data structure (set:), VarRef.on will fire set callbacks for every object in the
		chain: $a's b's c's d to 1 will produce 'set' callbacks for c, b, a and State.variables.
		We only care about the root - false positives created by altering a deep value in a datamap
		neighbouring the actual bound value don't really matter, as the twoWayBindEvent function should
		filter them out.
	*/
	if (obj instanceof VarScope) {
		/*
			Sadly, there isn't quite a more efficient way of sleuthing out every DOM element
			that could be a two-way bound interaction element, beyond a DOM query with an attachable attribute.
		*/
		storyElement.find(`[data-2bind]`).each((_,Elem) => {
			let elem = $(Elem)
			/*
				Retrieve and run the twoWayBindEvent handler, which should've been installed by the macro.
			*/
			const d = elem.data(`twoWayBindEvent`)
			;(typeof d === `function`) && d(elem, obj, name)
		})
	}
})

/*d:
	Bind data

	A few macros that produce interactive elements, like (cycling-link:), have the ability to automatically update a variable whenever the
	player interacts with them. There needs to be a way to specify which variable these will update: simply giving the macro the variable
	itself, such as in `(cycling-link: $hat, "Poker visor", "Beret")`, won't work - the value that's currently inside `$hat` will be given
	instead, as one would expect for every other kind of macro. So, the `bind` keyword is needed to make your intent unambiguous:
	`bind $hat` produces a "bound variable".

	One can bind any kind of variable: story-wide variables like `$morality`, temp variables like `_glance`, and data values and positions
	inside them, like `$diary's 1st's event`. Once bound, the macro's element will set data to it automatically, as if by a series of
	unseen (set:)s or (move:)s.

	Two-way binds, created by the `2bind` syntax, enforce an equality that normal binds do not: whenever the variable changes outside
	of the element, such as by an `(event:)` macro, then the interaction element updates to match, if it can. Thus, there are two bindings
	between the data and the element using it: the variable updates when the element changes, and the element updates when the variable changes.

	Note that bound variables can't be (set:) into variables themselves, because there's no real point to doing so (and it could lead to
	a lot of undue confusion).

	| Operator | Purpose | Example
	| --- | --- | ---
	| `bind` | Binds the named variable on the right. | `bind $weapon`, `bind _hat`, `bind $profile's age`
	| `2bind` | Double-binds the named variable on the right. | `2bind $weapon`, `2bind _hat`, `2bind $profile's age`

	If you bind an array's `random` data name (a data name which normally provides a random value) then Harlowe will pick a random position,
	and retain that position for the duration of the bound variable's usage. So, if it picks the 3rd position, the macro using the bound
	variable will be consistently bound to the 3rd position's value.
*/
class VarBind implements HarloweValue, UserFacing<VarBind> {
	declare varRef: VarRef
	declare bind: `one way` | `two way`

	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly unstorable: boolean
	static { Object.assign(this.prototype, {
		/*
			These should normally only appear during type signature error messages.
		*/
		typeID: `varbind`,
		typeName: `a VarBind (bound variable name)`,
		unstorable: true
	})}
	get objectName() {
		return `a ${this.bind} bind to ${this.varRef.toSource()}`
	}

	print() {
		return `\`[A bound variable name]\``
	}

	toSource() {
		return `${this.bind === `two way` ? `2` : ``}bind ${this.varRef.toSource()}`
	}

	/*
		Setting a value in a VarBind is fairly straightforward - simply set the varRef, and then pass up any errors.
	*/
	set(value: AnyValue) {
		const result = this.varRef.set(value)
		if (result instanceof TwineError) {
			return result
		}
	}
	
	/*
		bind is either "one way" (the DOM element's first provided value is automatically selected and
		written to the variable) or "two way" (the macro's contained value determines which option in
		the DOM element is initially selected, and continues to affect the DOM element if the variable is remotely
		changed).
	*/
	static create(varRef: AnyValue | TwineError, bind = `one way`) {
		if (varRef instanceof TwineError) {
			return varRef
		}
		const errorExplanation = `Use 'bind' with variables like $this, or temp variables like _this.`
		/*
			Produce a user-facing error if a non-varRef was given.
			Since "bind" is just another operator, this can't be picked up in compilation until now.
		*/
		if (!(varRef instanceof VarRef)) {
			return new TwineError(`operation`, `I can only 'bind' a variable, not ${objectName(varRef)}.`, errorExplanation)
		}
		if (varRef.error) {
			return varRef.error
		}
		/*
			VarRefs can refer to variable, temp variables, or identifiers. Binds obviously can't be performed on the latter.
		*/
		if (varRef.object instanceof Identifiers) {
			return new TwineError(`operation`, `I can't 'bind' identifiers, only variables.`, errorExplanation)
		}
		return new VarBind(varRef, bind)
	}
	private constructor(varRef: VarRef, bind: string) {
		Object.assign(this, { varRef, bind })
	}
}

Object.freeze(VarBind)
Object.freeze(VarBind.prototype)

export default VarBind