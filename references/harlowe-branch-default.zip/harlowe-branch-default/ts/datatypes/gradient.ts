import { Comparable, PropertyContainer, HarloweValue, Measure } from "../datatypes.js"
import {toSource} from "../utils/operationutils.js"
import Colour from './colour.js'

/*d:
	Gradient data

	Gradients are special composite data values which can be provided to (bg:) and (meter:). Much as colour data
	represents a single colour that can be used with (text-colour:) or (bg:), gradients represent
	special computer-generated backgrounds that smoothly transition from one colour on one side, to another colour
	on its other side, with any number of other colours in between.

	For an in-depth description of how to create gradients, see the article for (gradient:).

	Gradients, like colours, have a few data values you can examine, but cannot (set:).

	| Data name | Example | Meaning
	| --- | --- | ---
	| `angle` | `$grad's angle` | The angle, a number from 0 to 359. If a value outside this range was given to `(gradient:)`, this will return that value wrapped to this range.
	| `stops` | `$grad's stops` | An array of the gradient's colour-stops, represented as datamaps. Gradients created by (gradient:) have "percent" and "colour" data names in this datamap. For (stripes:) gradients, "pixels" and "colour" data names appear instead. <br>`(gradient: 90, 0.2, blue, 0.8, white)'s stops` is `(a:(dm: "percent", 0.2, "colour", blue), (dm: "percent", 0.8, "colour", white))`.

	Gradients, when used in passage prose or given to (print:), produce a square swatch containing the gradient. This is a `<tw-colour>`
	element, but otherwise has no other features or capabilities and is intended solely for debugging purposes.
*/
type ColourStop = { colour: Colour, stop: Measure | number }

class Gradient implements HarloweValue, PropertyContainer, Comparable<Gradient>
	/*
	TODO: Permit gradients to be added together.
	, Add<Gradient>*/ {
	declare angle: number
	declare stops: ColourStop[]
	declare repeating: boolean

	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly objectName: string
	declare readonly properties: string[]
	static { Object.assign(this.prototype, {
		typeID: `gradient`,
		/*
			These should normally only appear during type signature error messages.
		*/
		typeName: `a gradient`,
		objectName: `a gradient`,
		properties: [`angle`,`stops`],
	})}

	debugName() {
		return `a gradient ${this.print()}`
	}

	getProperty(prop: string) {
		if (prop === `angle`) {
			return this.angle
		}
		if (prop === `stops`) {
			/*
				Possible concern: no error is reported when trying to (set:)
				a deep property of a gradient, such as (set: $grad's stops's (0.1) to blue),
				even though this does nothing.
			*/
			return this.stops.map(stop => new Map<string,number|Measure|Colour>([[this.repeating ? `pixels` : `percent`, stop.stop], [`colour`, stop.colour.clone()]]))
		}
	}

	toSource() {
		return `(gradient:${this.angle},${this.stops.map(stop => `${toSource(stop.stop)},${toSource(stop.colour)}`)})`
	}

	is(other: unknown) {
		return other instanceof Gradient
			&& other.angle === this.angle
			&& other.stops.length === this.stops.length
			&& other.stops.every(({colour, stop}, i) =>
				this.stops[i].stop === stop && this.stops[i].colour.is(colour)
			)
	}

	clone() {
		// We don't really have to clone the gradient's stops objects, because colours
		// should be immutable in user-facing Harlowe code.
		return new Gradient(this.angle, [...this.stops])
	}

	print() {
		return `<tw-colour style='background:${this.toLinearGradientString()}'></tw-colour>`
	}
	// This accepts an integer degree, plus any number of [distance, colour] pairs.
	constructor(angle: number, stops: ColourStop[], repeating = false) {
		Object.assign(this, { angle, stops, repeating })
	}

	/*
		This creates a copy of the gradient, but multiplies the colour stops by the given number.
	*/
	multiply(mul: number) {
		return new Gradient(this.angle, this.stops.map(({colour, stop}: ColourStop) => ({ colour, stop: stop instanceof Measure ? stop[`*`](mul) : stop*mul })))
	}

	/*
		This converts the colour into a CSS linear-gradient() function.
	*/
	toLinearGradientString() {
		return `${this.repeating ? `repeating-` : ``}linear-gradient(${this.angle}deg, ${
			this.stops.reduce((str, {colour,stop}) =>
				`${str + colour.toCSSString()} ${stop instanceof Measure ? stop.toCSSString() : stop*(this.repeating ? 1 : 100) + (this.repeating ? `px` : `%`)},`,
			``).slice(0,-1)
		})`
	}
}

Object.freeze(Gradient)
Object.freeze(Gradient.prototype)

export default Gradient