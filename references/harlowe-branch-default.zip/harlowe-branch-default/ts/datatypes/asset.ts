import { storyElement } from '../utils.js'
import { HarloweValue, Gradient, Colour } from '../datatypes.js'
import State from '../state.js'
import { toSource } from '../utils/operationutils.js'

/*
	Image Assets are asynchronously loaded images from the same or other domains.
*/
/*d:
	Image data

	Images are data values for an entire image in your story, loaded externally via
	the (image:) macro (which can only be used with (define:)).

	Images, while representing important assets to your story, are nonetheless very rigid data that can't be easily changed into different data.
	You cannot, for instance, add them together using `+`, spread them using `...`, put them in a different variable using (put:) or (set:),
	or even store them in an array, dataset or datamap using (a:), (ds:) or (dm:). They can only be used from the variables in which they were
	defined using (define:).

	Variables containing image data (made using (define:)) can be placed in bare passage prose to show the image. Note, however, that this is
	a very basic method of displaying it - various options such as centering and scaling aren't available this way. Images are best used
	when given to other macros to display them.

	Images have the following data values.

	| Data name | Example | Meaning
	| --- | --- | ---
	| `loaded` | `$img's loaded` | `true` if the image has loaded, and `false` otherwise.
	| `failed` | `$img's failed` | `true` if the image cannot load because it failed to download or produce valid image data, and `false` otherwise.

	Harlowe updates these data values in the background while downloading images. These can be used to, for instance, postpone travel to a
	new passage until a certain image has loaded (by something like `(when: $img's loaded)[(goto:"Splash")]`) and doing something else if it fails.
*/
class ImageAsset implements HarloweValue {
	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly objectName: string
	static { Object.assign(this.prototype, {
		typeID: `image`,
		/*
			These should normally only appear during type signature error messages.
		*/
		typeName: `an image`,
		objectName: `an image`,
		properties: [`loaded`, `failed`],
	})}

	getProperty(prop:string) {
		if (prop === `loaded`) {
			return !!this.loaded
		}
		if (prop === `failed`) {
			return !!this.failed
		}
	}

	/*
		URLs to attempt to load. The first one is the main image, and the others are fallbacks/mirrors.
	*/
	urls: string[]
	/*
		The final fallback if all URLs fail - a gradient.
		TODO: Make it possible for this to also be an embedded image when/if those are implemented.
	*/
	fallback?: Gradient | Colour
	/*
		When truthy, this is the blob URL of the image that was loaded.
	*/
	loaded: string | false
	/*
		When truthy, this is the reason that loading failed, as a user-facing message.
	*/
	failed: string | false
	/*
		When this image BEGINS downloading, this value becomes true. It then never returns to false,
		because images should not be downloaded twice.
	*/
	#loading: boolean

	/*
		knownName is added by (define:), and provides a Harlowe path into the defined variable holding this asset, such as `$cg's 1st`.
		This is used to serialise the asset, if it was copied into a normal variable using (set:) - because the definitions are always constant across save files, this path is stable.
	*/
	knownName?: string

	/*
		TODO: Make it so that this toSource() call returns the knownName ONLY when serialising a saved game,
		and for (source:) it returns the actual source.
	*/
	toSource() {
		return this.knownName ??
			`(image:${toSource(this.urls)}${this.fallback ? `, ${toSource(this.fallback)}` : ``})`
	}

	/*
		Individual image assets are immutable.
	*/
	clone() {
		return this
	}

	/*
		This is a very basic display method which doesn't take into account e.g. what size to make the fallback.
	*/
	print() {
		if (this.loaded) {
			return `<img src='${this.loaded}'></img>`
		}
		return this.fallback?.print() || ``
	}

	/*
		A quick way to get the fallback CSS for this image, for use as a background. Used by (pic:) (March 2025).
	*/
	fallbackCSS() {
		let { fallback } = this
		return fallback ? fallback instanceof Gradient ? fallback.toLinearGradientString() : fallback.toCSSString() : ``
	}

	constructor(urls: string[], fallback?: Gradient | Colour) {
		this.urls = urls
		this.fallback = fallback
		this.failed = false
		this.loaded = false
		this.#loading = false
	}

	async #fetch() {
		let attemptedURLs = this.urls.slice()
		while(attemptedURLs.length > 0) {
			let url = attemptedURLs.shift()!
			try {
				this.#loading = true
				//eslint-disable-next-line no-await-in-loop
				let response = await window.fetch(url)
				try {
					//eslint-disable-next-line no-await-in-loop
					let blob = await response.blob()
					this.loaded = URL.createObjectURL(blob)
					this.failed = false
					/*
						Since this image has loaded, find all [data-img-fallback] elements and run their imageLoadEvent.
						This once again uses the less elegant "event triggering" (DOM data attributes as labels) that twoWayBindEvent() uses.
					*/
					storyElement.find(`[data-img-fallback]`).each((_, Elem) => {
						const elem = $(Elem)
						const d = elem.data(`imageLoadEvent`)
						;(typeof d === `function`) && d(elem, this)
					})
					return true
				}
				catch(_) {
					this.failed = `The image file at "${url}" couldn't be decoded.`
				}
			}
			catch(_) {
				this.failed = `The image URL "${url}" failed to resolve.`
			}
		}
		return false
	}

	/*
		All asset classes have a loadAssets() static method which is ONLY called by Harlowe.js at startup time.
	*/
	static loadAssets() {
		for (let e of Object.values(State.definitions.variableStore)) {
			if (e instanceof ImageAsset && !e.#loading) {
				e.#fetch()
			}
		}
	}
}

export { ImageAsset }