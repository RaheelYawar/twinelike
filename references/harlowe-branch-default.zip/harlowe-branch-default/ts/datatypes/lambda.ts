import {objectName, unstorableValue} from "../utils/operationutils.js"
import { AnyToken } from "../markup/markup.js"
import { EvalReplayFrame, Section } from "../section.js"
import { VarRef, VarScope, TypedVar, TwineError, AnyValue, AnyStorable, HarloweValue, Comparable } from "../datatypes.js"

/*d:
	Lambda data

	Suppose you want to do a complicated task with an array, like, say, convert all of its strings to lowercase,
	or check if its datamaps have "health" data equal to 0, or join all of its strings together
	into a single string. You want to be able to tell Harlowe to search for "each string where the string's 1st
	letter is A". You want to write a "function" for how the search is to be conducted.

	Lambdas are user-created functions that let you tell certain macros, like (find:), (altered:) and (folded:),
	precisely how to search, alter, or combine the data provided to them. Try thinking of them as stored expressions that
	operate on a single value in the sequence of data, which are then run on every value in turn.

	There are several types of lambdas, as well as lambdas that comprise multiple types.

	* **"where"** lambdas, used by the (find:) macro, are used to search for and filter data. The lambda `_item where _item's 1st is "A"`
	tells the macro to searches for items whose `1st` is the string "A".
	
	* For certain macros, like (for:), you may want to use a "where" lambda that doesn't filter out any of the values -
	`_item where true`, for instance, will include every item. There is a special, more readable **"each"** shorthand for this type
	of "where" lambda: writing just `each _item` is equivalent.

	* **"when"** lambdas are a variant of "where" used exclusively by (event:) and (storylet:), and are used to specify when a hook or passage should
	be shown. The lambda `when $fuel > 8` tells (event:) to show the attached hook when `$fuel` is increased (due to an interaction macro
	like (link-repeat:), a (live:) macro, or anything else). This really shouln't be called a "lambda", but you can perhaps think of it in
	terms of it filtering moments in time that pass or fail the condition.

	* **"via"** lambdas, used by the (altered:) and (sorted:) macro, are used to translate or change data. The lambda `_item via _item + "s"`
	tells the macro to add the string "s" to the end of each item. Only the (altered:) macro uses this to change values: the (sorted:)
	macro uses this to sort the data value as if it was another value.
	
	* **"making"** lambdas, used by the (folded:) are used to build or "make" a single data value by adding something from
	each item to it. The lambda `_item making _total via _total + (max: _item, 0)` tells the macro to add each item to
	the total, but only if the item is greater than 0. (Incidentally, you can also use "where" inside a "making" lambda -
	you could rewrite that lambda as `_item making _total via _total + _item where _item > 0`.)

	Lambdas use temp variables to hold the actual values. For instance, in `(find: _num where _num > 2, 5,6,0)`,
	the temp variable `_num` is used to mean each individual value given to the macro, in turn. It will be 5, 6 and 0, respectively.
	Importantly, this will *not* alter any existing temp variable called `_num` - the inside of a lambda can be thought
	of as a hook, so just as the inner `_x` in `(set: _x to 1) |a>[ (set:_x to 2) ]` is different from the outer `_x`, the `_num` in the
	lambda will not affect any other `_num`.

	If you want to be extra watchful for errors and mistyped data (and if you're working on a big project, you should!), you can include a datatype
	with each variable, such as by writing `str-type _a where _a contains 'e'` instead of `_a where _a contains 'e'`, to make it a TypedVar.
	You may notice that `_a contains 'e'` would also be true if `_a` was `(a:'e')` rather than, as intended, a string. Adding `str-type`
	allows such an error to be found and reported early, and results in a less confusing error message.

	You can use the "it" shorthand to save on having to write the temporary variable's name multiple times.
	`_num where _num > 2` can be rewritten as`_num where it > 2`. Not only that, but you can even save on naming the temporary
	variable at all, by just using `where` (or `via` or `making`) without the name and only using `it` to refer to the variable: `where it > 2`.

	Additionally, the "pos" identifier can be used inside a lambda - it evaluates to the position of the data value (from those passed into
	the macro) that the lambda is currently processing. `(altered: via it + (str:pos), "A", "B", "C", "A")` produces `(a:"A1","B2","C3","A4")`.

	An important feature is that you can save lambdas into variables, and reuse them in your story easily. You
	could, for instance, `(set: $statsReadout to (_stat making _readout via _readout + "|" + _stat's name + ":" + _stat's value))`,
	and then use $printStats with the (folded:) macro in different places, such as `(folded: $statsReadout, ...(dm-entries: $playerStats))`
	for displaying the player's stats, `(folded: $statsReadout, ...(dm-entries: $monsterStats))` for a monster's stats, etc.

	Lambdas are named after the lambda calculus, and the ["lambda"](https://en.wikipedia.org/wiki/Anonymous_function) keyword used in many popular programming languages.
	They may seem complicated, but as long as you think of them as just a special way of writing a repeating instruction,
	and understand how their macros work, you may find that they are very convenient.
*/
const {setPrototypeOf,assign,freeze} = Object

/*
	`loop` refers to lambdas with no `each` clause
*/
type ClauseType = `making`|`via`|`where`|`when`|`each`
/*
	The only user-produced value which is passed into this operation is the bool -
	the passVal and failVal are internally supplied.
*/
function where(bool: unknown, passVal: AnyValue | TwineError, failVal: AnyValue | TwineError | null) {
	if (bool instanceof TwineError) {
		return bool
	}
	if (typeof bool !== `boolean`) {
		return new TwineError(`operation`,
			`This lambda's 'where' clause must evaluate to true or false, not ${objectName(bool)}.`)
	}
	return bool ? passVal : failVal
}

/*
	This function assigns the value for a variable for an apply() iteration, and retrieves any
	type errors resulting from it (if the variable was typed).
*/
function setArgument(tempVariables: VarScope, variable: VarRef | TypedVar, arg: AnyStorable) {
	if (variable) {
		/*
			If the variable is a typed variable, then we perform a more formal defineType() and set() call to assign it to the scope.
		*/
		if (variable instanceof TypedVar) {
			/*
				Create VarRef.creates that use this tempVariable scope as a base.
			*/
			const ref = VarRef.create(tempVariables, variable.varRef.propertyChain)
			if (ref instanceof TwineError) {
				return ref
			}
			let error = ref.defineType(variable.datatype)
			if (error instanceof TwineError) {
				return error
			}
			error = ref.set(arg)
			if (error instanceof TwineError) {
				return error
			}
		}
		else {
			// Because the passed-in variable will always be one of a lambda's `making`, `each` or `loop` vars,
			// it is safe to assume this variable's base will always be a VarScope, and thus that its
			// name will always be a string.
			tempVariables.set(variable.getName(),arg)
		}
	}
}

class Lambda implements HarloweValue, Comparable<Lambda> {
	declare where?: AnyToken[]
	declare when?: AnyToken[]
	declare via?: AnyToken[]
	declare making?: VarRef | TypedVar
	declare each?: VarRef | TypedVar
	source: string
	/*
		A `loop` lambda is one created implicitly by placing a non-each lambda next to a VarRef or TypedVar.
		For instance: in ( _e via _e + 1 ), _e is changed into a `loop` lambda.
	*/
	loop?: VarRef | TypedVar

	declare readonly typeID: string
	declare readonly typeName: string
	static { Object.assign(this.prototype, {
		typeID: `lambda`,
		typeName: `a lambda`,
	})}

	get objectName() {
		return `a "${(`making` in this) ? `making ... ` : ``
			}${(`each` in this) ? `each ... ` : ``
			}${(`where` in this) ? `where ... ` : ``
			}${(`when` in this) ? `when ... ` : ``
			}${(`via` in this) ? `via ... ` : ``
			}" lambda`
	}

	print() {
		// TODO: Make this string more detailed.
		return `\`[A lambda]\``
	}

	is(other: unknown) {
		/*
			Lambdas are equal if their body is equivalent given parameter renaming
			(a.k.a. alpha equivalence)
			TODO: Implement the above.
		*/
		return other === this
	}

	/*
		Lambdas store their entire source entirely for the purposes to ToSource,
		as decompiling the JS of their clauses is too difficult.
	*/
	toSource() {
		return this.source
	}

	/*
		This static method is used exclusively to produce type signature objects for use by
		macro definitions in macrolib. Specifically, it lets us specify which clauses a macro
		expects its lambda to have.
	*/
	static TypeSignature(...clauses: ClauseType[]) {
		return {
			pattern: `lambda`, innerType: Lambda, clauses,
			typeName: `a "${
					// This concat() causes a trailing ... to be added to the end of the clauses.
					(<string[]>clauses).concat(``).join(` ...`)
				}" lambda`,
		} as const
	}

	/*
		I assume this is sufficient... despite their being a lot of data structures
		attached to a lambda, including other lambdas, none of those should
		be user-accessible.
	*/
	clone() {
		/*
			The array properties (where, when) don't need to be cloned because they are
			never mutated.
		*/
		return setPrototypeOf({...this},Lambda.prototype)
	}

	/*
		This function quickly checks that a variable object (either subject or 'making' clause) given to this lambda is valid.
	*/
	static #validVariable(subject: unknown) {
		/*
			If the subject is a typed variable, then pull out its variable. Otherwise, use the subject itself.
		*/
		const variable = subject instanceof TypedVar ? subject.varRef : subject
		return variable === undefined ||
			(variable && (variable instanceof VarRef)
			// It must be a temp variable...
			&& (variable.object instanceof VarScope && variable.object.type === `temp`)
			// ...and not a property access on one.
			&& variable.propertyChain.length === 1)
	}
	/*
		Performs error-checking of the constructor parameters before constructing a Lambda.
		TODO: Write different signatures for this based on the clauseType.
	*/
	static create(subject: unknown, clauseType: ClauseType, clause: AnyToken[] | VarRef | TypedVar | undefined, source:string): TwineError | Lambda {
		const tempVariableMsg = `temp variable, or typed temp variable`
		if (TwineError.containsError(subject)) {
			return <TwineError>subject
		}
		if (clauseType === `making` && !Lambda.#validVariable(clause)) {
			return new TwineError(`syntax`,`I need a ${tempVariableMsg}, to the right of '${clauseType}', not ${objectName(clause)}.`)
		}
		else if (subject instanceof Lambda) {
			/*
				"when" is a special variant of "where" that can't be joined with any other clauses.
			*/
			if (clauseType === `when` || `when` in subject) {
				return new TwineError(`syntax`, `A 'when' lambda cannot have any other clauses, such as '${clauseType}'.`)
			}
			/*
				An error only identifiable while adding clauses:
				two of one clause (such as "where _a > 2 where _b < 2") is a mistake.
			*/
			if (clauseType in subject) {
				return new TwineError(`syntax`, `This lambda has two '${clauseType}' clauses.`)
			}
		}
		else {
			/*
				"when" is a special variant that, for readability, shouldn't have a subject.
			*/
			if (clauseType === `when` && subject !== undefined) {
				return new TwineError(`syntax`,
					`A 'when' lambda shouldn't begin with a temp variable (just use 'when' followed by the condition).`)
			}

			if (!Lambda.#validVariable(subject)) {
				return new TwineError(`syntax`, `This lambda needs to start with a single ${tempVariableMsg}, not ${objectName(subject)}.`)
			}
		}
		const loopVar = subject instanceof Lambda ? subject.loop?.getName() :
			// This assertion is based on the #validVariable() check above
			(<TypedVar | VarRef | undefined>subject)?.getName() || ``
		const varClause = clause instanceof VarRef || clause instanceof TypedVar
		/*
			The "making" or "loop" variables' names must always be unique.
			Note: like regular variables, temp variables are not case-insensitive.
		*/
		const nonunique = clauseType === `making` && varClause && clause.getName() === loopVar
		
		if (nonunique) {
			return new TwineError(`syntax`, `This lambda has two variables named '${clause.getName()}'.`,
				`Lambdas should have all-unique parameter names.`)
		}

		return new Lambda(<Lambda | VarRef | TypedVar>subject, clauseType, clause, source)
	}

	/*
		Because this checks for and returns TwineErrors,
		this create() method must be used instead of new Lambda().

		Lambdas consist of five clauses: the loop variable, the 'making' variable,
		the 'where' clause (and its special 'when' variant), and the 'via' clause.

		Lambdas are constructed by joining one of these clauses with a subject (which is either another
		lambda - thus adding their clauses - or a temp variable or typed variable).
		{subject} A VarRef, TypedVar, undefined, or Lambda (hopefully)
		{clauseType} 'making', 'via', 'where', 'when' or 'each'
		{clause} An array of tokens OR a VarRef
		{source} Harlowe source code
	*/
	private constructor(subject: Lambda | VarRef | TypedVar | undefined, clauseType: ClauseType, clause: AnyToken[] | VarRef | TypedVar | undefined, source: string) {
		/*
			If the subject is another lambda (as consecutive clauses compile to nested
			Operations.createLambda() calls), copy its clauses to this one.
		*/
		if (subject instanceof Lambda) {
			assign(this, subject)
		}
		else {
			/*
				If the subject is a temporary variable, typed variable, or undefined, create a fresh
				lambda object with only a "loop" property.
			*/
			this.loop = subject
		}
		/*
			The outermost Operations.createLambda() call contains the source of the "full" lambda,
			so it's OK to overwrite subject's source with whatever is passed in.
		*/
		this.source = source.trim()
		this[clauseType] = <(VarRef | TypedVar | undefined) & AnyToken[]>clause
	}
	/*
		Macros call this method to apply the lambda to a series of provided values.
		This needs to have the macro's section passed in so that its JS code can be eval()'d in
		the correct scope.
	*/
	apply(section: Section, {
				loop:loopArg, pos:lambdaPos /*This must be 1-indexed*/, making:makingArg = undefined, ignoreVia = false, tempVariables = undefined
			}: { loop?: AnyValue, pos: number, making?: AnyStorable, ignoreVia?: boolean, tempVariables?: VarScope}) {

		if ((this.making && makingArg === undefined) || (this.loop && loopArg === undefined)) {
			let name = this.loop ? `loop` : `making`
			throw Error(`"${name}" lambda was given no ${name}Arg: ${this.toSource()}`)
		}
		/*
			We run the JS code of this lambda, inserting the arguments by adding them to a tempVariables
			object (if one wasn't provided). The temporary variable references in the code are compiled to
			VarRefs for tempVariables.
		*/
		tempVariables ||= new VarScope(`this lambda's temp variables`, `temp`, section.stack.length ? section.stackTop.tempVariables : null)

		/*
			Every macro consumer that gives unstorable values to .apply() only accepts `via` lambdas with no `each` clause.
		*/
		if (this.loop && unstorableValue(loopArg)) {
			throw Error(`Loop lambda was given an unstorable value ${objectName(loopArg)}`)
		}
		// Assertion is based on the unstorableValue() check just above.
		let error = this.loop && setArgument(tempVariables, this.loop, <AnyStorable>loopArg)
		if (error instanceof TwineError) {
			return error
		}
		// Assertion is based on the `makingArg` check above.
		error = this.making && setArgument(tempVariables, this.making, makingArg!)
		if (error instanceof TwineError) {
			return error
		}

		/*
			The stackTop, if it exists, may have a speculativePassage or something
			else that alters the semantics of identifiers inside the lambda (like 'visits'), and so
			instead, the lambda's stack inherits those values from it.
		*/
		section.stack.unshift(setPrototypeOf({
			tempVariables,
			/*
				"pos" is not used for "when" lambdas.
			*/
			lambdaPos: !this.when ? lambdaPos : undefined,
		}, section.stackTop || null))

		/*
			If this lambda has no "making" clauses (and isn't a "when" lambda), then the "it"
			keyword is set to the loop arg. Note that this doesn't require the presence of
			this.loop - if it is omitted, then you can only access the loop var in the "where"
			clause using "it".
		*/
		if (loopArg !== undefined && !this.making && !this.when) {
			section.Identifiers.it = loopArg
		}
		/*
			Otherwise, stuff the "it" value with a special error message that should propagate up
			if "it" is ever used inside this macro.
		*/
		else {
			section.Identifiers.it = new TwineError(`operation`,
				`I can't use 'it', or an implied 'it', in ${this.objectName}`
			)
		}

		/*
			At the start of a "making via where" lambda, we must filter out the values that fail
			the "where" clause, without running the "via" clause at all. So, ignoreVia is used by filter()
			to signify that this must be done.
		*/
		const via = !ignoreVia && this.via
		const hasWhere = `where` in this || `when` in this

		/*
			Cache the evalReplay of section, so that the eval() doesn't clobber it.
		*/
		const {evalReplay: originalReplay} = section
		section.evalReplay = originalReplay ? [] : undefined

		/*
			These are used to store separate replays for both the "where" lambda execution, and the "via"
			lambda execution.
		*/
		let ret: AnyValue | TwineError | null
		let whereResult: boolean
		let whereReplay: EvalReplayFrame[] | undefined, viaReplay: EvalReplayFrame[] | undefined
		/*
			If a lambda has a "where" (or "when") clause, then the "where" clause filters out
			values. Filtered-out values are replaced by null (which .apply() consumers should handle themselves).
			If a lambda has a "via" clause, then its result becomes the result of the
			call. Otherwise, true is returned.
		*/
		if (hasWhere) {
			/*
				hasWhere should be enough to guarantee where and when have proper values.
			*/
			whereResult = <boolean>section.eval(<AnyToken[]>(this.where || this.when))
			/*
				Save the replay array generated by this eval(), and make a new array in preparation for the via eval() below.
			*/
			whereReplay = section.evalReplay
			section.evalReplay = whereReplay && via ? [] : undefined
			/*
				Reinstate the value of the 'it' identifier if it was permuted by the above eval()
			*/
			if (loopArg && !this.making && !this.when) {
				section.Identifiers.it = loopArg
			}
			ret = where(whereResult, via ? section.eval(via) : true, null)
		}
		else {
			whereResult = ret = via ? <boolean>section.eval(via) : true
		}
		viaReplay = via ? section.evalReplay : undefined

		/*
			Having finished running eval(), pop the lambda's stack.
		*/
		section.stack.shift()
		/*
			All that being done, we now swap the section's evalReplay back.
		*/
		section.evalReplay = originalReplay
		/*
			Create a lambda replay frame only if this lambda has 'where' or 'via' clauses (which would contain analysable computation).
		*/
		if (originalReplay && (hasWhere || via)) {
			/*
				This creates a special "lambda replay frame" which contains a table of loops and results.
			*/
			let last = originalReplay[originalReplay.length-1]
			/*
				Subsequent loops of the lambda reuse the same replay frame, IF it's the same lambda.
			*/
			if (!last.lambda || last.lambda?.obj !== this) {
				const code = originalReplay[originalReplay.length-1]?.code || ``
				last = {
					lambda: {
						obj: this,
						loops: [],
					},
					/*
						Since this doesn't alter the structure of the interpreted code, reuse the previous replay frame's code.
					*/
					code,
					fromCode: code,
					/*
						These three are included purely for type-completeness.
					*/
					start: 0,
					end: code.length,
					diff: 0,
				}
				originalReplay.push(last)
			}
			/*
				Populate the (now) existing lambda replay frame with the results of this loop.
			*/
			// The block above asserts that last.lambda exists.
			last.lambda!.loops.push({it: loopArg,
					/*
						The pos needs to be stored, too, just in case it's different from what one might expect
						(as is the case for (folded:) lambdas).
					*/
					pos: lambdaPos,
				...makingArg !== undefined && { making: makingArg },
				...via && { viaReplay, viaResult: ret },
				...hasWhere && { whereReplay, whereResult: whereResult === null ? false : whereResult },
			})
		}
		return ret
	}

	/*
		This convenience function is used to run reduce() on macro args using a lambda,
		which is an operation common to (find:), (all-pass:) and (some-pass:).

		tempVariables is only overridden by certain deferred rendering macros (as of Sep 2018, just (event:)).
	*/
	filter<T extends AnyStorable>(section: Section, args:T[], tempVariables?: VarScope) {
		return args.reduce((result: T[] | TwineError, arg, pos) => {
			/*
				If the previous iteration produced an error, don't run any more computations and just return.
			*/
			if (result instanceof TwineError) {
				return result
			}
			/*
				Run the lambda, to determine whether to filter out this element.
			*/
			const passedFilter = this.apply(section, {loop:arg, pos:pos+1, ignoreVia:true, tempVariables})
			if (passedFilter instanceof TwineError) {
				return passedFilter
			}
			return result.concat(passedFilter ? [arg] : [])
		}, [])
	}
}

freeze(Lambda)
freeze(Lambda.prototype)

export default Lambda