import {typeName, matches, toSource, unstorableValue, clone} from "../utils/operationutils.js"
import { Datatype, VarRef, TwineError, VarScope, AnyValue, AnyStorable, HarloweValue, PropertyContainer, Typelike } from "../datatypes.js"

const {freeze,assign} = Object
/*d:
	TypedVar data

	Typed variable names combine a datatype or a pattern of data, and the name of a variable, joined by adding the `-type` suffix to the datatype. `str-type _name` defines
	a typed variable, _name, which can only be set to a string. `(a: num)-type $a` defines a typed variable, $a, which can only be set to an array with 1 number value inside.

	Typed variable names are used in several places – (set:), (put:), (move:) and (unpack:) can be given typed variables in place of normal variables to restrict that variable
	to the given type, and ensure all future uses of that variable maintain that restriction. Typed variables are also used by the (macro:) macro to specify
	the input data for your custom macros, and ensure users of that macro maintain those restrictions. The (str-find:) and (str-replaced:) macros allows typed variables to be used
	inside string patterns, to give names to sub-matches in the string being searched. Finally, typed temp variables can be used in lambdas, to guarantee that the
	lambda is being used with the correct type of data.

	The ability to restrict the type of data that your variables and custom macros receive is a great assistance in debugging your stories,
	as well as understanding what the variable or macro is and does - especially if they were written by someone else and imported into the project.

	TypedVars used with the (macro:) macro support an additional feature. When a TypedVar is a plain datatype name preceded with the `...` spread operator, such as in `...str-type _a`,
	then it becomes a spread typed variable, which represents an arbitrary number of values. Giving multiple values of the given type at or after such a position will cause an array
	containing those values to be put into the named variable.
	
	Typed variables, when retrieved from a custom macro's "params" array, have two data names that you can examine.

	| Data name | Example | Meaning
	| --- | --- | ---
	| `name` | `$customMac's params's 1st's name`, `name of 1st of params of $customMac` | The name of the typed variable. `(num-type _grains)'s name` is `"grains"`.
	| `datatype` | `$customMac's params's 1st's datatype`, `datatype of 1st of params of $customMac` | The datatype of the typed variable. `(num-type _grains)'s datatype` is `num`.

	For more details, consult the (set:) and (macro:) articles.
*/
class TypedVar implements HarloweValue, PropertyContainer, Typelike<TypedVar> {
	declare datatype: AnyStorable
	declare varRef: VarRef

	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly unstorable: boolean
	declare readonly properties: string[]
	static { Object.assign(this.prototype, {
		typeID: `typedvar`,
		/*
			These should normally only appear during type signature error messages.
		*/
		typeName: `a TypedVar (typed variable name)`,
		unstorable: true,
		properties: [`datatype`, `name`],
	})}
	get objectName() {
		const typeSource = toSource(this.datatype)
		return `the ${typeSource.length < 24 ? `${typeSource}-` : ``}typed variable name, ${this.varRef.toSource()}`
	}

	print() {
		return `\`[A typed variable name]\``
	}

	/*
		Typed variables are immutable data.
	*/
	clone() {
		return new TypedVar(
			clone(this.datatype),
			this.varRef,
		)
	}

	toSource() {
		/*
			This must use toSource(), as the datatype could be a data pattern, such as an array.
		*/
		return `${toSource(this.datatype)}-type ${this.varRef.toSource()}`
	}
	getProperty(prop:string) {
		/*
			The properties array (above) ensures only two properties are accessible.
		*/
		return prop === `name` ? this.getName() : this.datatype
	}
	/*
		The presence of this property allows TypedVars to be used in "matches" patterns.
	*/
	isTypeOf(val: unknown) {
		return matches(this.datatype, val)
	}

	/*
		This is currently (Jul 2024) not used for anything.
	*/
	toTypeSignatureObject() {
		if (this.datatype instanceof Datatype) {
			return this.datatype.toTypeSignatureObject()
		}
		/*
			The "matches" pattern exclusively exists to represent TypedVars' type restrictions.
		*/
		return {
			pattern: `matches`,
			value: this.datatype
		} as const
	}

	/*
		The compiler requires that TypedVars, which can be used in place of an ordinary VarRef in a (set:) call, also have
		a get() method (for setting the It identifier).
	*/
	get() {
		return this.varRef.get()
	}
	/*
		Sharing a getName() interface with varRef allows TypedVars to be interchangeable with VarRefs when used in lambdas
		and other places.
	*/
	getName() {
		/*
			As this is a TypedVar, the VarRef's base should be a VarScope.
		*/
		return this.varRef.getName()
	}

	/*
		A convenience method that allows a TypedVar to directly define the type for its variable.
	*/
	defineType() {
		if (this.datatype instanceof Datatype && this.datatype.name !== `any`) {
			return this.varRef.defineType(this.datatype)
		}
	}

	/*
		This performs a few type-checks that must be run before creating a new TypedVar.
	*/
	static create(datatype: AnyValue, varRef: VarRef) {
		/*
			Errors caught during compiling (and converted to TwineError instantiations) should be returned
			here.
		*/
		let error: TwineError | false | undefined
		if ((error = TwineError.containsError(datatype) ||
				/*
					This handles wrapped VarRef errors (those created by VarRef.create()).
				*/
				varRef.error)) {
			return error
		}
		if (varRef instanceof TwineError) {
			return varRef
		}
		/*
			TODO: Should this check even be here, or in runtime?
		*/
		if (!(varRef instanceof VarRef)) {
			return new TwineError(`syntax`, `The -type syntax must have a variable to its right.`)
		}
		const {object, compiledPropertyChain} = varRef
		if (!object || !(object instanceof VarScope) || compiledPropertyChain.length !== 1 || !object.typeDefs) {
			return new TwineError(`unimplemented`, `I can only restrict the datatypes of variables, not data names or anything else.`)
		}
		/*
			TypedVars can only have storable data as datatypes, like "(a:num,num)-type $a". The exception is, of course, structures containing TypedVars
			themselves, such as (p: "Red", alnum-type _a), which should still be permitted.
		*/
		const unstorable = unstorableValue(datatype)
		if (unstorable && !(unstorable instanceof TypedVar)) {
			return new TwineError(`syntax`, `The -type syntax can't have ${typeName(unstorable)} to its left.`)
		}
		// Assertion is based on the unstorableValue() check above.
		return new TypedVar(<AnyStorable>datatype, varRef)
	}

	private constructor(datatype: AnyStorable, varRef: VarRef) {
		assign(this, {
			datatype,
			varRef,
		})
	}
}

freeze(TypedVar)
freeze(TypedVar.prototype)

export default TypedVar