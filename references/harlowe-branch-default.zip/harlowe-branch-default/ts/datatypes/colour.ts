import { Add, Comparable, PropertyContainer, HarloweValue } from "../datatypes.js"
import $ from "jquery"
/*d:
	Colour data

	Colours are special data values which can be provided to certain styling macros, such as (bg:)
	or (text-colour:). You can use built-in named colour values, or create other colours using the
	(rgb:) or (hsl:) macros.

	The built-in values consist of the following:

	| Value | HTML colour equivalent
	| --- | ---
	| `red` | <span style='background:#e61919;color:black'>#e61919</span>
	| `orange` | <span style='background:#e68019;color:black'>#e68019</span>
	| `yellow` | <span style='background:#e5e619;color:black'>#e5e619</span>
	| `lime` | <span style='background:#80e619;color:black'>#80e619</span>
	| `green` | <span style='background:#19e619;color:black'>#19e619</span>
	| `aqua` or `cyan` | <span style='background:#19e5e6;color:black'>#19e5e6</span>
	| `blue` | <span style='background:#197fe6;color:white'>#197fe6</span>
	| `navy` | <span style='background:#1919e6;color:white'>#1919e6</span>
	| `purple` | <span style='background:#7f19e6;color:white'>#7f19e6</span>
	| `magenta` or `fuchsia` | <span style='background:#e619e5;color:white'>#e619e5</span>
	| `white` | <span style='background:#fff;color:black'>#fff</span>
	| `black` | <span style='background:#000;color:white'>#000</span>
	| `grey` or `gray` | <span style='background:#888;color:white'>#888</span>
	| `transparent` | <span>transparent</span>

	(These colours were chosen to be visually pleasing when used as both background colours and text colours, without
	the glaring intensity that certain HTML colours, like pure #f00 red, are known to exhibit.)

	In addition to these values, and the (rgb:), (hsl:), (oklch:) and (lch:) macros, you can also use HTML hex notation to specify
	colours, such as `#691212` or `#a4e`. (Note that these are *not* strings, but bare values - `(bg: #a4e)`
	is valid, as is `(bg:navy)`.) Of course, HTML hex notation is notoriously hard to read and write, so this
	isn't recommended.

	If you want to quickly obtain a colour which is the mixture of two others, you can mix them
	using the `+` operator: `red + orange + white` produces a mix of red and orange, tinted
	white. `#a4e + black` is a dim purple. Note that the `transparent` built-in value allows you to make colours
	partly transparent by mixing them with it. If you want to mix colours in different proportions, such
	as by making a 90% white, 10% yellow shade, then the (mix:) macro is also available to use.

	Like datamaps, colour values have a few read-only data names, which let you examine the **r**ed, **g**reen and **b**lue
	components that make up the colour, as well as its **h**ue, **s**aturation and **l**ightness, its **a**lpha transparency,
	and a datamap showing its **lch** form (in the same values given to the (lch:) macro).

	| Data name | Example | Meaning
	| --- | --- | ---
	| `r` | `$colour's r` | The red component, a whole number from 0 to 255.
	| `g` | `$colour's g` | The green component, a whole number from 0 to 255.
	| `b` | `$colour's b` | The blue component, a whole number from 0 to 255.
	| `h` | `$colour's h` | The hue angle in degrees, a whole number from 0 to 359.
	| `s` | `$colour's s` | The saturation percentage, a fractional number from 0 to 1.
	| `l` | `$colour's l` | The lightness percentage, a fractional number from 0 to 1.
	| `a` | `$colour's a` | The alpha percentage, a fractional number from 0 to 1.
	| `lch` | `$colour's lch` | A datamap of LCH values for this colour.

	These values can be used in the (hsl:), (rgb:) and (lch:) macros to produce further colours. Note that some of these values
	do not transfer one-to-one between representations! For instance, the hue of a gray is essentially irrelevant, so grays
	will usually have a `h` value equal to 0, even if you provided a different hue to (hsl:). Furthermore, colours with a
	lightness of 1 are always white, so their saturation and hue are irrelevant.

	The `lch` value produces a datamap containing these values.

	| Data name | Example | Meaning
	| --- | --- | ---
	| `l` | `$colour's lch's l` | The lightness percentage, a fractional number from 0 to 1. (Not the same as `$colour's l`!)
	| `c` | `$colour's lch's c` | The chroma component, a whole number from 0 to 230 (but which is usually below 132).
	| `h` | `$colour's lch's h` | The hue angle in degrees, a whole number from 0 to 359.

	Colours, when used in passage prose or given to (print:), produce a square swatch containing the colour. This is a `<tw-colour>`
	element, but otherwise has no other features or capabilities and is intended solely for debugging purposes.
*/
const
	{max,min,sin,cos,round,floor,atan2,cbrt,sqrt,PI,abs,sign} = Math,
	{assign, create} = Object,
	/*
		These RegExps check for HTML #fff and #ffffff format colours.
	*/
	tripleDigit   = /^([\da-fA-F])([\da-fA-F])([\da-fA-F])$/,
	sextupleDigit = /^([\da-fA-F])([\da-fA-F])([\da-fA-F])([\da-fA-F])([\da-fA-F])([\da-fA-F])$/,
	/*
		Used for iteration.
	*/
	RGBAkeys: (keyof RGB)[] = [`r`,`g`,`b`,`a`],
	/*
		This cache here is used by the function just below.
	*/
	cssNameCache = create(null)

type HSL = { h: number, s: number, l: number, a?: number }
type RGB = { r: number, g: number, b: number, a?: number }
type LCH = { l: number, c: number, h: number }
type LCHA = LCH & {a:number}

// Matrix multiplication
function matMul(m1: number[][], m2?: number[][], ...rest: number[][][]) {
	if (rest.length > 0) {
		return matMul(matMul(m1, m2), ...rest)
	}
	else if (!m2) {
		return m1
	}
	const result: number[][] = []
	for (let i = 0; i < m1.length; i++) {
		result[i] = []
		for (let j = 0; j < m2[0].length; j++) {
			let sum = 0
			for (let k = 0; k < m1[0].length; k++) {
				sum += m1[i][k] * m2[k][j]
			}
			result[i][j] = sum
		}
	}
	return result
}

/*
	This private function tries its best to convert a CSS3 colour name (like "rebeccapurple"
	or "papayawhip") to an RGB object. It uses jQuery to make the initial lookup, and
	caches the resulting object for future lookups.
*/
function css3ToRGB(colourName: string): RGB {
	if (colourName in cssNameCache) {
		return cssNameCache[colourName]
	}
	let colourString: string = $(`<p>`).css(`background-color`, colourName).css(`background-color`)
	/*
		"transparent" is the only built-in Harlowe colour which can't be represented by
		hex form (and which isn't converted to it during compilation).
	*/
	let colour:RGB
	if (colourString === `transparent`) {
		colour = { r:0, g:0, b:0, a:0 }
	}
	else if (!colourString.startsWith(`rgb`)) {
		colour = { r:192, g:192, b:192 }
	}
	else {
		colour = (colourString.match(/\d+/g) || []).reduce((colour:RGB, num, ind) => {
			colour[<`r`|`g`|`b`>`rgb`[ind]] = +num
			return colour
		}, { r:0, g:0, b:0 })
	}
	cssNameCache[colourName] = colour
	return colour
}

/*
	This private function converts a string comprising a CSS hex colour
	into an {r,g,b} object.
	This, of course, doesn't attempt to trim the string, or
	perform "flex hex" parsing to over-long strings.
	(http://scrappy-do.blogspot.com/2004/08/little-rant-about-microsoft-internet.html)
*/
function hexToRGB(str:string): RGB {
	// Assume that any non-strings passed in here are already valid {r,g,b}s.
	if (typeof str !== `string`) {
		return str
	}
	// Trim off the "#".
	str = str.replace(`#`, ``)
	/*
		If a 3-char hex colour was passed, convert it to a 6-char colour.
	*/
	str = str.replace(tripleDigit, `$1$1$2$2$3$3`)
	
	return {
		r: parseInt(str.slice(0,2), 16),
		g: parseInt(str.slice(2,4), 16),
		b: parseInt(str.slice(4,6), 16),
	}
}

/*
	These two private functions converts RGB 0..255 values into H 0..359
	and SL 0..1 values, and back.
	Both are taken from https://drafts.csswg.org/css-color/#hsl-to-rgb
*/
function RGBtoHSL({r, g, b, a}: RGB): HSL {
	// Convert the RGB values to decimals.
	r /= 255
	g /= 255
	b /= 255

	const maxVal = max(r,g,b), minVal = min(r, g, b)
	let h = NaN, s = 0, l = (minVal + maxVal)/2
	let d = maxVal - minVal

	if (d !== 0) {
		s = (l === 0 || l === 1) ? 0 : (maxVal - l) / min(l, 1 - l)
		switch (maxVal) {
			case r: h = (g - b) / d + (g < b ? 6 : 0); break
			case g: h = (b - r) / d + 2; break
			case b: h = (r - g) / d + 4
		}

		h *= 60
	}

    // If saturation is negative, rotate hue by 180
    if (s < 0) {
		h += 180
		s = Math.abs(s)
	}
	if (h >= 360) {
		h -= 360
	}

	return { h:round(h), s, l, a }
}

function HSLToRGB({h, s, l, a}: HSL): RGB {
	function component(n: number) {
		let k = (n + h/30) % 12
		let a = s * min(l, 1 - l)
		return l - a * max(-1, min(k - 3, 9 - k, 1))
	}
	return {
		r: round(component(0)*255),
		g: round(component(8)*255),
		b: round(component(4)*255),
		a,
	}
}

/*
	These functions convert RGB 0..255 values (interpreted as sRGB, as per browser
	specs for CSS colours defined using RGB and HSL) into LCH and OKLCH values
	where L is 0..1+, C is 0..100+, and H is 0..360.

	Taken from https://drafts.csswg.org/css-color-4/conversions.js
*/
const D50white = [ 0.9642956764295677, 1, 0.8251046025104602 ],
	sRGBtoXYZ = [
		[ 0.41239079926595934, 0.357584339383878,   0.1804807884018343  ],
		[ 0.21263900587151027, 0.715168678767756,   0.07219231536073371 ],
		[ 0.01933081871559182, 0.11919477979462598, 0.9505321522496607  ]
	],
	XYZtosRGB = [
		[  3.2409699419045226,  -1.537383177570094,   -0.4986107602930034  ],
		[ -0.9692436362808796,   1.8759675015077202,   0.04155505740717559 ],
		[  0.05563007969699366, -0.20397695888897652,  1.0569715142428786  ]
	],
	D65toD50 = [
		[  1.0479298208405488,    0.022946793341019088,  -0.05019222954313557 ],
		[  0.029627815688159344,  0.990434484573249,     -0.01707382502938514 ],
		[ -0.009243058152591178,  0.015055144896577895,   0.7518742899580008  ]
	],
	D50toD65 = [
		[  0.9554734527042182,   -0.023098536874261423,  0.0632593086610217   ],
		[ -0.028369706963208136,  1.0099954580058226,    0.021041398966943008 ],
		[  0.012314001688319899, -0.020507696433477912,  1.3303659366080753   ]
	],
	kappa = 24389/27, epsilon = 216/24389,
	down = (a:number[]) => a.map(v => [v]),
	across = (a:number[][]) => a.map(v => v[0]),
	RGBtoLinear = (val:number) => val < 0.04045 ? val / 12.92 : ((val + 0.055) / 1.055)**2.4,
	LineartoRGB = (val:number) => abs(val) > 0.0031308 ? sign(val) * (1.055 * val**(1/2.4) - 0.055) : 12.92 * val

// XYZ65 ←→ sRGB
function sRGBtoXYZ65({r,g,b}: RGB) {
	return across(matMul(sRGBtoXYZ, down([r/255,g/255,b/255].map(RGBtoLinear))))
}
function XYZ65tosRGB(XYZ:number[]) {
	const [r,g,b] = across(matMul(XYZtosRGB, down(XYZ))).map(v=>LineartoRGB(v)*255)
	return {r,g,b}
}

// XYZ50 ←→ XYZ65
function XYZ65toXYZ50(XYZ:number[]) {
	return across(matMul(D65toD50, down(XYZ)))
}
function XYZ50toXYZ65(XYZ:number[]) {
	return across(matMul(D50toD65, down(XYZ)))
}

// XYZ50 ←→ LCH
function XYZ50toLCH(XYZ:number[]) {
	// Scale XYZ relative to white
	const xyz = XYZ.map((v, i) => v / D50white[i])
	const f = xyz.map(v => v > epsilon ? cbrt(v) : (kappa * v + 16)/116)
	const Lab = [
		(116 * f[1]) - 16,
		500 * (f[0] - f[1]),
		200 * (f[1] - f[2])
	]
	const hue = atan2(Lab[2], Lab[1]) * 180 / PI
	return {
		l: Lab[0]/100,
		c: sqrt(Lab[1]**2 + Lab[2]**2),
		h: hue >= 0 ? hue : hue + 360
	}
}
function LCHtoXYZ50({l,c,h} : LCH) {
	l *= 100
	const Lab = [
		l, c * cos(h * PI / 180), (c * sin(h * PI / 180))
	]
	const f: number[] = []
	f[1] = (Lab[0] + 16)/116
	f[0] = Lab[1]/500 + f[1]
	f[2] = f[1] - Lab[2]/200
	const xyz = [
		f[0]**3 > epsilon ? f[0]**3 : (116*f[0]-16)/kappa,
		l > kappa * epsilon ? ((l+16)/116)**3 : l/kappa,
		f[2]**3 > epsilon ? f[2]**3 : (116*f[2]-16)/kappa
	]
	return xyz.map((v, i) => v * D50white[i])
}

// XYZ65 ←→ OKLCH
function XYZ65toOKLCH(XYZ:number[]) {
	const XYZtoLMS = [
		[ 0.8190224379967030, 0.3619062600528904, -0.1288737815209879 ],
		[ 0.0329836539323885, 0.9292868615863434,  0.0361446663506424 ],
		[ 0.0481771893596242, 0.2642395317527308,  0.6335478284694309 ]
	]
	const LMStoOKLab = [
		[ 0.2104542683093140,  0.7936177747023054, -0.0040720430116193 ],
		[ 1.9779985324311684, -2.4285922420485799,  0.4505937096174110 ],
		[ 0.0259040424655478,  0.7827717124575296, -0.8086757549230774 ]
	]
	const OKLab = across(matMul(LMStoOKLab, down(across(matMul(XYZtoLMS, down(XYZ))).map(e => cbrt(e)))))
	const hue = atan2(OKLab[2], OKLab[1]) * 180 / PI
	return {
		l: OKLab[0],
		c: sqrt(OKLab[1] ** 2 + OKLab[2] ** 2),
		h: hue >= 0 ? hue : hue + 360
	}
}
function OKLCHtoXYZ65({l,c,h}: LCH) {
	const OKLab = [
		l,
		c * cos(h * PI / 180), // a
		c * sin(h * PI / 180)  // b
	]
	const LMStoXYZ =  [
		[  1.2268798758459243, -0.5578149944602171,  0.2813910456659647 ],
		[ -0.0405757452148008,  1.1122868032803170, -0.0717110580655164 ],
		[ -0.0763729366746601, -0.4214933324022432,  1.5869240198367816 ]
	]
	const OKLabtoLMS = [
		[ 1.0000000000000000,  0.3963377773761749,  0.2158037573099136 ],
		[ 1.0000000000000000, -0.1055613458156586, -0.0638541728258133 ],
		[ 1.0000000000000000, -0.0894841775298119, -1.2914855480194092 ]
    ]
	return across(matMul(LMStoXYZ, down(across(matMul(OKLabtoLMS, down(OKLab))).map(c => c ** 3))))
}

/*
	Alpha-preserving end-user value conversions.
*/

// sRGB ←→ LCH
function sRGBtoLCH(rgb: RGB, a:number) {
	const ret = <LCHA>XYZ50toLCH(XYZ65toXYZ50(sRGBtoXYZ65(rgb)))
	ret.a = a
	return ret
}
function LCHtosRGB(lch: LCH, a:number) {
	const ret = <RGB>XYZ65tosRGB(XYZ50toXYZ65(LCHtoXYZ50(lch)))
	ret.a = a
	return ret
}

// sRGB ←→ OKLCH
function sRGBtoOKLCH(rgb: RGB, a:number) {
	const ret = <LCHA>XYZ65toOKLCH(sRGBtoXYZ65(rgb))
	ret.a = a
	return ret
}
function OKLCHtosRGB(lch: LCH, a:number) {
	const ret = <RGB>XYZ65tosRGB(OKLCHtoXYZ65(lch))
	ret.a = a
	return ret
}

// OKLCH ←→ LCH
function OKLCHtoLCH(oklch: LCH, a:number) {
	const ret = <LCHA>XYZ50toLCH(XYZ65toXYZ50(OKLCHtoXYZ65(oklch)))
	ret.a = a
	return ret
}
function LCHtoOKLCH(lch: LCH, a:number) {
	const ret = <LCHA>XYZ65toOKLCH(XYZ50toXYZ65(LCHtoXYZ50(lch)))
	ret.a = a
	return ret
}

/*
	In order to convert LCH and OKLCH to RGB, it is often necessary to constrain the
	colour's chroma. This function (from https://css.land/lch) binary-searches
	for the lowest chroma that can fit into RGB.
*/
function LCHtoValidsRGB(lch: LCH, a: number, oklch = true) {
	let rgb = oklch ? OKLCHtosRGB(lch, a) : LCHtosRGB(lch, a)
	const validity = (k:keyof RGB) => (rgb[k] || 0) >= 0 && (rgb[k] || 0) <= 255
	if (RGBAkeys.every(validity)) {
		return rgb
	}
	lch = {...lch}
	let high = lch.c
	let low = 0
	lch.c /= 2
	while (high - low > 1e-5) {
		rgb = oklch ? OKLCHtosRGB(lch, a) : LCHtosRGB(lch, a)
		RGBAkeys.every(validity) ? low = lch.c : high = lch.c
		lch.c = (high + low)/2
	}
	/*
		At the very end, hard-cap the values to eliminate decimals.
	*/
	let ret = oklch ? OKLCHtosRGB(lch, a) : LCHtosRGB(lch, a)
	ret.r = min(255,max(0,ret.r))
	ret.g = min(255,max(0,ret.g))
	ret.b = min(255,max(0,ret.b))
	return ret
}

class Colour implements HarloweValue, PropertyContainer, Comparable<Colour>, Add<Colour> {
	declare h?: number
	declare s?: number
	declare l?: number
	declare r: number
	declare g: number
	declare b: number
	a: number
	declare lch?: LCH
	declare oklch?: LCH
	get c() { throw Error() }
	set c(a:unknown) { throw Error() }

	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly objectName: string
	declare readonly properties: string[]
	static { Object.assign(this.prototype, {
		typeID: `colour`,
		typeName: `a colour`,
		objectName: `a colour`,
		properties: [`h`,`s`,`l`,`r`,`g`,`b`,`a`,`lch`,`oklch`]
	})}

	debugName() {
		return `a colour ${this.print()}`
	}
	
	/*
		Colours can be blended by addition.
	*/
	"+"(other:Colour) {
		/*
			These are just shorthands (for "lvalue" and "rvalue").
		*/
		const
			l = this.toRGBA(),
			r = other.toRGBA()
		
		return new Colour({
			/*
				TODO: Replace with oklch blending
			*/
			r : min(round((l.r + r.r) * 0.6), 0xFF),
			g : min(round((l.g + r.g) * 0.6), 0xFF),
			b : min(round((l.b + r.b) * 0.6), 0xFF),
			a : (l.a + r.a) / 2,
		})
	}
	
	print() {
		return `<tw-colour style='background-color:${this.toCSSString()}'></tw-colour>`
	}
	
	is(other: unknown) {
		if (!(other instanceof Colour)) {
			return false
		}
		if ((other.oklch && this.oklch) || (other.lch && this.lch)) {
			let thisLCH = this.oklch ?? this.lch!
			let otherLCH = other.oklch ?? other.lch!
			return abs(otherLCH.l - thisLCH.l) < 1e-3 &&
				abs(otherLCH.c - thisLCH.c) < 1e-3 &&
				abs(otherLCH.h - thisLCH.h) < 1e-3 &&
				other.a === this.a
		}
		const obj = this.toRGBA()
		const otherRGB = other.toRGBA()
		return abs(otherRGB.r - obj.r) < 1e-3 &&
			abs(otherRGB.g - obj.g) < 1e-3 &&
			abs(otherRGB.b - obj.b) < 1e-3 &&
			otherRGB.a === obj.a
	}
	
	clone() {
		return new Colour(this)
	}
	
	/*
		This converts the colour into a CSS rgba() or lch() function.
	*/
	toCSSString() {
		if (this.oklch) {
			const {l,c,h} = this.oklch
			return `oklch(${l} ${c} ${h} / ${this.a})`
		}
		if (this.lch) {
			const {l,c,h} = this.lch
			return `lch(${l*100} ${c} ${h} / ${this.a})`
		}
		const {r,g,b,a} = this.toRGBA()
		return `rgba(${r}, ${g}, ${b}, ${a})`
	}

	toHSLA() {
		return RGBtoHSL(this.toRGBA())
	}

	/*
		For each of these methods, use the colour's canonical LCH if it's present.
	*/
	toRGBA(): Required<RGB> {
		// Because a is explicitly passed in to LCHtoValidsRGB, it's guaranteed to be in the output.
		return this.oklch ? <Required<RGB>>LCHtoValidsRGB(this.oklch, this.a, true) :
			this.lch ? <Required<RGB>>LCHtoValidsRGB(this.lch, this.a, false) : this
	}

	toLCHA() {
		return this.lch ? {a: this.a, ...this.lch} : this.oklch ? OKLCHtoLCH(this.oklch, this.a) : sRGBtoLCH(this, this.a)
	}

	toOKLCHA() {
		return this.oklch ? {a: this.a, ...this.oklch} : this.lch ? LCHtoOKLCH(this.lch, this.a) : sRGBtoOKLCH(this, this.a)
	}

	/*
		Used by (complement:), this rotates a colour's OKLCH hue.
	*/
	OKLCHRotate(r:number) {
		if (r < 0) {
			r = 360 + r
		}
		const oklch = this.toOKLCHA()
		oklch.h = (oklch.h+r) % 360
		return new Colour({ok: true, ...oklch})
	}

	getProperty(prop:string) {
		if (prop === `lch` || prop === `oklch`) {
			const lch = prop === `oklch` ? this.toOKLCHA() : this.toLCHA()
			return new Map([[`l`, lch.l], [`c`, lch.c], [`h`, lch.h]])
		}
		const obj = this.toRGBA()
		if (prop === `h` || prop === `s` || prop === `l`) {
			return RGBtoHSL(obj)[prop]
		}
		if (prop === `r` || prop === `g` || prop === `b` || prop === `a`) {
			return obj[prop]
		}
	}

	toSource() {
		if (this.a === 0) {
			return `transparent`
		}
		let args
		if (this.lch) {
			args = [this.lch.l, this.lch.c, this.lch.h]
		} else if (this.oklch) {
			args = [this.oklch.l, this.oklch.c, this.oklch.h]
		}
		else {
			const hsl = RGBtoHSL(this)
			if (hsl.l === 1 && !hsl.h && !hsl.s) {
				return `white`
			}
			if (hsl.l === 0 && !hsl.h && !hsl.s) {
				return `black`
			}
			if (hsl.l >= 0.5 && hsl.l < 0.5334 && hsl.s === 0) {
				return `gray`
			}
			if (hsl.l === 0.5 && (hsl.s >= 0.8 && hsl.s < 0.8040)) {
				/*
					This mapping MUST line up with that in Markup.js.
				*/
				const mapping = {
					0   : `red`,
					30  : `orange`,
					60  : `yellow`,
					90  : `lime`,
					120 : `green`,
					180 : `cyan`,
					210 : `blue`,
					240 : `navy`,
					270 : `purple`,
					300 : `magenta`,
				}[hsl.h]
				if (mapping) {
					return mapping
				}
			}
			args = [hsl.h, hsl.s, hsl.l]
		}
		/*
			Use (lch:) or (oklch:) if it's available, otherwise (hsl:).
		*/
		return `(${this.oklch ? `oklch` : this.lch ? `lch` : `hsl`}:${args}${this.a !== 1 ? `,${this.a}` : ``})`
	}

	/*
		This constructor accepts an object containing r, g and b numeric properties,
		an object containing h, s and l numeric properties,
		or a string comprising a CSS hex colour.
	*/
	constructor(obj: string | RGB | HSL | LCH & { ok?: boolean } | Colour) {
		if (typeof obj === `string`) {
			obj = (Colour.isHexString(obj) ? hexToRGB : css3ToRGB)(obj)
		}

		// To save computation, don't do the HSL to RGB conversion
		// if the RGB values are already present.
		if (`h` in obj && `s` in obj && `l` in obj &&
				!(`r` in obj) && !(`g` in obj) && !(`b` in obj)) {
			obj = HSLToRGB(obj)
		}
		let a = 1
		// Assume alpha is 1 if it is not specified.
		if (`a` in obj && typeof obj.a === `number`) {
			a = obj.a
		}
		// LCH colours store their initial values rather than converting to
		// RGB immediately.
		if (`h` in obj && `c` in obj && !(`s` in obj) && `l` in obj) {
			// Make sure to copy the object by value rather than by reference.
			assign(this, { [obj.ok ? `oklch` : `lch`]: { l: obj.l, c: obj.c, h: obj.h, }})
		}
		else {
			assign(this, obj)
		}
		this.a = a
	}
	/*
		This static method determines if a given string matches a HTML hex colour format.
	*/
	static isHexString(str:string) {
		return typeof str === `string` && str.startsWith(`#`)
			&& (str.slice(1).match(tripleDigit) || str.slice(1).match(sextupleDigit))
	}

	/*
		This performs both OKLCH and LCH mixing, based on https://drafts.csswg.org/css-color-4/#interpolation
	*/
	static mixLCH(c1: LCHA, p1: number, c2: LCHA, p2: number, ok = true, hueMethod: `shorter`|`longer`|`increasing`|`decreasing` = `shorter`) {
		/*
			If the percents don't equal 1, the difference is converted
			to an alpha multiplier, which is applied at the very end. This is in keeping with
			CSS's color-mix().
		*/
		let alphaMultiplier = 1
		/*
			Scale (normalise) the percents so that they total 1.
		*/
		if (p1 + p2 !== 1) {
			if (p1 + p2 < 1) {
				alphaMultiplier = p1 + p2
			}
			[p1, p2] = [p1/(p1+p2), p2/(p1+p2)]
		}
		/*
			The "powerless hue" step: since white or black don't have a hue, don't interpolate it
			(instead, replace it with the other hue).
			0.001 is a carefully-picked lower limit for chroma in OKLCH.
			2 is a carefully-picked lower limit for chroma in LCH.
		*/
		if (c1.c < (ok ? 0.001 : 2) || c1.l < 0.01 || c1.l > 0.99) {
			c1.h = c2.h
		}
		else if (c2.c < (ok ? 0.001 : 2) || c2.l < 0.01 || c2.l > 0.99) {
			c2.h = c1.h
		}
		/*
			Premultiply step: since transparent colours aren't perceptually as powerful
			as solid colours, multiply (as in, reduce) the lightness and chroma by the alpha.
		*/
		c1.l *= c1.a; c1.c *= c1.a
		c2.l *= c2.a; c2.c *= c2.a
		/*
			The following is each hue interpolation algorithm used for CSS color-mix()
		*/
		if (hueMethod === `shorter`) {
			if (c2.h - c1.h > 180) {
				c1.h += 360
			}
			else if (c2.h - c1.h < -180) {
				c2.h += 360
			}
		} else if (hueMethod === `longer`) {
			const d = c2.h - c1.h
			if (d < 180 && d > 0) {
				c1.h  += 360
			}
			else if (d > -180 && d <= 0) {
				c2.h  += 360
			}
		}
		else if (hueMethod === `increasing` && c2.h < c1.h) {
			c2.h += 360
		}
		else if (hueMethod === `decreasing` && c2.h >= c1.h) {
			c1.h += 360
		}
		/*
			Now, linearly interpolate all the values, and reverse the premultiply step by
			dividing (as in, increasing) them by the new alpha.
		*/
		let newA = c1.a*p1+c2.a*p2,
			newL = (c1.l*p1+c2.l*p2)/newA,
			newC = (c1.c*p1+c2.c*p2)/newA,
			newH = c1.h*p1+c2.h*p2 // Hue, of course, wasn't premultiplied
		return new Colour({l: newL, c: newC, h: newH, a: newA * alphaMultiplier, ok})
	}

	static mixRGB(c1: Required<RGB>, p1: number, c2: Required<RGB>, p2: number) {
		/*
			If the percents don't equal 1, the difference is converted
			to an alpha multiplier, which is applied at the very end. This is in keeping with
			CSS's color-mix().
		*/
		let alphaMultiplier = 1
		/*
			Scale (normalise) the percents so that they total 1.
		*/
		if (p1 + p2 !== 1) {
			if (p1 + p2 < 1) {
				alphaMultiplier = p1 + p2
			}
			[p1, p2] = [p1/(p1+p2), p2/(p1+p2)]
		}
		/*
			Premultiply step: since transparent colours aren't perceptually as powerful
			as solid colours, multiply (as in, reduce) all values by the alpha.
		*/
		c1.r *= c1.a; c2.r *= c2.a
		c1.g *= c1.a; c2.g *= c2.a
		c1.b *= c1.a; c2.b *= c2.a
		/*
			Now, linearly interpolate all the values, and reverse the premultiply step by
			dividing (as in, increasing) them by the new alpha.
		*/
		let newA = c1.a*p1+c2.a*p2
		return new Colour({
			r : min(round((c1.r * p1 + c2.r * p2)/newA), 0xFF),
			g : min(round((c1.g * p1 + c2.g * p2)/newA), 0xFF),
			b : min(round((c1.b * p1 + c2.b * p2)/newA), 0xFF),
			a : (c1.a + c2.a) / 2 * alphaMultiplier,
		})
	}

	static mixHSL(c1: Required<HSL>, p1: number, c2: Required<HSL>, p2: number, hueMethod: `shorter`|`longer`|`increasing`|`decreasing` = `shorter`) {
		/*
			If the percents don't equal 1, the difference is converted
			to an alpha multiplier, which is applied at the very end. This is in keeping with
			CSS's color-mix().
		*/
		let alphaMultiplier = 1
		/*
			Scale (normalise) the percents so that they total 1.
		*/
		if (p1 + p2 !== 1) {
			if (p1 + p2 < 1) {
				alphaMultiplier = p1 + p2
			}
			[p1, p2] = [p1/(p1+p2), p2/(p1+p2)]
		}
		/*
			The "powerless hue" step: since white or black don't have a hue, don't interpolate it
			(instead, replace it with the other hue).
		*/
		if (c1.s < 0.02 || c1.l < 0.01 || c1.l > 0.99) {
			c1.h = c2.h
		}
		else if (c2.s < 0.02 || c2.l < 0.01 || c2.l > 0.99) {
			c2.h = c1.h
		}
		/*
			Premultiply step: since transparent colours aren't perceptually as powerful
			as solid colours, multiply (as in, reduce) saturation and lightness by alpha.
		*/
		c1.s *= c1.a; c2.s *= c2.a
		c1.l *= c1.a; c2.l *= c2.a
		/*
			The following is each hue interpolation algorithm used for CSS color-mix()
		*/
		if (hueMethod === `shorter`) {
			if (c2.h - c1.h > 180) {
				c1.h += 360
			}
			else if (c2.h - c1.h < -180) {
				c2.h += 360
			}
		} else if (hueMethod === `longer`) {
			const d = c2.h - c1.h
			if (d < 180 && d > 0) {
				c1.h  += 360
			}
			else if (d > -180 && d <= 0) {
				c2.h  += 360
			}
		}
		else if (hueMethod === `increasing` && c2.h < c1.h) {
			c2.h += 360
		}
		else if (hueMethod === `decreasing` && c2.h >= c1.h) {
			c1.h += 360
		}
		/*
			Now, linearly interpolate all the values, and reverse the premultiply step by
			dividing (as in, increasing) them by the new alpha.
		*/
		let newA = c1.a*p1+c2.a*p2
		return new Colour({
			h : c1.h * p1 + c2.h * p2, // Hue, of course, wasn't premultiplied
			s : (c1.s * p1 + c2.s * p2)/newA,
			l : (c1.l * p1 + c2.l * p2)/newA,
			a : (c1.a + c2.a) / 2 * alphaMultiplier,
		})
	}
}

Object.freeze(Colour)
Object.freeze(Colour.prototype)

export default Colour