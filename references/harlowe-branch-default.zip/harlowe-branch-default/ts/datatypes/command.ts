import { Section } from '../section.js'
import { toSource } from '../utils/operationutils.js'
import { ChangeDescriptor, CommandRunFn, FullChangeDescriptor, HarloweValue } from '../datatypes.js'
import { Writable } from 'type-fest'

/*
	Commands are data values created by command macros like (goto:) or (seq-link:).
	They can be saved and used elsewhere, like all storable values, and as such must be able to
	hold all the state necessary for this.
*/
type CommandDesc = { attachable?: boolean, storable?: boolean, runFn: CommandRunFn, name?:string, source?: string }
class Command implements HarloweValue {
	#name = ``
	#source = ``
	/*
		This is a public-facing boolean which determines if this can be attached to hooks.
		Attachable commands have a different signature for #runFn - (cd: ChangeDescriptor, section: Section)
		instead of just (section: Section).
	*/
	attachable: boolean
	/*
		Very few commands are unstorable, and those that are typically involve VarRefs ((set:) etc.)
	*/
	unstorable: boolean
	/*
		The function that defines the behaviour of this command.
	*/
	readonly #runFn: CommandRunFn

	get objectName() {
		return `a (${this.#name}:) command`
	}
	get typeName() {
		return `a (${this.#name}:) command`
	}

	declare readonly typeID: string
	static { (<Writable<InstanceType<typeof this>>>this.prototype).typeID = `command`}

	print() { return `\`[A (${this.#name}:) command]\`` }
	
	toSource() { return this.#source }
	is(other: unknown) {
		return toSource(this) === toSource(other)
	}
	clone() {
		return new Command({
			attachable: this.attachable,
			storable: !this.unstorable,
			runFn: this.#runFn,
			name: this.#name,
			source: this.#source,
		})
	}
	runCommand(section:Section, cd?: ChangeDescriptor) {
		const ret = this.#runFn(<FullChangeDescriptor>cd, section)
		return ret
	}

	static create(desc: CommandDesc) {
		return new Command(desc)
	}
	/*
		This constructor is only (Jan 2024) used by Macros and CustomCommand (there as super()),
		but each of them has awkwardly non-overlapping state to give to this Command.
		CustomCommands are generated with no name, 
	*/
	/*
		This must be public instead of protected so that CustomCommand can change the signature.
	*/
	constructor({attachable = true, storable = true, runFn, name, source }: CommandDesc) {
		this.attachable = attachable
		this.unstorable = storable === false
		name !== undefined && (this.#name = name)
		source !== undefined && (this.#source = source)
		this.#runFn = runFn
	}

	name(name:string, source:string) {
		this.#name = name
		this.#source = source

		return this
	}
}
Object.freeze(Command)
Object.freeze(Command.prototype)

export default Command