import { Constructor } from 'type-fest'
import Command from './command.js'
import Changer from './changer.js'
import TwineError from '../internaltypes/twineerror.js'
import { AnyStorable, ChangeDescriptor, Comparable, HarloweValue, VarScope } from '../datatypes.js'
import { Section } from '../section.js'
import { Obj } from '../utils.js'

/*
	These objects comprise the constructor parameters for CustomCommand, which are created by (output:) exclusively
	and passed to macroEntryFn.
*/
type CustomCommandDesc = {
	/*
		This changer matches the original changer attached to the output hook, but with (output:) removed.
		In the case of (t8n:'instant')+(output:), only (t8n:'instant') is present.
		This is handled in the constructor().

		If only (output:) was attached, then this is an explicit undefined.
	*/
	changer: Changer | undefined
	variables: VarScope
	hook: string
	toSource?: string
}
/*
	The (output:) macro allows custom macros to "output hooks".
	For consistency with (print:) etc., this takes the form of custom command values.
	This is one of the few subclasses in the codebase.
*/
class CustomCommand extends
		/*
			This allows overriding Command.create with a different parameter signature.
		*/
		(Command as Constructor<Command> & Omit<typeof Command, `create`>) implements Comparable<CustomCommand>, HarloweValue {
	/*
		TODO: store the knownName of the creator custom macro in the commandDesc, too,
		so that the superclass's versions of these three can be used instead.
	*/
	get objectName() { return `a custom command` }
	get typeName() { return `a custom command` }
	typeID = `customcommand`

	print() { return `\`[A custom command]\`` }

	clone() {
		return new CustomCommand(this.#commandDesc)
	}
	/*
		Custom Commands have no #runFn because they all fundamentally do the same thing: print hooks, with various changers
		attached (both inside at the (out:) call, and outside when used).

		initialCD is used whenever a custom command has changers attached to the outside of it.
		Consider this example:
			(color:red)$customCommand
		The (color:) changer is applied to initialCD (by Section#runExpression()), and passed in to be combined with the
		internal changers combined with the $customCommand's (output:) changer.
	*/
	runCommand(section:Section, initialCD?: ChangeDescriptor) {
		const { variables, hook, changer } = this.#commandDesc
		/*
			This #awkward hack leverages loopVars to provide the tempVariables to the changer, as just one sad little loop.
			This must collect all of the tempVariables in this stack, so an 'in' loop (without hasOwn) must be used.
		*/
		const loopVars: Obj<AnyStorable[]> = {}
		for(let key in variables.variableStore) {
			/*
				A normal loopVars object looks something like this:
				{ a: [1,2,3], b: [5,6], },
				where each array position represents a loop iteration.
				As there is only one loop iteration here, each variable gets an array of 1 element:
				{ a: [1], b: [4], }
			*/
			const value = variables.variableStore[key]
			// null represents deleted variables.
			if (value !== null) {
				loopVars[key] = [value]
			}
		}
		/*
			Create a new CD, or alter the existing one if it was given.
		*/
		const parts = {
			source: hook,
			loopVars,
			section
		}
		const cd = initialCD ? Object.assign(initialCD, parts) : new ChangeDescriptor(parts)
		/*
			If (output:) was the only changer attached to the output hook,
			then changer is undefined here.
		*/
		if (changer) {
			const error = changer.run(cd)
			if (error instanceof TwineError) {
				return error
			}
		}
		return cd
	}
	/*
		This constructor simply calls upon the superclass, and saves the commandDesc.
	*/
	constructor(commandDesc: CustomCommandDesc) {
		/*
			The CustomCommandDesc's changer should not include the (output:) changer, for various
			reasons (mainly that executing the (output:) changer in runCommand() would incorrectly block the caller's stack,
			instead of just the custom macro interior's stack), so it is manually removed by this method:

			Go through each changer in the chain. If it's (output:), splice it from the chain
			by making the previous changer's 'next' become the (output:) changer's 'next'.
			If there is no previous changer, replace the changer with its 'next'.
		*/
		let changer: undefined|Changer = commandDesc.changer?.clone()
		let curr = changer, prev: undefined|Changer
		while (curr) {
			if (curr.macroName === `output`) {
				if (prev) {
					prev.next = curr.next
				} else {
					changer = curr = curr.next
					continue
				}
			}
			prev = curr
			curr = curr.next
		}
		commandDesc.changer = changer

		super({
			/*
				All CustomCommands are attachable, because all they do is print hooks,
				which can be changed further with changers.
			*/
			attachable: true,
			source: commandDesc.toSource
		})
		this.#commandDesc = commandDesc
	}
	/*
		The internals of the custom command must be stored and given to State for serialisation, to completely
		capture the internal variables, the (out:) hook, and the (out:) changer (combined with other changers) that was
		attached to that hook. There isn't really an easier way of doing this at the moment.
	*/
	readonly #commandDesc: CustomCommandDesc
	customCommand() {
		return this.#commandDesc
	}
}

Object.freeze(CustomCommand)
Object.freeze(CustomCommand.prototype)

export { CustomCommand, CustomCommandDesc }