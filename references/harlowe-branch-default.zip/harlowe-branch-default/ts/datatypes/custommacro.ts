import $ from "jquery"
import {andList} from "../utils.js"
import Renderer from "../renderer.js"
import {objectName, typeName, matches, toSource} from "../utils/operationutils.js"
import TwineError from "../internaltypes/twineerror.js"
import TwineNotifier from "../internaltypes/twinenotifier.js"
import { Section, StackFrame } from "../section.js"
import { MacroFn, Signature } from "../macros.js"
import { Datatype, CustomCommand, VarRef, VarScope, AnyStorable, CodeHook, TypedVar, HarloweValue, UserFacing, PropertyContainer } from "../datatypes.js"

const {assign,setPrototypeOf} = Object
/*d:
	CustomMacro data

	These are custom macros produced by the (macro:) and (partial:) macros. You can (and should) store them in variables using (set:),
	and call them like any other macro, by using the variable instead of a name: `($someCustomMacro:)` is how you would
	call a custom macro stored in the variable $someCustomMacro, and `(_anotherCustomMacro:)` is how you would
	call a custom macro stored in the temp variable _anotherCustomMacro.

	Custom macros created with (macro:) have a single data name that you can examine.

	| Data name | Example | Meaning
	| --- | --- | ---
	| `params` | `$customMacro's params`, `params of $customMacro` | An array containing all of the TypedVar data given to the (macro:) macro when this was created.

	Placing custom macros directly into passage prose, such as by calling (macro:) outside of a (set:) or another data-storing
	macro, or writing a custom macro call incorrectly, will cause an error.

	For more information about custom macros, see the (macro:) macro's article.
*/

/*
	A quick type-check utility function.
*/
function isRest(p: unknown) {
	return p instanceof Datatype && p.rest
}
/*
	This creates the "fn" function, normally present in built-in macros' entries in Macros,
	that will be run by Macros.runCustom(). It takes the stored body, assigns the passed-in args
	to the variable names (since type-checking has been completed), sets up the environment
	in which the body is executed, executes it, then returns the result.
*/
const macroEntryFn = (macro: CustomMacro) => (section: Section, ...args: AnyStorable[]) => {
	/*
		First, increment the "called" value for this macro, which is used just below.
	*/
	macro.called += 1

	const {varNames, params, body} = macro
	/*
		The passed-in arguments to the custom macro become temp. variables
		immediately.
		You may notice this does NOT have access to any temp. variables outside the
		custom macro. So, closures do not exist in Harlowe custom macros at this time.
	*/
	const tempVariables = new VarScope(`${macro.objectName} call #${macro.called}`)
	/*
		Whenever an error occurs, the DOM may be displayed. When that happens, TwineNotifiers displaying the input variables
		should be added to the start of the DOM.
	*/
	const notifiers:TwineNotifier[] = []
	/*
		Feed the values into the variables scope with the correct names, taking care to
		make sure that rest params turn into arrays.
	*/
	let i = 0
	let finalRest = false // Whether or not a rest param has been reached.
	let name = ``
	for (let argIndex = 0; argIndex < args.length; argIndex += 1) {
		const arg = args[argIndex]
		name = varNames[i]
		/*
			Load up the runtime type constraints, first. Note that rests become arrays, so they must be
			constrained as such... even though the array contents itself currently cannot.
		*/
		tempVariables.typeDefs[name] = isRest(params[i].datatype) ? new Datatype(`array`) : params[i].datatype
		/*
			Now, load up the actual value.
			This uses VarRef.set() instead of a straight assignment to invoke
			the VarRef 'set' event, as well as updating the knownName of the value.
		*/
		const ref = VarRef.create(tempVariables, name)
		if (ref instanceof TwineError) {
			return ref
		}
		if (isRest(params[i].datatype)) {
			finalRest = true
			/*
				Because each .set() activates the 'set' event for VarRef, which includes Debug Mode's
				DOM updating, we need to only use .set() on the final iteration.
			*/
			const newArray = (<AnyStorable[]>(tempVariables.variableStore[name] || []))
				/*
					Don't accidentally spread arg if it's an array.
				*/
				.concat([arg])
			if (argIndex < args.length-1) {
				/*
					As of Jan 2024, it is currently not possible to pass a non-storable value,
					such as a HookName, to custom macros. As a result, this assertion is safe.
				*/
				tempVariables.variableStore[name] = newArray
				continue
			} else {
				ref.set(newArray)
			}
		}
		else {
			ref.set(arg)
			i += 1
		}
		notifiers.push(new TwineNotifier(`${objectName(ref)} is now ${objectName(tempVariables.variableStore[name])}`))
	}
	/*
		In the loop above, if a given argument aligns with a rest param, it and every subsequent argument are loaded
		into it. However, if every argument is consumed by normal params and the next unused param is a rest,
		an empty array should be loaded into it.
	*/
	if (!finalRest && isRest(params[i]?.datatype)) {
		const ref = VarRef.create(tempVariables, varNames[i])
		if (ref instanceof TwineError) {
			return ref
		}
		ref.set([])
		tempVariables.typeDefs[name] = new Datatype(`array`)
	}

	/*
		Prepare the section stack by affixing the arguments, creating a sealed-off DOM to run the body,
		and attaching a special "output" property used to retrieve the output.
		The stack frame itself needs to be in a variable because .execute() will pop it off the stackTop.
	*/
	type outputType = Parameters<StackFrame[`output`]>[0]
	let output:outputType | undefined
	// CustomMacros without a body are not expected to use macroEntryFn() at all.
	let dom = $(`<p>`).append(Renderer.exec(body!.code))
	let stackSize = section.stack.length
	section.stack.unshift({
		tempVariables,
		dom,
		/*
			Output is used for both the values returned by (output:) and the ChangeDescriptors returned by (output-hook:).
		*/
		output(data: outputType) {
			/*
				Because both output macros block control flow to force an early exit, there shouldn't be a need
				for a double-output error (i.e. output already having a value).
			*/
			output = data
		},
	})
	/*
		Cache the evalReplay of section, so that it isn't clobbered.
	*/
	const {evalReplay} = section
	section.evalReplay = undefined
	section.execute()
	/*
		(output:) and (output-data:) block their stack frame, and Section.execute() doesn't pop the stack frame if it's blocked.
		Also, if the (output:) was inside an (if:), the containing stack frame of the (if:) isn't popped either.
		So, these pops need to be done ourselves.
	*/
	while (section.stack.length > stackSize) {
		section.stack.shift()
	}
	section.evalReplay = evalReplay
	/*
		If errors resulted from this execution, extract and return those instead of the output.
	*/
	const errors = dom.find(`tw-error`)

	if (errors.length) {
		/*
			Attach all those saved-up notifiers to the DOM.
		*/
		dom.prepend(notifiers.map(n => n.render()), `<br>`)
		return new TwineError(`propagated`, `${errors.length} error${errors.length > 1 ? `s` : ``} occurred when running ${macro.objectName}.`,
			undefined, dom)
	}

	/*
		Currently, custom macros are required to return something, even if that thing is an error.
	*/
	if (output === undefined) {
		return new TwineError(`custommacro`, `${macro.objectName} didn't output any data or hooks using (output:) or (output-data:).`)
	}
	/*
		If (output:) was run, and a CustomCommandDesc object (with {changer, variables, hook}) was
		returned, then this custom macro should produce a CustomCommand.
	*/
	if (typeof output === `object` && `changer` in output) {
		/*
			Since there's no way to call custom macros without assigning them to variables, this "unnamed"
			string shouldn't ever appear.
		*/
		output.toSource = `(${macro.knownName || `unnamed`}:${args.map(toSource)})`
		return new CustomCommand(output)
	}
	/*
		Otherwise, simply return the outputted value.
	*/
	return output
}

class CustomMacro implements HarloweValue, UserFacing<CustomMacro>, PropertyContainer {
	declare params: TypedVar[]
	declare body?: CodeHook
	declare fn:MacroFn
	declare knownName: string
	declare objectName: string
	declare typeSignature: Signature[]
	/*
		Number of times this has ever been called. Used for notification/error messages only.
	*/
	declare called: number
	/*
		Names of the variables this uses as parameters.
	*/
	declare varNames: string[]

	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly properties: string[]
	static { Object.assign(this.prototype, {
		typeID: `colour`,
		typeName: `a custom macro`,
		properties: [`params`],
	})}

	getProperty(prop: string) {
		if (prop === `params`) {
			return [...this.params]
		}
	}

	print() {
		return `\`[${this.objectName}]\``
	}

	/*
		As with Lambda.clone(), this is rather naive, but should
		be sufficient given macros shouldn't be mutatable from user code.
	*/
	clone() {
		const ret = setPrototypeOf({...this},CustomMacro.prototype)
		/*
			The clone needs a new macroEntryFn so that references to called and knownName use this copy, not the original.
		*/
		ret.fn = macroEntryFn(ret)
		return ret
	}

	/*
		Macros that created modified macros (such as (partial:)) are expected to override this.
	*/
	toSource() {
		return `(macro:${this.params.map(p => p.toSource())
			// This .concat() only adds a comma to the resulting string if params contained any other values.
			.concat(``)}${
				// CustomMacros without a body are expected to override this function.
				this.body!.toSource()
			})`
	}

	/*
		Used exclusively by (partial:).
	*/
	static createFromFn(fn: MacroFn, objectName: string, toSource: () => string, typeSignature: Signature[]): CustomMacro {
		return setPrototypeOf({
			/*
				Currently, custom macros created by (partial:) don't have any params visible to the author.
				This could be modified to support, for partials of built-ins, a conversion of Harlowe built-ins' type signatures…
				if the Harlowe type system was versatile enough.
			*/
			params: [],
			fn,
			typeSignature,
			objectName,
			toSource,
			knownName: ``,
		}, CustomMacro.prototype)
	}

	/*
		Custom macros have a TypeSignature that the type-checker functions in Macros
		require (using internal type-signature objects, not TypedVars), and with other values
		that Macros.addCustom() will pass into the macroEntryFn on execution: varNames and body.
	*/
	constructor(params: TypedVar[], body: CodeHook) {
		assign(this, {
			params,
			/*
				The number of times this has been called throughout the whole story. Used
				entirely by the tempVariables scope of custom macro calls, to make
				Debug Mode's variables pane more informative.
			*/
			called: 0,
			varNames: params.map(p => p.varRef.propertyChain[0]),
			typeSignature: params.map(p => {
				/*
					Convert the datatype of this param into a Harlowe internal type signature.
				*/
				let type: Signature
				if (p.datatype instanceof Datatype) {
					type = p.datatype.toTypeSignatureObject()
				} else {
					// matches() can only error when given (p-opt:) or other "can't be used alone" patterns.
					// Since they can't be used in custom nacro context, this error can't occur.
					type = {pattern: `range`, range: (e:unknown) => <boolean>matches(p.datatype, e), name: typeName(p.datatype)}
				}
				return type
			}),
			body,
			/*
				knownName is assigned to whatever variable this data structure was last assigned to, by VarRef.set().
			*/
			knownName: ``,
			objectName: `a custom macro (with ${params.length ? andList(params.map(toSource)) : `no params`})`,
		})
		this.fn = macroEntryFn(this)
	}
}

Object.freeze(CustomMacro)
/*
	Only using seal() so that (partial:)s can override toSource().
*/
Object.seal(CustomMacro.prototype)

export default CustomMacro