import {anyRealLetter, anyUppercase, anyLowercase, anyCasedLetter, realWhitespace} from "../utils.js"
import { Merge } from "type-fest"
import {objectName, toSource} from "../utils/operationutils.js"
import { Datatype, TypedVar, TwineError, VarScope, DestructureList} from "../datatypes.js"
/*
	Patterns are datatypes which match strings based on an internal RegExp.
*/
const {create} = Object

type PatternArg = string | Datatype | TypedVar
// This one is exported.
type PatternArgs = Array<PatternArg>
/*
	The config object used internally within Pattern.
*/
type PatternConfig = {
	insensitive?: boolean
	canContainTypedVars?: boolean
	canBeUsedAlone?: boolean
	canContainTypedGlobals?: boolean
	/*
		makeRegExpString is used by insensitive().
	*/
	makeRegExpString?: (s: string[]) => string
	args: PatternArgs
}
/*
	The config object passed into Pattern.create().
*/
type PatternCreateConfig = Merge<PatternConfig, {
	name: string
	/*
		This is only used for reconstructing/cloning this pattern.
		This reflects all possible argument types for all pattern macros.
	*/
	fullArgs?: Array<number |string | Datatype | TypedVar>
	makeRegExpString?: (s:string[]) => string
}>

class Pattern extends Datatype {

	regExp: string
	readonly #config: PatternConfig
	readonly #argsSource: string

	/*
		The (p-ins:) macro performs a somewhat drastic transformation on its inputs: all of them are converted to
		case-insensitive versions. This is done using the following brute-force method, whereby a pattern recompiles itself
		and all of its arguments (if necessary).
	*/
	insensitive(): Pattern {
		if (this.#config.insensitive) {
			return this
		}
		/*
			Recompile the pattern (and its RegExp string, using the saved makeRegExpString in the #config).
		*/
		let ret = <Pattern>Pattern.create({
			name: this.name,
			...this.#config,
			insensitive: true,
			args: this.#config.args.map(p => p instanceof Pattern && !p.#config.insensitive ? p.insensitive() : p)
		})
		return ret
	}
	/*
		Recursive method, used only by destructure(), which retrieves every TypedVar (and thus each RegExp capture)
		in this pattern, including inside sub-patterns.
	*/
	typedVars() {
		return this.#config.args.reduce((a: TypedVar[], pattern) => {
			/*
				It's important that captures (TypedVars) are found in the exact order that they're
				returned by RegExp#exec(). For something like /(?:(a)(b)|(c)|(?:(d(e))|(f)))/,
				the order is "ab","c","de","e","f" - which means that nested captures occur
				immediately after their containing captures.
			*/
			if (pattern instanceof TypedVar) {
				/*
					Because this Pattern.create() call is already using a known good datatype,
					this won't throw.
				*/
				let datatype = <Pattern>Pattern.create({
					name:`p-ins`,
					args:[<PatternArg>pattern.datatype],
					insensitive: true,
				})
				a = a.concat(
					/*
						You may notice a conundrum inherent in (p-ins:) combining with typed vars -
						if a var is bound to, say, uppercase-type, but it's inside a (p-ins:), is it actually
						uppercase-type? The intuitive solution is simply to convert all of the TypedVars inside
						an insensitive pattern into versions whose type is wrapped in (p-ins:).

						This assertion presupposes it's impossible for this conversion to error.
					*/
					this.#config.insensitive ? <TypedVar>TypedVar.create(datatype,pattern.varRef) : pattern
				)
				pattern = <PatternArg>pattern.datatype
			}
			if (pattern instanceof Pattern) {
				a = a.concat(pattern.typedVars())
			}
			return a
		},[])
	}
	/*
		AssignmentRequest.destructure() delegates the responsibility of destructuring string patterns to this
		method, which runs the internal RegExp and extracts matches, returning { dest, src, value }
		objects identical to that which AssignmentRequest.destructure() internally uses.
	*/
	destructure(value: unknown): DestructureList | TwineError {
		if (typeof value !== `string`) {
			return new TwineError(`operation`, `I can't put ${objectName(value)} into ${this.toSource()} because it isn't a string.`)
		}
		/*
			If this pattern doesn't have any typedVars at all (i.e. it isn't a destructuring pattern at all) then
			simply return [], and let AssignmentRequest.destructure() produce an error on its own.
		*/
		const typedVars = this.typedVars()
		if (!typedVars.length) {
			return []
		}
		/*
			Unfortunately, this standard destructure match error has to be replicated here.
		*/
		const results = (RegExp(`^${this.rest ? `(?:` : ``}${this.regExp}${this.rest ? `)*` : ``}$`).exec(value) || []).slice(1)
		if (!results.length) {
			return new TwineError(`operation`, `I can't put ${objectName(value)} because it doesn't match the pattern ${this.toSource()}.`)
		}
		/*
			Because every "optional match" pattern macro forbids TypedVars in it, we can safely assume every match lines up
			with a TypedVar, and simply convert them like so.

			Note that in the case of a 0-character match, like "(p-opt:'A')-type _a", we must default the value to the empty string
			ourselves rather than leaving it as undefined.
		*/
		return <DestructureList>results.map((r,i) => {
			let dest = typedVars[i]
			if (dest) {
				/*
					As with spread datatypes inside destructuring array patterns (like (a: 1, ...num-type _a)) which need to be wrapped in (a:)
					(becoming (a:...num)-type _a), the datatype of the resulting variable inside a string pattern needs to be wrapped in (p:).
				*/
				if (dest.datatype instanceof Datatype && dest.datatype.rest && !(dest.datatype instanceof Pattern)) {
					dest = dest.clone()
					/*
						Because this Pattern.create() call is already using a known good datatype, this won't error.
					*/
					dest.datatype = <Pattern>Pattern.create({ name:`p`, args: [<PatternArg>dest.datatype], })
				}
				return { dest, value: r || ``, src: undefined, }
			}
		}).filter(Boolean)
	}

	isTypeOf(value: unknown) {
		if (!this.#config.canBeUsedAlone) {
			return new TwineError(`operation`, `A (${this.name}:) datatype must only be used with a (p:) macro.`)
		}
		return typeof value === `string` && !!value.match(`^${this.rest ? `(?:` : ``}${this.regExp}${this.rest ? `)*` : ``}$`)
	}

	/*
		String patterns used as custom macro arg types must, in the absence of anything more sophisticated,
		overload the 'range' type signature object to perform type checks.
	*/
	toTypeSignatureObject() {
		return { pattern: `range`, name: this.name, range: (e: unknown) => this.isTypeOf(e) } as const
	}

	toSource() {
		return `${this.rest ? `...` : ``}(${this.name}:${this.#argsSource})`
	}

	clone() {
		return Pattern.create({
			name: this.name,
			...this.#config
		})
	}

	get objectName () {
		return `a (${this.name}:) datatype`
	}

	private constructor(name:string, regExp: string, argsSource:string, config: PatternConfig) {
		super(name)
		this.regExp = regExp
		this.#config = config
		this.#argsSource = argsSource
	}

	/*
		The base function for constructing Pattern datatypes, using the Pattern constructor's args, and a function to make the
		internal RegExp using the args (which the function preprocesses to ensure they're all capable of being turned into RegExps).
	*/
	static create(config: PatternCreateConfig) {
		const {name, args, fullArgs = args, makeRegExpString = subargs => subargs.join(``), insensitive=false, canContainTypedVars = true, canBeUsedAlone = true, canContainTypedGlobals = true} = config
		/*
			Convert the args into their regexp string representations, if that's possible.

			Notice that this map of typed var names is used across all recursive mapper() calls.
		*/
		const typedVarNames = create(null)
		const compiledArgs = args.map(function mapper(pattern): TwineError | string {
			/*
				If this pattern has a TypedVar in it (i.e. it's a destructuring/capture pattern) then
				convert it into a RegExp capture, so that RegExp.exec() can capture the matched substring.
			*/
			if (pattern instanceof TypedVar) {
				if (!canContainTypedVars) {
					return new TwineError(`operation`,
						`Optional string patterns, like (${name}:)${name === `p-many` ? ` with a minimum of 0 matches` : ``}, can't have typed variables inside them.`)
				}
				/*
					If typed globals aren't allowed, check that it's a temp variable without a property access.
				*/
				if (!canContainTypedGlobals && !(pattern.varRef.object instanceof VarScope)) {
					return new TwineError(`operation`, `Only typed temp variables can be used in patterns given to (${name}:)`)
				}
				/*
					Check that this TypedVar name isn't repeated.
				*/
				const varName = pattern.getName()
				if (varName in typedVarNames) {
					return new TwineError(`operation`, `There's already a typed temp variable named _${varName} inside this (${name}:) call.`)
				}
				typedVarNames[varName] = true

				/*
					Because of how the (p:) macros restrict their input types, this assertion is safe.
				*/
				const subPattern = mapper(<PatternArg>pattern.datatype)
				return (subPattern instanceof TwineError) ? subPattern : `(${subPattern})`
			}
			/*
				A datatype is a valid argument for a Pattern macro if it's either another Pattern,
				or a String-related datatype.
			*/
			if (pattern instanceof Datatype) {
				/*
					The canContainTypedVars constraint must be obeyed for all sub-patterns of this pattern.
				*/
				if ((!canContainTypedVars || !canContainTypedGlobals) && pattern instanceof Pattern) {
					const typedVars = pattern.typedVars()
					if (!canContainTypedVars && typedVars.length) {
						return new TwineError(`operation`,
							`(${name}:) can't have typed variables inside its pattern.`)
					}
					/*
						If typed globals aren't allowed, check that it's a temp variable without a property access.
					*/
					if (!canContainTypedGlobals && typedVars.some(v => v.varRef.object instanceof VarScope && v.varRef.object.type === `global`)) {
						return new TwineError(`operation`, `Only typed temp variables can be used in patterns given to (${name}:)`)
					}
				}
				if (pattern instanceof Pattern && pattern.regExp) {
					return (pattern.rest ? `(?:` : ``) + (
						/*
							If this is a recompilation of a sensitive pattern into an insensitive one, then convert this argument
							into an insensitive one, too. (Note that the insensitive() call won't recompile an already-insensitive pattern.)
						*/
						insensitive ? pattern.insensitive().regExp : pattern.regExp
					) + (pattern.rest ? `)*` : ``)
				}
				const pName = pattern.name
				/*
					Spread datatypes represent "zero or more" values, in keeping with how they behave when used for custom macro parameters.
				*/
				const rest = pattern.rest ? `*` : ``
				/*
					All of these need to be manually aligned with their implementation in datatype.js.
					Fortunately, both implementations rely on the same RegExp strings in Utils.
				*/
				if (pName === `alnum`) {
					return anyRealLetter + rest
				}
				if (pName === `whitespace`) {
					return realWhitespace + rest
				}
				if (pName === `uppercase`) {
					/*
						(p-ins:) forces both of these case-sensitive datatypes to degrade to just anycase!! Yeah!
					*/
					return (insensitive ? anyCasedLetter : anyUppercase) + rest
				}
				if (pName === `lowercase`) {
					return (insensitive ? anyCasedLetter : anyLowercase) + rest
				}
				if (pName === `anycase`) {
					return anyCasedLetter + rest
				}
				if (pName === `digit`) {
					return `\\d${rest}`
				}
				if (pName === `linebreak`) {
					return `(?:\\r|\\n|\\r\\n)${rest}`
				}
				if (pName === `str`) {
					/*
						"string" is the only one of these datatypes which doesn't strictly refer to a single character, but instead to basically
						anything until a more specific pattern is encountered.
					*/
					return `.*?`
				}
				if ([`even`,`odd`,`int`,`num`].includes(pName)) {
					return new TwineError(`datatype`, `Please use string datatypes like 'digit' in (${name}:) instead of number datatypes.`)
				}
				/*
					If this datatype isn't one of the above, produce an error. This is left in the resulting mapped array, to be dredged out just afterward.
				*/
				return new TwineError(`datatype`, `The (${name}:) macro must only be given string-related datatypes, not ${objectName(pattern)}.`)
			}
			/*
				If it's a string, then it's user-authored, so it needs to have all RegExp-specific
				characters escaped in it.
			*/
			if (typeof pattern === `string`) {
				pattern = pattern.replace(/[.*+\-?^${}()|[\]\\]/g, `\\$&`)
				/*
					This is where (p-ins:) is implemented - this line, which turns every uppercase or lowercase character intoa RegExp character class for both.
				*/
				if (insensitive) {
					pattern = pattern.replace(RegExp(`(${anyUppercase}|${anyLowercase})`, `g`), a => `[${a.toUpperCase()}${a.toLowerCase()}]`)
				}
				return pattern
			}
			/*
				Each Pattern macro has a type signature of either(String,Datatype) in some configuration, so this really should be impossible.
			*/
			throw Error(`given a non-string non-datatype pattern: ${pattern}`)
		})
		/*
			Dredge out any TwineErrors produced.
		*/
		for (let e of compiledArgs) {
			if (e instanceof TwineError) {
				return e
			}
		}
		const ret = new Pattern(name, makeRegExpString(<string[]>compiledArgs),
			`${fullArgs.map(toSource)}`,
			/*
				Strip down the passed-in config to just these.
			*/
			{
				insensitive,
				canContainTypedVars,
				canBeUsedAlone,
				canContainTypedGlobals,
				makeRegExpString,
				args
			}
		)
		return ret
	}
}

Object.freeze(Pattern)
Object.seal(Pattern.prototype)

export { Pattern, PatternArgs }