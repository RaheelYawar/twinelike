import { HarloweValue, Add } from "../datatypes.js"
/*d:
	Measurement data

	Measurements represent distances, lengths and heights of page elements, such as hooks and images. If a macro needs to be given
	a length or distance, such as (text-indent:) or (border-size:), measurements are the data type to use.
	
	Measurements are a combination of a number, and a unit such as "pixels". The units are derived from CSS, but if you
	aren't familiar with it, their meanings and roles are explained as follows.
	- `px`: Short for "pixels", these correspond to CSS's `px` unit. You should use these when you need *extremely precise sizes* that aren't related to the text size.
	Usually, `px` corresponds to the pixels on the player's screen. However, if their browser's zoom level is not 100%, then the pixels of the page
	will be correctly scaled to match. Moreover, on very high DPI screens, CSS pixels instead refer to 1/96th of an onscreen inch (at 100% zoom) instead of specific pixels.
	- `em`: This is a CSS unit that loosely corresponds to the length of the uppercase M in the font being used for that element (hence the name "em").
	Which is to say, this unit is designed for macros that involve text, and which need lengths that scale relative to the text's font. (text-indent:) is one macro that this unit is ideal for.
	- `rem`: Short for "root em". A variant of `em` which refers to the length of the M in the *default* ("root") font. This unit is typically used with
	(font-size:) as an objective sizing unit for fonts, and isn't that useful elsewhere.
	- `w` and `h`: Short for "width" and "height", these refer to a percentage of the width and height of the containing hook or HTML element. `12w` equals 12% of the width.
	`120h` equals 120% of the height. This is almost always used with distance-related macros like (border-width:) or (scroll:), and cannot be used for other macros such as (font-size:).
	- `Lh`: Short for "line height", this refers to the height of a line of text in the current font size. `1Lh` equals one line's height, `3Lh` refers to 3 lines' height, and
	`1.5Lh` means one line and a half of height. While you can write this in lowercase, such as `3lh`, it is recommended to capitalise the L to avoid visual confusion with the `1` digit.

	Measurements can be added and subtracted with other measurements, even ones of a different unit, such as `100w - 50px`. They can also be multiplied with numbers to scale them, such as `50px * 2`.
	This allows you to convert number variables into measurements - writing `1em * $treasures` lets you define an `em` measurement whose value is the same as `$treasures`. And, of course,
	combinations of arithmetic operations can be made, such as `(100w - 25px) * 2`.
*/
/*
	Not supported:
	- in: Absolute. Equals 96px.
	- cm: Absolute. Equals 96px / 2.54
	- mm: Absolute. Equals 96px / 25.4
*/
type MeasureUnit = `px` | `em` | `rem` | `w` | `h` | `Lh`
class Measure implements HarloweValue, Add<Measure> {
	declare readonly typeID: string
	declare readonly typeName: string
	static { Object.assign(this.prototype, {
		typeID: `measure`,
		typeName: `a measurement`,
	})}
	declare unit: MeasureUnit
	declare value: number
	/*
		Because relative measures can't be resolved into concrete values, the only way to resolve relative measure arithmetic is to
		render it as a CSS calc() function when it is finally used.
		As such, every component of a measure arithmetic operation must be saved until then.
		Arithmetic combinations of measures result in a special "sum" measure that has left and right sides, value and unit 0px, but CAN have mult.
	*/
	declare left?: Measure
	declare right?: Measure
	declare operator?: `+` | `-`
	/*
		When the / and * operators are used with a sum measure and a number, that measure gains a multiplier.
	*/
	declare mult?: number

	get objectName() {
		return `a ${this.toSource()} measurement`
	}

	static readonly Units = [`em`, `px`, `rem`, `w`, `h`, `Lh`]

	toSource():string {
		const {left, right, operator, value, unit, mult} = this
		return left && right ? mult !== undefined ? `(${left.toSource()} ${operator} ${right.toSource()}) * ${mult}` : `${left.toSource()} ${operator} ${right.toSource()}`
			: mult !== undefined ? `(${value}${unit} * ${mult})` : `${value}${unit}`
	}

	print() {
		return this.toSource()
	}

	is(other: unknown):boolean {
		/*
			Measures are the same if every property of them is the same.
		*/
		return other instanceof Measure && other.unit === this.unit && other.value === this.value
			&& other.operator === this.operator && other.mult === this.mult && (other.left ? other.left.is(this.left) : !this.left) && (other.right ? other.right.is(this.right) : !this.right)
	}

	/*
		Recursively convert this measure to CSS, including its left and right if it's a sum measure.
	*/
	#toCSSString():string {
		const {left, right, operator, value, unit, mult} = this
		return left && right ? mult !== undefined ? `(${left.toCSSString()} ${operator} ${right.toCSSString()}) * ${mult}` : `(${left.toCSSString()} ${operator} ${right.toCSSString()})`
			: `${value}${
			/*
				Every unit except w and h corresponds to itself in CSS.
			*/
			unit === `w` || unit === `h` ? `%` : unit}`
	}

	/*
		The outermost toCSSString() should wrap the resulting 
	*/
	toCSSString():string {
		return this.left && this.right ? `calc(${this.#toCSSString()})` : this.#toCSSString()
	}

	constructor(value:number, unit: string, mult?: number, left?: Measure, right?: Measure, operator?: `+` | `-`) {
		this.value = value
		this.unit = <MeasureUnit>unit.toLowerCase().replace(`lh`,`Lh`)
		mult && (this.mult = mult)
		left && (this.left = left)
		right && (this.right = right)
		operator && (this.operator = operator)
	}

	clone() {
		return new Measure(this.value, this.unit, this.mult, this.left, this.right, this.operator)
	}

	/*
		Convert this measure to absolute pixels, based on the font size or dimensions of a given element.
	*/
	pxLengthInElement(e: Element,
			/*
				A problem arises when using this method to compute a distance for scrollTo() - scrolling to 100w
				should be the only value that moves the scroll bar to the bottom, but to do that, 100w must mean the
				scrollHeight *minus the clientHeight*, because scrolling within the range (scrollHeight - clientHeight, scrollHeight)
				does nothing (as this would attempt to scroll past the bottom of the element).
				As such, this boolean is required to change the inherent meaning of the `h` and `w` units.
			*/
			scrollDimensions = false):number {
		if (this.left && this.right) {
			return this.left.pxLengthInElement(e, scrollDimensions) + (this.right.pxLengthInElement(e, scrollDimensions) * (this.operator === `-` ? -1 : 1)) * (this.mult ?? 1)
		}
		if (this.unit === `em`) {
			return +getComputedStyle(e).fontSize.replace(`px`,``) * this.value
		}
		if (this.unit === `rem`) {
			return +getComputedStyle(document.documentElement).fontSize.replace(`px`,``) * this.value
		}
		if (this.unit === `Lh`) {
			return +getComputedStyle(e).lineHeight.replace(`px`,``) * this.value
		}
		if (this.unit === `h`) {
			return (e.scrollHeight - (scrollDimensions ? e.clientHeight : 0)) * (this.value / 100)
		}
		if (this.unit === `w`) {
			return (e.scrollWidth - (scrollDimensions ? e.clientWidth : 0)) * (this.value / 100)
		}
		return this.value
	}

	"+"(other:Measure):Measure {
		/*
			If both this and the other are value measures and have the same unit, simply add them.
		*/
		if (!this.left && !this.right && !other.left && !other.right && other.unit === this.unit) {
			// If there is no left or right, then there is no mult either.
			return new Measure(this.value + other.value, this.unit)
		}
		/*
			Addition and subtraction create "addition" measures which have no inherent value except for their left and right.
		*/
		return new Measure(0, `px`, undefined, this, other, `+`)
	}

	"-"(other:Measure):Measure {
		/*
			If both this and the other are value measures and have the same unit, simply subtract them.
		*/
		if (!this.left && !this.right && !other.left && !other.right && other.unit === this.unit) {
			// If there is no left or right, then there is no mult either.
			return new Measure(this.value - other.value, this.unit)
		}
		return new Measure(0, `px`, undefined, this, other, `-`)
	}

	"*"(other:number):Measure  {
		if (!this.left && !this.right) {
			return new Measure(this.value * other, this.unit)
		}
		let ret = this.clone()
		ret.mult = (this.mult ?? 1) * other
		return ret
	}

	"/"(other:number):Measure  {
		if (!this.left && !this.right) {
			return new Measure(this.value / other, this.unit)
		}
		let ret = this.clone()
		ret.mult = (this.mult ?? 1) / other
		return ret
	}

	/*
		Used to verify that the Measure doesn't contain a certain kind of unit.
	*/
	containsUnits(...units: MeasureUnit[]):boolean {
		const {left, right, unit} = this
		return left?.containsUnits(...units) || right?.containsUnits(...units) || units.includes(unit)
	}
}

/*
	Sizing

	left: Measure
	centre: Measure
	right: Measure

	==XXX== equals { left: 30%, centre: 30%, right: 30% }
*/
/*
	Sizing data (in progress)
*/
class Sizing implements HarloweValue {
	left: Measure
	centre: Measure
	right: Measure

	declare readonly typeID: string
	declare readonly typeName: string
	static { Object.assign(this.prototype, {
		typeID: `sizing`,
		typeName: `a sizing`,
	})}

	get objectName() {
		return `a (${this.left.toSource()}-${this.centre.toSource()}-${this.right.toSource()}) measurement`
	}

	constructor(left: Measure, centre: Measure, right: Measure) {
		this.left = left
		this.centre = centre
		this.right = right
	}
}

Object.freeze(Measure)
Object.freeze(Measure.prototype)
export { Measure, Sizing }