import { Comparable, HarloweValue } from "../datatypes.js"
import { AnyToken } from "../markup/markup.js"

/*d:
	CodeHook data

	Several macros, such as (dialog:) or (append-with:), are used to render some markup code stored in a string.
	However, markup code stored in strings can be difficult to write or read in the editor, because there's no syntax
	highlighting for the interior of string. It is also sometimes desirable to have markup code in strings appear
	different to other strings in Debug Mode, so that you can more easily tell what the string is used for in the game.

	Code hooks can be used as alternatives to strings in these cases. You may think of them as "hooks" that
	are written inside macro calls, as data provided to them. Place markup code between `[` and `]` symbols, in the
	same way that strings are between pairs of `"` or `'` symbols.

	Note that unlike strings, you can nest hooks inside code hooks without needing to escape the `]` symbol.
	`(print:[Good afternoon.(if:visits > 1)[ I'm glad to see you again]])` is a valid code hook.

	The (macro:) macro only accepts code hooks for the inner code of the custom macro. The contents of this hook will not be displayed when the
	custom macro runs, so you can put any number of comments and remarks inside it, for your own benefit.
*/
class CodeHook implements HarloweValue, Comparable<CodeHook> {
	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly objectName: string
	static { Object.assign(this.prototype, {
		typeID: `codehook`,
		/*
			These should normally only appear during type signature error messages.
		*/
		typeName: `a code hook`,
		objectName: `a code hook`,
	})}

	declare code: AnyToken[]
	readonly #source: string
	
	toSource() {
		return this.#source
	}

	/*
		Because printed values are pumped directly to renderInto, it's OK to return the code tree.
	*/
	print() {
		return this.code
	}

	is(other: unknown) {
		return other instanceof CodeHook && this.#source === other.#source
	}

	clone() {
		/*
			Cloning is permitted to pass the code tree by reference, since there shouldn't be anything
			that can permute it.
		*/
		return new CodeHook(this.code, this.#source)
	}

	/*
		Note that revived values from (loadgame:) don't have HTML, so they need to be
		compiled anyway...
	*/
	constructor(code: AnyToken[], source: string) {
		this.code = code
		this.#source = source
	}
}
Object.freeze(CodeHook)
Object.freeze(CodeHook.prototype)

export default CodeHook