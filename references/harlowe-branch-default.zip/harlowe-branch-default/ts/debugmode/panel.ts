import $ from "jquery"
import NaturalSort from "../utils/naturalsort.js"
/*
	A simple debug panel + tab class, used to display Variables, Errors, and so forth, which can be live-updated
	whenever the game state changes.
*/
const Sort = NaturalSort()
type PanelCreate<T> = {
	className: string
	rowWrite: ((d: T, existingRow?: JQuery) => JQuery) | VoidFunction
	rowCheck: (d: T, existingRow: JQuery) => void
	rowSort?: (column: string, a: JQuery, b: JQuery) => void
	columnHead: () => string | void
	tabName: string
	tabNameCounter?: boolean
	tabUpdate?: (c:number) => void
}
class Panel<T> {

	declare rowWrite: PanelCreate<T>[`rowWrite`]
	declare rowCheck: PanelCreate<T>[`rowCheck`]
	declare rowSort:  PanelCreate<T>[`rowSort`]
	declare columnHead: PanelCreate<T>[`columnHead`]
	declare tabUpdate: Exclude<PanelCreate<T>[`tabUpdate`], undefined>
	declare tabName: string
	declare tab: JQuery
	declare panel: JQuery
	declare panelRows: JQuery
	/*
		rowWrite is a function which produces a new DOM structure representing the passed-in data, or freshens up
			an existing row if passed in
		rowCheck compares an existing DOM structure created by rowWrite to a given data row, to see if the
		former represents the latter.
		tabUpdate is an overridable function for updating the tab's name.
	*/
	constructor({className, rowWrite, rowCheck, rowSort, columnHead, tabName, tabNameCounter = true, tabUpdate}: PanelCreate<T>) {
		const panel = $(`<div class='panel panel-${className}' style='${new.target.defaultMaxHeight ? `max-height:${new.target.defaultMaxHeight}px` : ``}' hidden><div class="resizer-v"></div><table class='panel-rows'></table></div>`)
		const tab = $(`<button class='tab tab-${className}'>${tabNameCounter ? `0 ${tabName}s` : tabName}</button>`)
		tab.click(() => {
			tab.toggleClass(`enabled`)
			tab.parent().siblings(`.panel`).attr(`hidden`,``)
			if (tab.is(`.enabled`)) {
				tab.siblings(`.tab:not(.tab-${className})`).removeClass(`enabled`)
				panel.removeAttr(`hidden`)
			}
		})
		panel.on(`click`, `th`, ({target}) => {
			target = $(target)
			let dir = target.attr(`data-order`)
			dir = dir === `desc` ? `asc` : `desc`
			this.sort(target.attr(`data-col`), dir)
			/*
				Clear the arrows from other columns except for the current column.
			*/
			panel.find(`th[data-order]`).removeAttr(`data-order`)
			target.attr(`data-order`, dir)
		})
		/*
			The default tab update function is to label it "2 Errors", etc.
		*/
		if (!tabUpdate) {
			tabUpdate = (count:number) => tab.text(tabNameCounter ? `${count} ${tabName}${count !== 1 ? `s` : ``}` : tabName)
		}
		Object.assign(this,{
			tabName,
			tab,
			panel,
			panelRows: panel.find(`.panel-rows`),
			rowWrite,
			rowSort,
			rowCheck,
			columnHead,
			tabUpdate,
		})
	}
	sort(column:string, dir: `desc` | `asc`) {
		this.panelRows.children(`:not(.panel-head, .panel-row-source)`).get().sort((a,b) => {
			if (dir === `desc`) {
				[a,b] = [b,a]
			}
			a = a.querySelector(`.${column}`)!
			b = b.querySelector(`.${column}`)!
			return (this.rowSort && this.rowSort(column, $(a), $(b))) || Sort(
				a.textContent,
				b.textContent
			)
		}).forEach(row => {
			const sourceRow = $(row).next(`.panel-row-source`).get()
			this.panelRows.append(row, sourceRow)
		})
	}
	update(data: T[], count = 0) {
		const {rowCheck, rowWrite, panelRows, columnHead, panel} = this
		const newRows:HTMLElement[] = []
		const children = panelRows.children()
		/*
			For each of the data rows, check if an existing row matches
			that data, using the specified rowCheck function. If so, replace
			it with a new row. Otherwise, insert the new row.
		*/
		data.forEach(d => {
			// For perf reasons, the Array .filter() is run, not the jQuery .filter()
			const existingRow = children.get().filter(e => rowCheck(d,$(e)))
			const newRow = rowWrite(d, existingRow.length ? $(existingRow) : undefined)
			if (newRow) {
				if (!existingRow.length) {
					panelRows.append(newRow)
				}
				newRows.push(...newRow.get())
			}
		})
		/*
			Remove rows once their data is gone (but don't remove the table head).
		*/
		children.filter((_,e) => !newRows.includes(e) && !e.className.includes(`panel-head`)).remove()
		/*
			Update the tab.
		*/
		this.tabUpdate(count)
		/*
			If the table has any rows in it, add the headers. Otherwise, remove them.
		*/
		if (count > 0 && !panelRows.find(`.panel-head`).length) {
			panelRows.prepend(columnHead() || ``)
		} else if (count === 0) {
			panelRows.find(`.panel-head`).remove()
		}
		/*
			Optionally sort if sorting is enabled.
			If a header is set to sort by default, then that sort will occur now.
		*/
		const sort = panel.find(`th[data-order]`)
		if (sort.length) {
			this.sort(sort.attr(`data-col`)!, <`desc` | `asc`>sort.attr(`data-order`))
		}
	}
	static defaultMaxHeight = 300
}
export default Panel