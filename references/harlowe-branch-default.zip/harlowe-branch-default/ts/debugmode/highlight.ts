import $ from "jquery"
import {Obj, insensitiveName} from "../utils.js"
import {Macros} from "../macros.js"
import {versionClass} from "../utils/typecolours.js"
import { AnyToken, Markup } from "../markup/markup.js"

const {lex} = Markup
/*
	This module holds a very simple syntax highlighter for use exclusively in Debug Mode.
*/

/*
	This is mostly the same as the algorithm used in codemirror/mode.
*/
function highlightClasses(currentBranch: AnyToken[]) {
	let counts: Obj<number> = {}
	let ret = ``
	for (let i = 0; i < currentBranch.length; i+=1) {
		const {type,text} = currentBranch[i]
		// If the type is "verbatim" or "comment", erase all of the class names before it.
		if (type === `verbatim` || type === `comment`) {
			ret = ``
		}
		let name = versionClass + type
		counts[name] = (counts[name] || 0) + 1
		// If this name has been used earlier in the chain, suffix
		// this name with an additional number.
		if (counts[name] > 1) {
			name += `-${counts[name]}`
		}
		switch(type) {
			/*
				It's an error if a text node appears inside a macro, but not inside a code hook.
			*/
			case `text`: {
				if (text.trim()) {
					const insideMacro = currentBranch.slice(i + 1).reduce((a: undefined | boolean,t) =>
							a === undefined ? t.type === `macro` ? true : t.type === `hook` ? false : a : a,
							undefined
						)
					if (insideMacro) {
						name += ` ${versionClass}error`
					}
				}
				break
			}
			/*
				Use the error style if the macro's name doesn't match the list of
				existant Harlowe macros.
			*/
			case `macroName`: {
				const firstGlyph = currentBranch[i].text[0]
				if (firstGlyph === `_` || firstGlyph === `$`) {
					name += ` ${versionClass}customMacro ${versionClass + (firstGlyph === `_` ? `tempV` : `v`)}ariable`
					break
				}
				const macroName = insensitiveName(currentBranch[i].text.slice(0,-1))
				if (!Macros.has(macroName)) {
					name += ` ${versionClass}error`
				}
				else {
					/*
						Colourise macro names based on the macro's return type.
						This is done by concatenating the cm-harlowe-4-macroName class
						with an additional modifier containing the return type.
					*/
					name += `-${Macros.get(macroName).returnType.toLowerCase()}`
				}
				break
			}
		}
		ret += `${name} `
	}
	return ret
}
/*
	This module returns a single syntax highlighting function, with optional marking of a subsection.
	This returns a plain array of <span> (or <mark>) elements containing the syntax-highlighted code.
	Note that this assumes the markStart and markEnd positions are exactly at token boundaries.
*/
export default function Highlight(code:string, mode?:string, markStart = 0, markEnd = code.length) {
	/*
		First things first: if the code has over 9999 characters, don't even bother highlighting it.
	*/
	if (code.length > 9999) {
		return [$(`<span>`).text(code)[0]]
	}
	/*
		First, lex the full code to get a tree.
	*/
	const root = lex(code, ``, mode || `macro`)
	const spans: HTMLElement[] = []
	let currentSpanText = ``
	let currentBranch: AnyToken[] = [root]
	for (let pos = root.start; pos < root.end; pos += 1) {
		const branch = <AnyToken[]>root.pathAt(pos)
		/*
			For each position, if the bottommost token changed, create a new <span> and give it the CSS classes for this branch. 
			Remember that pathAt() returns a bottom-first array, with the bottom token at 0.
		*/
		if (branch[0] !== currentBranch[0]) {
			/*
				Finalise the text of this <span> before creating the next.
			*/
			spans.length && (spans[spans.length-1].textContent = currentSpanText)
			currentSpanText = ``
			currentBranch = branch
			/*
				Marked <span>s simply become <mark> elements.
			*/
			spans.push($(`<${markEnd && pos >= markStart && pos < markEnd ? `mark` : `span`} class="${highlightClasses(currentBranch)}">`)[0])
		}
		/*
			Otherwise, simply progressively add to the text of this <span>.
		*/
		currentSpanText += root.text[pos - root.start]
	}
	/*
		Finish the final <span>.
	*/
	spans.length && (spans[spans.length-1].textContent = currentSpanText)
	return spans
}