import $ from "jquery"
import DebugMode from './debugmode/mode.js'
import Renderer from "./renderer.js"
import State from "./state.js"
import {Section,StackFrame} from "./section.js"
import Engine from "./engine.js"
import {Passages} from "./passages.js"
import { ImageAsset } from "./datatypes.js"
import { options, onStartup, storyElement, nth, StoryOptions, Obj } from "./utils.js"
import RenderUtils from "./utils/renderutils.js"
import VarScope from "./internaltypes/varscope.js"
import "./macrolib/values.js"
import "./macrolib/commands.js"
import "./macrolib/datastructures.js"
import "./macrolib/stylechangers.js"
import "./macrolib/enchantments.js"
import "./macrolib/metadata.js"
import "./macrolib/patterns.js"
import "./macrolib/links.js"
import "./macrolib/custommacros.js"
import "./utils/jqueryplugins.js"
import "./repl.js"

const {dialog} = RenderUtils

/*
	Expose jQuery to user scripts.
*/
;(<{$?: typeof $}>window).$ = $
/*
	Harlowe, the default story format for Twine 2.
	
	This module contains only code which initialises the document and the game.
*/
// Used to execute custom scripts outside of main()'s scope.
function __HarloweEval(script:string) {
	Function(`script`, `DebugMode`, `Renderer`, `State`, `Section`, `Engine`, `Passages`, `Utils`, `RenderUtils`,`ImageAsset`,
		/*
			The two variables of this function, plus its arguments, are shadowed with undefined to make them unusable to the <script>.
			Even the script variable is shadowed.
			Non-strict mode makes shadowing 'arguments' possible.
		*/
		`arguments=void 0;eval([script,script=void 0][0]);`
	)(script, DebugMode, Renderer, State, Section, Engine, Passages, { options, onStartup, storyElement, nth }, RenderUtils, ImageAsset)
}

/*
	This function pretty-prints JS errors using Harlowe markup, for display in the two error dialogs below.
*/
function printJSError(error:Error) {
	let ret = `${error.name}: ${error.message}`
	if (error.stack) {
		const stack = error.stack.split(`\n`)
		/*
			Exclude the part of the error stack that follows "__HarloweEval" (the name of the eval wrapper function above)
			as these contain Harlowe engine code rather than user script code.
		*/
		const index = stack.findIndex(line => line.includes(`__HarloweEval`))
		/*
			Print the full stack, removing URL references (in brackets) such as those in Chrome stacks.
		*/
		ret += `\n${stack.slice(0, index).join(`\n`).replace(/\([^)]+\)/g, ``)}`
	}
	/*
		The stack is shown in monospace, in a limited-size frame that shouldn't push the OK link off the dialog box.
	*/
	return `<div style='font-family:monospace;overflow-y:scroll;max-height:30vh'>\`\`\`${ret}\`\`\`</div>`
}

/*
	When an uncaught error occurs, then display an alert box once, notifying the author.
	This installs a window.onerror method, but we must be careful not to clobber any existing
	onerror method.
*/
(oldOnError => {
	window.onerror = function (...args) {
		/*
			First, to ensure this function only fires once, we restore the previous onError function.
		*/
		window.onerror = oldOnError
		/*
			This dialog, and the one further down, doesn't - can't - block passage control flow, so it can appear over other dialogs and lets
			the passage animate beneath it. This is just a slightly awkward inconsistency for a dialog box that shouldn't appear in normal situations.
			Additionally, this is affixed to the parent of the <tw-story> so that it isn't easily removed without being seen by the player.
		*/
		storyElement.parent().append(dialog({
			message: `Sorry to interrupt, but this page's code has got itself in a mess.\n\n${args[4] ? printJSError(args[4]) : ``}\n(This is probably due to a bug in the Harlowe game engine.)`
		}).addClass(`harlowe-crash`))
		/*
			Having produced that once-off message, we now invoke the previous onError function.
		*/
		if (typeof oldOnError === `function`) {
			oldOnError(...args)
		}
	}
})(window.onerror)

/*
	This is the main function which starts up the entire program.
*/
onStartup(() => {
	const header = $(`tw-storydata`)

	if (header.length === 0) {
		// TODO: Maybe some sort of error?
		return
	}

	/*
		The IFID is currently only used as a localStorage name tag.
		Since this is used by Debug Mode, it should be loaded before calling DebugMode().
	*/
	options.ifid = header.attr(`ifid`)!
	/*
		3.3.5: Special valueRef bug triage switch (to be removed in a future version)
	*/
	;(header.attr(`tags`) || ``).split(/\s/).forEach(b => {
		if (b === `uncompressed-pure-values` || b === `uncompressed-saves`) {
			options.uncompressedPureValues = true
		}
		if (b === `uncompressed-structures` || b === `uncompressed-saves`) {
			options.uncompressedStructures = true
		}
	})

	// Load options from attribute into story object
	;(header.attr(`options`) || ``).split(/\s/).forEach(b => {
		b && ((<StoryOptions & Obj<boolean>>options)[b] = true)
		/*
			Enable Debug Mode if it's set in the HTML.
		*/
		if (b === `debug`) {
			DebugMode()
		}
	})
	let startPassageId: number | string | undefined = header.attr(`startnode`)
	
	// If there's no set start passage, find the passage with the
	// lowest passage ID, and use that.
	if (startPassageId === undefined) {
		startPassageId = $(`tw-passagedata`).get().reduce((id:number, el) => {
			const pid = el.getAttribute(`pid`) || ``
			return !Number.isNaN(pid) && +pid < id ? +pid : id
		}, Infinity)
	}
	/*
		TODO: Drop an error if there is still no startPassage.
	*/
	let startPassage = $(`tw-passagedata[pid='${startPassageId}']`).attr(`name`)!

	/*
		This gives interactable elements that should have keyboard access (via possessing
		a tabindex property) some basic keyboard accessibility, by making their
		enter-key event trigger their click event.
	*/
	$(document.documentElement).on(`keydown`, event => {
		if (event.which === 13 && event.target.getAttribute(`tabindex`) === `0`) {
			$(event.target).trigger(`click`)
		}
	})
	
	// Execute the custom scripts
	let scriptError = false
	$(`[role=script]`).each(function(i) {
		try {
			__HarloweEval($(this).html())
		} catch (e) {
			// Only show the first script error, leaving the rest suppressed.
			if (!scriptError) {
				scriptError = true
				dialog({
					parent: storyElement.parent(),
					message:`There is a problem with this story's ${nth(i + 1)} script:\n\n${printJSError(<Error>e)}`,
				})
			}
		}
	})
	
	// Apply the stylesheets
	$(`[role=stylesheet]`).each((i,e) => {
		// In the future, pre-processing may occur.
		$(document.head).append(`<style data-title="Story stylesheet '${i + 1}'">${$(e).html()}`)
	})

	// Set up the passage metadata
	const tempSection = new Section()
	/*
		This is necessary in order for State to recompile custom macros containing typed variables as parameters.
		These are recompiled into VarRefs, even though they aren't actually references to temp variables, but definitions.
	*/
	// TODO: StackFrame doesn't need to be exported by Section… add a method to do this instead.
	tempSection.stack = [new StackFrame({tempVariables: new VarScope(``)})]

	const metadataErrors = Passages.loadMetadata(tempSection)
	if (metadataErrors.length) {
		const d = dialog({
			parent: storyElement.parent(),
			message: `These errors occurred when running the \`(metadata:)\` macro calls in this story's passages:<p></p>`,
		})
		// Because these TwineErrors have their 'source' property modified to list their actual source, render() doesn't need an argument.
		metadataErrors.forEach(error => d.find(`p`).append(error.render()))
	}
	
	/*
		Load all assets, then commence with the story.
	*/
	ImageAsset.loadAssets()

	// Load the sessionStorage if it's present (and we're not testing)
	const sessionData = !options.debug && State.hasSessionStorage && sessionStorage.getItem(`Saved Session`)
	if (sessionData) {
		// If deserialisation fails (i.e. it returned an Error instead of true),
		// it means the sessionData is invalid. Just ignore it - it's only temporary data.
		if (State.deserialise(tempSection, sessionData) === true) {
			// This is copied from (load-game:).
			Engine.showPassage(State.passage)
			return
		}
	}

	// Show the first passage!
	Engine.goToPassage(startPassage)
})