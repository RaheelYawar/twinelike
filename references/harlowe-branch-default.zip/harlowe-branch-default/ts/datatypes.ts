/*
	This is a convenience module designed to make importing all datatypes easier.
*/
import { SetRequired } from 'type-fest'
import {AssignmentRequest, DestructureList} from './datatypes/assignmentrequest.js'
import Changer from './datatypes/changer.js'
import CodeHook from './datatypes/codehook.js'
import Colour from './datatypes/colour.js'
import Command from './datatypes/command.js'
import { CustomCommand, CustomCommandDesc } from './datatypes/customcommand.js'
import CustomMacro from './datatypes/custommacro.js'
import Datatype from './datatypes/datatype.js'
import { Pattern } from './datatypes/pattern.js'
import Gradient from './datatypes/gradient.js'
import {HookSet, HookSetProperty} from './datatypes/hookset.js'
import Lambda from './datatypes/lambda.js'
import TypedVar from './datatypes/typedvar.js'
import { Measure } from './datatypes/measure.js'
import VarBind from './datatypes/varbind.js'
import { ImageAsset } from './datatypes/asset.js'
import ChangeDescriptor from './internaltypes/changedescriptor.js'
import Enchantment from './internaltypes/enchantment.js'
import TwineError from './internaltypes/twineerror.js'
import TwineNotifier from './internaltypes/twinenotifier.js'
import { VarRef, Determiner } from './internaltypes/varref.js'
import VarScope from './internaltypes/varscope.js'
import Spreader from './internaltypes/spreader.js'
import { Section } from './section.js'
import { AnyToken } from 'markup/markup.js'
import { Signature } from 'macros.js'

type AnyStorablePrimitive = string | number | boolean | AssignmentRequest | CodeHook | Datatype | Command | Changer | Colour | CustomMacro | Gradient | ImageAsset | Lambda | Measure
type AnyStorable = AnyStorablePrimitive | Map<string, AnyStorable> | AnyStorable[] | Set<AnyStorable>
type AnyValue = AnyStorable | AssignmentRequest | HookSet | TypedVar | VarBind | Spreader | Determiner | VarRef | AnyValue[]
type AnyUnstorable = Exclude<AnyValue, AnyStorable>
type AnyMap = Map<string, AnyStorable>
type AnySet = Set<AnyStorable>
	/*
		So that destucturing patterns involving arrays are possible, this must be included.
	*/
	| Array<AnyStorable | TypedVar | Spreader>

type ContainsTwineError = TwineError | Array<unknown|ContainsTwineError>
type OrTwineError<T> = T | ContainsTwineError
type MaybeError = ReturnType<typeof TwineError.containsError>

/*
	Used by Macros and Command.
*/
type FullChangeDescriptor = SetRequired<ChangeDescriptor, `section` | `attr` | `styles` | `data`>
type CommandReturnValue = void | TwineError | TwineNotifier | ChangeDescriptor | { blocked: boolean | JQuery }
type CommandRunFn = (cd: FullChangeDescriptor, section: Section, ...args: any[]) => CommandReturnValue
/*
	Changers can receive and permute partial ChangeDescriptors, unlike Commands.
*/
type ChangerFn = (cd: ChangeDescriptor, ...args: any[]) => TwineError | Changer | void

/*
	This is the parameter for the *setter* version of $.prototype.css().
*/
type JQueryCSSValue = string | number | ((this: HTMLElement, index: number, value: string) => string | number | void | undefined)
type JQueryCSSParameter = JQuery.PlainObject<JQueryCSSValue>

/*
	The basic API of Harlowe data values.
*/
type HarloweValue = {
	/*
		A string that's used when Harlowe needs to name the object in error messages or the debug menu.
	*/
	objectName: (() => string) | string
	/*
		A string that's used when Harlowe needs to name the type of the object in error messages or the debug menu.
		TODO: Make static
	*/
	typeName: (() => string) | string
	/*
		Used by Debug Mode, etc. to determine what colour to give this value's representation.
		TODO: Make static
	*/
	typeID: string
	/*
		Means the value cannot be stored using (set:) or (put:), nor can be used inside macros with an Any signature.
	*/
	unstorable?: boolean
	/*
		A function which is used when this is printed into the passage,
		or used in a (print:) command. This does NOT execute Command objects,
		instead just printing their name.
	*/
	print?: () => string | TwineError | AnyToken[]
}
/*
	An extension to HarloweValue which signifies that this value is "first-class", and can be stored in variables, passed to (source:) etc.
*/
type UserFacing<T> = {
	toSource: () => string
	/*
		A function which clones the value, even if it's an oddly-shaped object.
		Should be used exclusively by VarRef.set().
		Anything without clone() is simply cloned using its create(), etc.
	*/
	clone?: () => T
	debugName?: () => string // Used for colour swatches, etc.
}
/*
	Signifies that the value can be added using the + operator.
*/
type Add<T> = UserFacing<T> & {
	/*
		A function which is used to overload the + operator. Note that Harlowe
		automatically forces both sides of + to be of identical type.
	*/
	[`+`]: (other: T) => T
}
/*
	Signifies that the value can overload the "is" operator.
*/
type Comparable<T> = UserFacing<T> & {
	is: (other: T) => boolean
}
/*
	Signifies that the value has properties accessible with "'s" and "of"
*/
type PropertyContainer = {
	getProperty: (name: string) => unknown
	// TODO
	properties: string[]
}
/*
	Signifies that the value can be used on the type-side of "matches" and "is a".
*/
type Typelike<T> = UserFacing<T> & {
	/*
		A function which is used to implement the "is a" operator. Should only be
		present on Datatype data. Note that this reverses "is a"'s arguments so
		that the right side has its isTypeOf method called.
	*/
	isTypeOf?: (other: unknown) => boolean | TwineError
	toTypeSignatureObject: () => Signature
}

export {
	AssignmentRequest,
	DestructureList,
	Changer,
	Command,
	CodeHook,
	Colour,
	CustomCommand,
	CustomCommandDesc,
	CustomMacro,
	Datatype,
	Pattern,
	Gradient,
	HookSet,
	HookSetProperty,
	ImageAsset,
	Measure,
	Lambda,
	TypedVar,
	VarBind,
	ChangeDescriptor,
	Enchantment,
	TwineError,
	TwineNotifier,
	VarRef,
	Determiner,
	VarScope,
	Spreader,
	AnyStorable,
	AnyUnstorable,
	AnyValue,
	AnyMap,
	AnySet,
	OrTwineError,
	ContainsTwineError,
	MaybeError,
	FullChangeDescriptor,
	CommandReturnValue,
	CommandRunFn,
	ChangerFn,
	JQueryCSSParameter,
	JQueryCSSValue,
	HarloweValue,
	UserFacing,
	Add,
	Comparable,
	PropertyContainer,
	Typelike
}