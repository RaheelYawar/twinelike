import {twine23, builtinColourNames, buttonClass, toHarloweColour, toCSSColour, el, fontIcon, ShortDefs, disabledButtonCSS, Obj, Callback}  from './utils.js'
import Patterns from '../patterns.js'
import {Markup} from '../markup.js'

const {stringify} = JSON

let {lex} = Markup,
	/*
		To work around a circular dependency (involving the Confirm button implementation), ToolbarPanel has wrapSelection and switchPanel injected into it.
	*/
	ToolbarPanel = <{ switchPanel: (s?:string) => void, wrapSelection: Callback }>{}

import { Simplify, TaggedUnion } from 'type-fest'

type Subrows<T> = (PanelRow<T> | HTMLElement | Text)[]
type ModelMethod<T> = (m: Model<T>, el: HTMLElement) => void
/*
	A ModelMethod that has been Curried with a HTMLElement.
*/
type PartialModelMethod<T> = (m:Model<T>) => void
type ModelRowsMethod<T> = (m: Model<T>, rowValues: string[]) => void
type ModelCallback<T> = (m: Model<T>, v:string|number) => void

/*
	Toolbar panels are defined as arrays of PanelRows (plus some loose DOM and Text nodes), offering the following GUI elements.
	The type variable T is assigned by folddownPanel().
*/
type PanelRow<T> = Simplify<{
	model?: ModelMethod<T>
	update?: ModelMethod<T>
} & TaggedUnion<`type`, {
	text: { text:string }
	small: { text:string }
	"inline-text": { text:string }
	notice: { text:string }
	buttons: {
		buttons: ({
			title: string
			html: string
			onClick: EventListener
			update?: (m: Model<T>, el: HTMLElement) => void
			active?: boolean
			danger?: boolean
		} | HTMLElement)[]
	}
	preview: {
		tagName?: string
		text:string
	}
	"t8n-preview": {
		tagName?: string
		// The first text is optional because link transitions don't involve disappearing text.
		text?:string
		text2: string
	}
	textarea: {
		text: string
		width:string
		placeholder?: string
		multiline?: boolean
	}
	"inline-textarea": {
		text: string
		width:string
		placeholder?: string
		multiline?: boolean
		useSelection?: boolean
		persist?: boolean
	}
	"inline-string-textarea": {
		text: string
		width:string
		placeholder?: string
		modelCallback:ModelCallback<T>
		modelRegistry:PartialModelMethod<T>[]
	}
	"inline-number-textarea": {
		text: string
		width:string
		placeholder?: string
		modelCallback:ModelCallback<T>
	}
	"inline-passage-textarea": {
		text: string
		width:string
		placeholder?: string
	}
	"expression-textarea": {
		text: string
		width:string
		placeholder?: string
		modelCallback:ModelCallback<T>
		modelRegistry:PartialModelMethod<T>[]
	}
	"textarea-rows": {
		nonZeroRows:boolean
		placeholder?: string
	}
	checkbox: {
		text: string
		persist?: boolean
	}
	"inline-checkbox": {
		text: string
		persist?: boolean
	}
	checkboxrow: {
		text: string
		subrow: Subrows<T>
	}
	checkboxes: {
		name: string
		capitalise?: boolean
		bold?: boolean
		bottomBorder?: boolean
		options: string[]
		checked?: (i:number) => boolean
		persist?: boolean
	}
	radios: {
		name: string
		capitalise?: boolean
		bold?: boolean
		bottomBorder?: boolean
		options: string[]
		persist?: boolean
	}
	radiorows: {
		name: string
		options: Subrows<T>[]
	}
	dropdown: {
		text:string
		options: string[]
		persist?: boolean
	}
	"inline-dropdown": {
		text:string
		options: string[]
		modelRegistry?:PartialModelMethod<T>[]
		persist?: boolean
	}
	"inline-dropdown-rows": {
		text:string
		name:string
		width:string
		options: [string, ...PanelRow<T>[]][]
	}
	"datavalue-rows": {
		text:string
		renumber: (l:HTMLElement, n:number) => void
		modelRows: ModelRowsMethod<T>
		modelRegistry?:PartialModelMethod<T>[]
	}
	/*
		datavalue-inner is used for values like "it + another value",
		which wrap a smidge of code around some other value.
	*/
	"datavalue-inner": {
		text:string
		/*
			The number is optional here because
			datavalue-inner only ever contains one row (the "inner" value)
		*/
		renumber: (l:HTMLElement, n?:number) => void
		modelRows: ModelRowsMethod<T>
		modelRegistry?:PartialModelMethod<T>[]
	}
	"datavalue-map": {
		text:string
		renumber: (l:HTMLElement, n:number) => void
		modelRows: ModelRowsMethod<T>
		modelRegistry?:PartialModelMethod<T>[]
	}
	"inline-number": {
		text:string
		width?:string
		value:number
		min: number
		max: number
		step?: number
	}
	range: {
		text:string
		width?:string
		value:number
		min: number
		max: number
		step: number
	}
	"inline-range": {
		text:string
		width?:string
		value:number
		min: number
		max: number
		step?: number
	}
	colour: {
		text:string
		value:string
	}
	"inline-colour": {
		text:string
		value:string
	}
	"scroll-wrapper": {
		contents: Subrows<T>
	}
	confirm: { type: `confirm` }
	gradient: { type: `gradient` }
	"macro-list": { type: `macro-list` }
}>>
/*
	Each Panel's GUI permutes a Model object, which is used to generate Harlowe code based on the Panel's options.
	The type variable T is assigned by folddownPanel().
*/
type Model<T> = T & {
	/*
		Most Panels produce Changer macro calls, often concatenated.
		These changer calls are stored here.
	*/
	changers: Obj<string[]>
	changerNamed: (s:string) => string[]
	// suppressedChangers represent Changers that must be placed in an (enchant:) call instead of as-is.
	suppressedChangers?: Obj<string[]>

	wrapStart: string | ((m:Model<T>) => string)
	wrapEnd: string | ((m:Model<T>) => string)
	wrapStringify: boolean
	innerText?: string
	valid: boolean
	output: () => string
	/*
		Used only by "data value rows", which can have arbitrary subrows,
		the modelRegistry stores subrows' model() methods to be called later.
	*/
	modelRegistry?: PartialModelMethod<T>[]
	/*
		These three are also only used by data value rows.
	*/
	expression?: string
	invalidSubrow?: boolean
	innerVariable?: string
}

const $ = `querySelector`
const $$ = `${$}All`
const ON = `addEventListener`
const OFF = `removeEventListener`

const openColors = [
	[`#f8f9fa`,`#fff5f5`,`#fff0f6`,`#f8f0fc`,`#f3f0ff`,`#edf2ff`,`#e7f5ff`,`#e3fafc`,`#e6fcf5`,`#ebfbee`,`#f4fce3`,`#fff9db`,`#fff4e6`],
	[`#f1f3f5`,`#ffe3e3`,`#ffdeeb`,`#f3d9fa`,`#e5dbff`,`#dbe4ff`,`#d0ebff`,`#c5f6fa`,`#c3fae8`,`#d3f9d8`,`#e9fac8`,`#fff3bf`,`#ffe8cc`],
	[`#e9ecef`,`#ffc9c9`,`#fcc2d7`,`#eebefa`,`#d0bfff`,`#bac8ff`,`#a5d8ff`,`#99e9f2`,`#96f2d7`,`#b2f2bb`,`#d8f5a2`,`#ffec99`,`#ffd8a8`],
	[`#dee2e6`,`#ffa8a8`,`#faa2c1`,`#e599f7`,`#b197fc`,`#91a7ff`,`#74c0fc`,`#66d9e8`,`#63e6be`,`#8ce99a`,`#c0eb75`,`#ffe066`,`#ffc078`],
	[`#ced4da`,`#ff8787`,`#f783ac`,`#da77f2`,`#9775fa`,`#748ffc`,`#4dabf7`,`#3bc9db`,`#38d9a9`,`#69db7c`,`#a9e34b`,`#ffd43b`,`#ffa94d`],
	[`#adb5bd`,`#ff6b6b`,`#f06595`,`#cc5de8`,`#845ef7`,`#5c7cfa`,`#339af0`,`#22b8cf`,`#20c997`,`#51cf66`,`#94d82d`,`#fcc419`,`#ff922b`],
	[`#868e96`,`#fa5252`,`#e64980`,`#be4bdb`,`#7950f2`,`#4c6ef5`,`#228be6`,`#15aabf`,`#12b886`,`#40c057`,`#82c91e`,`#fab005`,`#fd7e14`],
	[`#495057`,`#f03e3e`,`#d6336c`,`#ae3ec9`,`#7048e8`,`#4263eb`,`#1c7ed6`,`#1098ad`,`#0ca678`,`#37b24d`,`#74b816`,`#f59f00`,`#f76707`],
	[`#343a40`,`#e03131`,`#c2255c`,`#9c36b5`,`#6741d9`,`#3b5bdb`,`#1971c2`,`#0c8599`,`#099268`,`#2f9e44`,`#66a80f`,`#f08c00`,`#e8590c`],
	[`#212529`,`#c92a2a`,`#a61e4d`,`#862e9c`,`#5f3dc4`,`#364fc7`,`#1864ab`,`#0b7285`,`#087f5b`,`#2b8a3e`,`#5c940d`,`#e67700`,`#d9480f`]
]

/*
	This creates a dropdown selector that can be used to input most native Harlowe values.

	modelCallback is a callback to use instead of setting a value on the model in their model() methods.
	modelRegistry is an alternative array to register the model() methods to, instead of the one for the parent panel.
	Both of these are used entirely by datavalue-rows and datavalue-map, in order to suppress the usual behaviour of panel rows,
	and to be able to dynamically add and remove rows during use.

	noComplexValues prevents the UI from becoming too complicated by removing "+ value" entries when this is a nested row.
*/
const dataValueRow = <T>(modelCallback = (m:Model<T>,v:string) => {m.expression = v}, modelRegistry?: PartialModelMethod<T>[], noComplexValues = false) => (<PanelRow<T>>{
	type: `inline-dropdown-rows`,
	text: `Value: `,
	name: `variable-datatype`,
	width: `16%`,
	options: [
		[`text string`, {
			type: `inline-string-textarea`,
			width:`55%`,
			text: ``,
			placeholder: `Text`,
			modelCallback,
			modelRegistry,
		}],
		[`number`, {
			type: `inline-number-textarea`,
			width:`20%`,
			text: ``,
			modelCallback,
			modelRegistry,
		}],
		[`Boolean value`, {
			type: `inline-dropdown`,
			text: ``,
			options: [`false`,`true`],
			model(m, el) {
				modelCallback(m, `${!!el[$](`select`)!.value}`)
			},
			modelRegistry,
		}],
		[`colour`, {
			type: `inline-colour`,
			text: ``,
			value: `#ffffff`,
			model(m, el) {
				const c = (<HTMLInputElement>el[$](`[type=color]`)).value,
					a = +(<HTMLInputElement>el[$](`[type=range]`)).value
				modelCallback(m, toHarloweColour(c, a))
			},
			modelRegistry,
		}],
		[`array`, {
			type: `datavalue-rows`,
			text: `<div class='harlowe-4-datavalueRowHint'>An <b>array</b> is a sequence of ordered datavalues that can be used without having to create separate variables for each. `
				+ `Use it to store similar values whose order and position matter, or to store an ever-changing quantity of similar values.</div>`,

			modelRows(m, rowValues) {
				modelCallback(m, `(a:${rowValues})`)
			},
			/*
				This is a special method for datavalue-rows that displays numbers (usually array indices) for each subvalue's line.
			*/
			renumber(label,num) {
				num += 1
				const lastDigit = `${num}`.slice(-1)
				
				label.textContent = `${num +
					(lastDigit === `1` ? `st` :
					lastDigit === `2` ? `nd` :
					lastDigit === `3` ? `rd` : `th`)}: `
			},
			modelRegistry,
		}],
		[`datamap`, {
			type: `datavalue-map`,
			text: `<div class='harlowe-4-datavalueRowHint'>A <b>datamap</b> is a value that holds any number of other values, each of which is "mapped" to a unique name. `
				+ `Use it to store data values that represent parts of a larger game entity, or rows of a table.</div>`,
			modelRows(m, rowValues) {
				/*
					Unlike arrays, datamaps have a constraint on their data names: they must not be empty.
				*/
				if (!rowValues.every((e,i) => i % 2 !== 0 || (e !== `""` && e !== `''`))) {
					// Any panel that consumes dataValueRow() should invalidate the model if this is true.
					m.invalidSubrow = true
				}
				modelCallback(m, `(dm:${rowValues})`)
			},
			/*
				Datamaps don't have sequential name labels, instead having just a colon.
			*/
			renumber(label) {
				label.textContent = `:`
			},
			modelRegistry,
		}],
		[],
		[`randomly chosen value`, {
			type: `datavalue-rows`,
			text: `<div class='harlowe-4-datavalueRowHint'>One of the following values is randomly chosen <b>each time the macro is run</b>.</div>`,
			modelRows(m, rowValues) {
				if (!rowValues.length) {
					m.invalidSubrow = true
				}
				modelCallback(m, `(either:${rowValues})`)
			},
			renumber(label) {
				label.textContent = `•`
				label.style.marginRight=`0.5em`
			},
			modelRegistry,
		}],
		[`random number`, el(`<div class='harlowe-4-datavalueRowHint'>A number between these two values is randomly chosen <b>each time the macro is run</b>.</div>`), {
			type: `inline-number-textarea`,
			width:`20%`,
			text: `From`,
			model() {},
			modelRegistry,
		},{
			type: `inline-number-textarea`,
			width:`20%`,
			text: `to`,
			model(m, elem) {
				modelCallback(m, `(random:${+(<HTMLInputElement>elem.previousElementSibling![$](`input`)).value || 0},${+(<HTMLInputElement>elem[$](`input`)).value || 0})`)
			},
			modelRegistry,
		}],
		...noComplexValues ? [] : <[string, ...PanelRow<T>[]][]>[
			[],
			[`itself + value`, {
				type: `datavalue-inner`,
				text: `<div class='harlowe-4-datavalueRowHint'>The following value is added to the existing value in the variable. NOTE: if the values aren't the same type of data, an error will result.</div>`,
				modelRows(m, rowValues) {
					if (rowValues.length !== 1) {
						m.invalidSubrow = true
					}
					modelCallback(m, `it + ${rowValues}`)
				},
				renumber(label) {
					label && (label.textContent = `it + `)
				},
				modelRegistry,
			}],
			[`variable + value`,
				{
					type: `inline-dropdown`,
					text: ` Other variable: `,
					options: [`$`, `_`],
					model(m, elem) {
						/*
							Because variable + value rows cannot be nested or included in datavalue-rows,
							the other variable must be stored on the model.
						*/
						m.innerVariable = (<HTMLSelectElement>elem[$](`select`)).value ? `_` : `$`
					},
				},{
					type: `inline-textarea`,
					width:`25%`,
					text: ``,
					placeholder: `Variable name`,
					model(m, elem) {
						const v = (<HTMLInputElement>elem[$](`input`)).value
						if (v) {
							if (RegExp(`^${Patterns.validPropertyName}$`).exec(v) && !RegExp(/^\d/).exec(v)) {
								m.innerVariable += v
							}
						}
					},
				},{
					type: `datavalue-inner`,
					text: `<div class='harlowe-4-datavalueRowHint'>The above variable's value and the value below are added together. NOTE: if the values aren't the same type of data, an error will result.</div>`,
					modelRows(m, rowValues) {
						if (rowValues.length !== 1) {
							m.invalidSubrow = true
						}
						modelCallback(m, `${m.innerVariable} + ${rowValues}`)
					},
					renumber(label) {
						label && (label.textContent = ``)
					},
					modelRegistry,
				}
			],
		],
		[],
		[`coded expression`, {
			type: `expression-textarea`,
			width:`90%`,
			text: `<div>Write a Harlowe code expression that should be computed to produce the desired value.</div>`,
			placeholder: `Code`,
			modelCallback,
			modelRegistry,
		}],
	]
})

/*
	The constructor for the folddownPanels. This accepts a number of panel rows (as an array of row-describing objects)
	and returns a <div> with the compiled UI elements.

	Each row object typically has the following:
	- update: A function taking the entire panel element, and performing actions whenever this element's value is altered.
	- name: User-facing display name of this element.
	- type: Which type of UI element to create for it.

	Note: panel creation is deferred until first access - hence, this returns a zero-arity function.

	The type variable T represents an object type of additional values that the Model for this particular Panel could have.
*/
const folddownPanel = <T>(...panelRows:(PanelRow<T> | HTMLElement | Text)[]) => () => {

	if (!panelRows.length) {
		return el(`<div>`)
	}
	/*
		The MVC-style flow of element states into data, and back, is performed here.
		Elements can register "model" and "update" functions. Model functions take a model object
		(seen in the reduce() call below) and permute it with the element's data. Update functions
		take the completed model object and permutes the element using it.
		Generally, each element has an addEventListener call in its implementation (below) which
		causes them to call update() whenever they're interacted with.
	*/
	/*
		These two arrays store Curried model methods and updater methods.
	*/
	const modelFns: PartialModelMethod<T>[] = [], updaterFns: PartialModelMethod<T>[] = []
	function output(this:Model<T>) {
		return Object.entries(this.changers).map(([k,v]) => `(${k}:${v.join(`,`)})`).join(`+`)
	}
	function changerNamed(this:Model<T>, name:string) {
		return (this.changers[name] ||= [])
	}
	// eslint-disable-next-line @typescript-eslint/prefer-reduce-type-parameter
	const model = (initiator?: HTMLElement) => modelFns.reduce((m:Model<T>, fn) => (fn(m), m), <Model<T>><unknown>{
		changers: {},
		wrapStart: `[`, wrapEnd: `]`,
		wrapStringify: false,
		innerText: undefined,
		// If the model is declared valid, then code can be produced using the panel as it currently is.
		valid: false,
		output,
		changerNamed,
		initiator,
	})
	function update({target}: Event = <Event>{ target:null }) {
		const m = model(<HTMLElement>target ?? undefined)
		updaterFns.forEach(fn => fn(m))
	}
	/*
		Since this is defined after update(), storing update() on it later should not cause a circular reference.
	*/
	const panelElem = el(`<div class="harlowe-4-toolbarPanel${!twine23 ? ` card floating` : ``}" style="transition:max-height 0.8s;overflow-y:auto">`)

	const makeColourPicker = (value:string) => {
		const makeSwatchRow = (colours:string[], index:string|number, visible?:boolean) =>
			el(`<span class=harlowe-4-swatchRow data-index="${index}" ${!visible ? `style="display:none"` : ``}>${
				colours.map(colour =>
					`<span class=harlowe-4-swatch style="background-color:${colour}"></span>`).join(``)
				}</span>`)

		const ret = el(`<div class=harlowe-4-singleColourPicker><input style="width:48px;margin-right:8px" type=color value="${value}"></div>`)
		const swatchSelectWrapper = el(`<span class="text-select-control"><select ${!twine23 ? `style="max-width: 9em;"` : ``}><option value="" selected>Harlowe built-ins</option></select></span>`)
		const swatchSelect = swatchSelectWrapper[$](`select`)
		ret.append(makeSwatchRow(Object.keys(builtinColourNames), ``, true))
		openColors.forEach((row,i) => {
			ret.append(makeSwatchRow(row, i))
			swatchSelect?.append(el(`<option value=${i}>OpenColor ${i}</option>`))
		})
		swatchSelect?.[ON](`change`, () => {
			ret[$$](`[data-index]`).forEach(ind => (<HTMLElement>ind).style.display = `none`)
			;(<HTMLElement>ret[$](`[data-index="${swatchSelect.value}"]`)).style.display = `inline-block`
		})
		ret.append(swatchSelectWrapper, el(`<br>`), new Text(`Opacity: `), el(`<input type=range style="width:64px;top:8px;position:relative" value=1 min=0 max=1 step=0.05>`))

		ret[ON](`click`, ({target}) => {
			if (target instanceof HTMLElement && target.classList.contains(`harlowe-4-swatch`)) {
				const input = ret[$](`input`)
				if (input) {
					input.value = target?.getAttribute(`style`)?.slice(-7) || ``
					input.dispatchEvent(new Event(`change`))
				}
			}
		})
		return ret
	}

	/*
		Turn each panel row description into a panel element. Notice that this reducer function
		can be recursively called, with a different element in accumulator position; this is
		used by radiorows to add its sub-elements.
	*/
	const ret = panelRows.reduce(function reducer(panelElem: HTMLElement, row: PanelRow<T> | HTMLElement | Text): HTMLElement {
		let ret:HTMLElement|undefined, inline
		const nested = panelElem instanceof HTMLElement && panelElem.tagName.toLowerCase() === `label`
		if (row instanceof Node) {
			panelElem.append(row)
			return panelElem
		}
		inline = row.type.startsWith(`inline`)
		if (panelElem instanceof HTMLElement) switch (row.type) {
			/*
				These are non-interactive messages.
			*/
			case `text`: case `inline-text`:
				ret = el(`<${inline ? `span` : `div`}>${row.text}</${inline ? `span` : `div`}>`)
			break; case `notice`: case `small`:
				ret = el(`<small style="display:block">${row.text}</small>`)
			/*
				Used only for the default panel and the Find panel.
			*/
			break; case `buttons`:
				panelElem.append(...row.buttons.map(button => {
					if (`tagName` in button) {
						return button
					}
					const elem = el(`<button title="${button.title}" class="${buttonClass()}${button.active ? ` active` : ``}${button.danger ? ` variant-danger` : ``}">${button.html}</button>`)
					button.onClick && elem[ON](`click`, button.onClick)
					button.update && updaterFns.push(m => button.update!(m, elem))
					return elem
				}))
			break; case `preview`: case `t8n-preview`: {
				const t8n = row.type === `t8n-preview`
				/*
					The (text-style:) preview panel.
				*/
				const tagName = row.tagName || `span`
				ret = el(`<div class="harlowe-4-stylePreview" style="${t8n ? `cursor:pointer;height: 2.6rem;` : ``}" ${
					t8n ? `alt="Click to preview the transition"` : ``}><${tagName}>${row.text || ``}</${tagName}>${t8n ? `<${tagName}>${row.text2}</${tagName}>` : ``}</div>`)

				if (t8n) {
					ret[ON](`mouseup`, update)
					ret[ON](`touchend`, update)
					const firstSpan:HTMLElement = ret[$](`:first-child`)!
					firstSpan[ON](`animationend`, () => firstSpan.style.visibility = `hidden`)
				}
			/*
				Checkboxes and radio buttons.
			*/
			} break; case `checkbox`: case `checkboxrow`: case `inline-checkbox`:
				ret = el(`<label${inline ? `` : ` style="display:block"`} class="harlowe-4-checkboxRow"><input type="checkbox" ${`persist` in row && row.persist ? `data-persist` : ``}></input>${row.text}</label>`)
				if (row.type === `checkboxrow`) {
					(<PanelRow<T>[]>row.subrow).reduce(reducer, ret)
					row.subrow.forEach(r => {
						if (r instanceof Node) {
							return
						}
						const model = r.model!
						r.model = (m, el) => {
							return (<HTMLElement>ret)[$](`:scope > input:checked`)
								/*
									Don't run the subrow's model unless the parent row's radio button is checked.
								*/
								&& (!nested || panelElem[$](`:scope > input:checked`)) ? model(m, el) : m
						}
					})
				}
				ret[ON](`change`, update)
			break; case `checkboxes`:
				ret = el(`<div class="harlowe-4-toolbarCheckboxes" ${row.bottomBorder === false ? ` style="border:none"` : ``}><div${row.bold ? ` style="font-weight:bold"` :``}>${row.name}</div></div>`)
				row.options.forEach((box,i) => {
					const e = el(`<label${row.capitalise ? ` style="text-transform:capitalize;"` : ``} class="${buttonClass()}"><input type="checkbox" ${row.persist ? `data-persist` : ``} ${
						// Determines the initial state of the checkbox. When the panel is closed, switchPanel() resets it to checked if it has the attr.
						row.checked?.(i) ? `checked` : ``
					}></input>${box}</label>`)
					e[ON](`change`, update)
					;(<HTMLElement>ret).append(e)
				})
			break; case `radios`:
				ret = el(`<div class="harlowe-4-toolbarCheckboxes"><div${row.bold ? ` style="font-weight:bold"`:``}>${row.name}</div></div>`)
				row.options.forEach((radio,i) => {
					const e = el(`<label${row.capitalise ? ` style="text-transform:capitalize;"` : ``} class="${buttonClass()}"><input type="radio" name="${row.name}" value="${radio}" ${!i ? `checked` : ``} ${row.persist ? `data-persist` : ``}></input>${radio}</label>`)
					e[ON](`change`, update)
					;(<HTMLElement>ret).append(e)
				})
			/*
				Text areas, single lines in which text can be entered.
			*/
			break; case `textarea`: case `inline-textarea`: case `inline-string-textarea`: case `inline-passage-textarea`: case `inline-number-textarea`: case `expression-textarea`: {
				let inputType = `text`
				const tagName = `multiline` in row && row.multiline ? `textarea` : `input`
				/*
					Full Harlowe expressions.
				*/
				if (row.type === `expression-textarea`) {
					/*
						These have special update and model routines.
					*/
					row.update = (m, elem) => {
						if (!m.expression && (<HTMLInputElement>elem[$](tagName)).value) {
							elem.setAttribute(`invalid`, `This doesn't seem to be valid code.`)
						}
						else {
							elem.removeAttribute(`invalid`)
						}
					}
					row.model = (m, elem) => {
						const v = ((<HTMLInputElement>elem[$](tagName)).value || ``).trim()
						if (v) {
							/*
								Attempt to lex the data, and consider it invalid if it contains any text nodes.
							*/
							const lexed = lex(v, ``, `macro`)
							if (lexed.children.every(function recur(token):boolean {
								return token.type !== `text` && token.type !== `error` &&
									(token.type === `string` || token.type === `hook` || token.children.every(recur))
							})) {
								row.modelCallback(m,v)
								return
							}
							m.valid = true
						}
					}
				}
				/*
					String-type textarea
				*/
				if (row.type === `inline-string-textarea`) {
					row.model ||= (m, elem) => {
						row.modelCallback(m, JSON.stringify(((<HTMLInputElement>elem[$](tagName)).value || ``)))
					}
				}
				if (row.type === `inline-number-textarea`) {
					inputType = `number`
					row.model ||= (m, elem) => {
						row.modelCallback(m, +(<HTMLInputElement>elem[$](tagName)).value || 0)
					}
				}
				ret = el(`<${inline ? `span` : `div`} class="harlowe-4-labeledInput">${
						row.text
					}<${tagName} ${`useSelection` in row && row.useSelection ? `data-use-selection` : ``}${row.type.includes(`passage`) ? `list="harlowe-4-passages"` : ``} style="width:${row.width};${`multiline` in row && row.multiline ? `max-width:${row.width};` : ``}padding:var(--grid-size);margin${
						inline ? `:2px 0.5rem 0 0.5rem` : `-left:1rem`
					};${`multiline` in row && row.multiline && inline ? `display:inline-block;height:40px`:``}" type=${inputType} ${`persist` in row && row.persist ? `data-persist` : ``} placeholder="${row.placeholder || ``}"></${tagName}></${inline ? `span` : `div`}>`)
				ret[$](tagName)![ON](`input`, update)

			} break; case `inline-number`: case `range`: case `inline-range`:
				ret = el(`<${inline ? `span` : `div`} class="harlowe-4-labeledInput">${
						row.text
					}<input style="padding:var(--grid-size);${row.width ? `width:${row.width}` : ``}" type=${
						row.type.endsWith(`range`) ? `range` : `number`
					} min=${row.min} max=${row.max} value=${row.value}${row.step ? ` step=${row.step}` : ``}></input></${inline ? `span` : `div`}>`)
				ret[$](`input`)![ON](row.type.endsWith(`range`) ? `input` : `change`, update)

			break; case `inline-colour`: {
				ret = el(`<${inline ? `span` : `div`} class="harlowe-4-labeledInput">${
						row.text
					}</${inline ? `span` : `div`}>`)
				const picker = makeColourPicker(row.value)
				ret.append(picker)
				ret[$$](`input`).forEach(input => input[ON](`change`, update))
			} break; case `gradient`: {
				ret = el(`<div style='position:relative'><span class=harlowe-4-gradientBar></span><button class="${buttonClass()}">${fontIcon(`plus`)} Colour</button></div>`)
				const gradientBar: HTMLElement = ret[$](`.harlowe-4-gradientBar`)!
				const createColourStop = (percent:number, colour:string, selected?:boolean) =>  {
					const ret = el(
						`<div ${selected ? `selected` : ``} data-colour="${
							colour
						}" data-pos="${percent}" class=harlowe-4-colourStop style="left:calc(${
							percent * 100
						}% - 8px); top:-8px"><div class=harlowe-4-colourStopButtons style="left:${-(twine23 ? 464 : 384)*percent - (twine23 ? 0 : 40)}px">`
						+ `</div></div>`
					)
					const picker = makeColourPicker(colour)
					picker[$$](`input`).forEach(input => input[ON](`change`, () => {
						const alpha = (<HTMLInputElement>picker[$](`input[type=range]`)).value
						const colour = (<HTMLInputElement>picker[$](`[type=color]`)).value
						ret.setAttribute(`data-colour`, toCSSColour(colour, alpha))
						if (+alpha < 1) {
							ret.setAttribute(`data-harlowe-colour`, toHarloweColour(colour, +alpha))
						}
						update()
					}))
					const deleteButton = el(`<button class="${buttonClass()}" style='float:right'>${fontIcon(`times`)} Delete</button>`)
					deleteButton[ON](`click`, () => { ret.remove(); update() })
					picker.append(deleteButton)
					ret.firstElementChild?.prepend(picker)
					gradientBar.append(ret)
					update()
				}
				setTimeout(() => {
					createColourStop(0, `#ffffff`)
					createColourStop(0.5, `#000000`, true)
					createColourStop(1, `#ffffff`)
				})

				ret[$](`button`)![ON](`click`, () => createColourStop(0.5, `#888888`))
				const listener = ({target}: Event) => {
					if (target instanceof HTMLElement && target.classList.contains(`harlowe-4-colourStop`)) {
						const html = document.documentElement
						const {left, right} = gradientBar.getBoundingClientRect()
						const width = right - left
						const onMouseMove = (e: TouchEvent|MouseEvent) => {
							let pageX = `pageX` in e ? e.pageX : e.touches[0].pageX
							if (pageX === undefined) {
								return
							}
							const pos = Math.min(1,Math.max(0,(pageX - window.scrollX - left) / width))
							target.style.left = `calc(${pos * 100}% - 8px)`
							/*
								Reposition the colour stop's button bar so that it's always entirely visible.
							*/
							;(<HTMLElement>target.firstChild).style.left = `${-(twine23 ? 464 : 384)*pos - (twine23 ? 0 : 40)}px`
							target.setAttribute(`data-pos`, `${pos}`)
							update()
						}
						const onMouseUp = () => {
							html[OFF](`mousemove`, onMouseMove)
							html[OFF](`mouseup`, onMouseUp)
							html[OFF](`touchmove`, onMouseMove)
							html[OFF](`touchend`, onMouseUp)
						}
						html[ON](`mousemove`, onMouseMove)
						html[ON](`mouseup`, onMouseUp)
						html[ON](`touchmove`, onMouseMove)
						html[ON](`touchend`, onMouseUp)

						/*
							Additionally, when a stop is clicked, deselect all other stops and select this one,
							causing its menu to appear.
						*/
						Array.from(gradientBar[$$](`[selected]`)).forEach(s => s.removeAttribute(`selected`))
						target.setAttribute(`selected`, `${true}`)
					}
				}
				ret[ON](`mousedown`, listener)
				ret[ON](`touchstart`, listener)

				updaterFns.push(() => {
					gradientBar.style.background = `linear-gradient(to right, ${
						Array.from(gradientBar[$$](`.harlowe-4-colourStop`))
							.sort((a,b) => (+a.getAttribute(`data-pos`)! || 0) - (+b.getAttribute(`data-pos`)! || 0))
							.map(stop => `${stop.getAttribute(`data-colour`)} ${(+stop.getAttribute(`data-pos`)! || 0)*100}%`)
					})`
				})
			/*
				Dropdowns.
			*/
			} break; case `dropdown`: case `inline-dropdown`: {
				const dropdownDiv = el(`<${inline ? `span` : `div`} style="white-space:nowrap;${inline ? `` : `width:50%;`}position:relative;">${
					row.text
				}<span class="text-select-control"><select style="${inline ? `margin:0.5rem;` : `margin-left:1rem;`}font-size:0.9rem;margin-top:4px" ${row.persist ? `data-persist` : ``}></select></span></${inline ? `span` : `div`}>`)
				row.options.forEach((option,i) => {
					dropdownDiv[$](`select`)?.append(el(`<option value="${!i ? `` : option}"${!option ? ` disabled` : !i ? ` selected` : ``}>${option || `───────`}</select>`))
				})
				dropdownDiv[$](`select`)?.[ON](`change`, update)
				ret = dropdownDiv
			/*
				Rows of options, selected using radio buttons.
			*/
			} break; case `radiorows`:
				ret = el(`<div>`)
				row.options.forEach((subrows,i) => {
					if (subrows instanceof HTMLElement) {
						return
					}
					const subrowEl = el(`<label class='harlowe-4-radioRow'><input type="radio" name="${row.name}" value="${!i ? `none` : i}" ${!i ? `checked` : ``}></input></label>`)
					/*
						Place each of these sub-options within the <label>.
					*/
					;(<HTMLElement>ret).append((<PanelRow<T>[]>subrows).reduce(reducer, subrowEl))
					/*
						Wrap each of the subrows' model functions, so that they only fire whenever this row is actually selected.
					*/
					subrows.forEach(subrow => {
						if (subrow instanceof Node) {
							return
						}
						const {model} = subrow
						if (model) {
							subrow.model = (m, el) => {
								return subrowEl[$](`:scope > input:checked`)
								/*
									Don't run the subrow's model unless the parent row's radio button is checked.
								*/
								&& (!nested || panelElem[$](`:scope > input:checked`)) ? model(m, el) : m
							}
						}
					})
					subrowEl[$](`input`)?.[ON](`change`, update)
				})
			break; case `macro-list`: {
				ret = el(`<div><div style="text-align:center">Category: </div></div>`)
				const categorySelectorWrapper = el(`<span class='text-select-control'><select></span>`)
				;(<HTMLElement>ret.firstChild).append(categorySelectorWrapper)
				const categorySelector = categorySelectorWrapper[$](`select`)
				const scrollBox = el(`<div style="margin-top:8px;border-top:1px solid hsla(0,0%,50%,0.5);max-height:40vh;overflow-y:scroll">`)
				ret.append(scrollBox)
				categorySelector?.[ON](`change`, () => {
					const el = scrollBox[$](`[name="${categorySelector.value}"]`)
					el?.scrollIntoView()
				})
				Object.values(ShortDefs.Macro)
					.sort(({name:leftName, category:leftCategory, categoryOrder:leftCategoryOrder}, {name:rightName, category:rightCategory, categoryOrder:rightCategoryOrder}) => {
						/*
							Sort alphabetically, then by explicit order number.
						*/
						if (leftCategory !== rightCategory) {
							return (leftCategory || ``).localeCompare(rightCategory || ``)
						}
						if (leftCategoryOrder !== rightCategoryOrder) {
							if (isNaN(+leftCategoryOrder)) {
								return 1
							}
							if (isNaN(+rightCategoryOrder)) {
								return -1
							}
							return Math.sign(+leftCategoryOrder - +rightCategoryOrder)
						}
						return leftName.localeCompare(rightName)
					})
					.forEach((defs, i, a) => {
						// Add category titles whenever the category changes.
						if (i === 0 || defs.category !== a[i-1].category) {
							scrollBox.append(el(`<h3 style="text-transform:capitalize" name="${defs.category}">${defs.category}</h3>`))
							categorySelector?.append(el(`<option value="${defs.category}">${defs.category}</option>`))
						}
						// Filter out doubles (created by macro aliases).
						if (i > 0 && defs.name === a[i-1].name) {
							return
						}

						const subrowEl = el(`<label class='harlowe-4-radioRow'><input type="radio" name="macro-list" value="${defs.name}"></input>`
							+ `<code><a href="https://twine2.neocities.org/#${defs.anchor}" target="_blank" rel="noopener noreferrer">(${defs.name}: ${defs.sig}) → ${defs.returnType}</a></code>`
							+ `${defs.aka.length ? `<div><i>Also known as: ${
								defs.aka.map(alias => `<code>(${alias}:)</code>`).join(`, `)
							}</i>` : ``}</div><div>${
								defs.abstract.replace(/`([^`]+)`/g, (_, inner) => `<code>${inner}</code>`)
							}</div></label>`
						)
						scrollBox.append(subrowEl)
						subrowEl[$](`input`)?.[ON](`change`, update)
					})
			
			} break; case `inline-dropdown-rows`: {
				/*
					Rows of options, selected using a single dropdown.
				*/
				ret = el(`<${inline ? `span` : `div`}><span class="harlowe-4-dropdownRowLabel">${
						row.text
					}</span><span class="text-select-control"><select style="font-size:1rem;margin-top:4px;${
						row.width ? `width:${row.width};text-overflow:ellipsis` : ``
					}"></select></span><span class="harlowe-4-dropdownRows"></span></${inline ? `span` : `div`}>`)
				const selectEl = ret[$](`select`)!
				row.options.forEach(([name, ...subrows], i) => {
					if (!name) {
						selectEl.append(el(`<option disabled>───────</option>`))
						return
					}
					selectEl.append(el(`<option value="${name}" ${!i ? `selected` : ``}>${name}<option>`))
					const subrowEl = el(`<span data-value="${name}" ${i ? `hidden` : ``}>`)
					/*
						Place each of these sub-options within the .harlowe-4-dropdownRows.
					*/
					;(<HTMLElement>ret)[$](`.harlowe-4-dropdownRows`)!.append(subrows.reduce(reducer, subrowEl))

					subrows.forEach(subrow => {
						const {model} = subrow
						if (model) {
							subrow.model = (m, el) => {
								return selectEl.value === name
								/*
									Don't run the subrow's model unless the parent row's radio button is checked.
								*/
								&& (!nested || panelElem[$](`:scope > input:checked`)) ? model(m, el) : m
							}
						}
					})
				})
				selectEl[ON](`change`, () => {
					const value = selectEl.value
					;(<HTMLElement>ret)[$$](`:scope > .harlowe-4-dropdownRows > span`).forEach(el => {
						el[`${el.getAttribute(`data-value`) === value ? `remove` : `set`}Attribute`](`hidden`,``)
					})
					update()
				})
			} break; case `textarea-rows`: {
				/*
					A column of textareas, but with buttons to add and subtract additional ones.
				*/
				ret = el(`<div class="harlowe-4-textareaRows ${row.nonZeroRows ? `harlowe-4-nonZeroRows` : ``}">`)
				const makeRow = () => {
					if ((<HTMLElement>ret).childNodes.length > 100) {
						return
					}
					const line = el(`<div class="harlowe-4-dataRow"><input type=text style="width:80%;padding:var(--grid-size)" placeholder="${row.placeholder}"></input><button class="${buttonClass()} harlowe-4-rowMinus">${
							fontIcon(`minus`)
						}</button><button class="${buttonClass()} harlowe-4-rowPlus">${
							fontIcon(`plus`)
						}</button></div>`)
					line[$](`input`)?.[ON](`input`, update)
					line[$](`.harlowe-4-rowPlus`)?.[ON](`click`, () => { makeRow(); update() })
					line[$](`.harlowe-4-rowMinus`)?.[ON](`click`, () => { line.remove(); update() })
					;(<HTMLElement>ret).append(line)
				}
				makeRow()
			} break; case `datavalue-inner`: {
				ret = el(`<div class="harlowe-4-dataRow" style='margin:0.2em 0px'>${row.text}</div>`)
				const modelRegistry: PartialModelMethod<T>[] = []
				let rowValuesBuffer: string[] = []

				reducer(ret, dataValueRow((_,v) => rowValuesBuffer.push(v), modelRegistry, true))

				const innerModel = row.modelRows
				row.model = m => {
					/*
						The process for actually obtaining a value from the child rows is:
						clear the rowValues buffer, then populate it by firing all of the model() methods
						that were captured in the modelRegistry.
					*/
					rowValuesBuffer = []
					modelRegistry.reduce((m, fn) => (fn(m), m), m)
					innerModel?.(m, rowValuesBuffer)
				}
				row.renumber(ret[$](`:scope > * > .harlowe-4-dropdownRowLabel`)!)

			} break; case `datavalue-rows`: case `datavalue-map`: {
				/*
					Datavalue rows are rows of inputs for Harlowe data values, which can be added and subtracted.
					Each Harlowe input is a special row created by dataValueRow(), above.
					Datavalue-map is a special case where the position name is an inline-textarea input, meaning
					each line has two inputs each.
				*/
				ret = el(`<div class="harlowe-4-datavalueRows">${row.text || ``}<div class="harlowe-4-dataEmptyRow"><i>No data</i></div><button class="${buttonClass()} harlowe-4-rowPlus">${
						fontIcon(`plus`)
					} Value</button></div>`)
				const plusButton = ret[$](`.harlowe-4-rowPlus`)

				/*
					Unlike every other panel row implemented, this dynamically creates and destroys other panel rows.
					As such, some special measures have to be taken to allow this row to still act like a normal row,
					and for its subrows to be entirely subordinate to it.
					In order to capture and suppress the model() methods of each subrow, two closure variables are needed:
					a modelRegistry, which vaccuums up the model() methods of subrows as they are created (by being passed to
					dataValueRow() in position 2) and a rowValuesBuffer, which is pushed to in place of assigning to the model
					in each row's model() methods (see above), using the callback argument to dataValueRow() in position 1.
				*/
				const childModelMethods = new Set<PartialModelMethod<T>>()
				let rowValuesBuffer: string[] = []
				/*
					A utility to ensure that each datavalue-row's "Value:" label is replaced with "1st", "2nd" and so forth.
				*/
				const renumber = () => {
					// eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
					(<HTMLElement[]>Array.from((<HTMLElement>ret)[$$](`:scope > .harlowe-4-dataRow > * > .harlowe-4-dropdownRowLabel`))).forEach(row.renumber)
				}
				const makeRow = () => {
					if ((<HTMLElement>ret).childNodes.length > 50) {
						return
					}
					const line = el(`<div class="harlowe-4-dataRow">`)
					/*
						The model() methods of this line's subrows are captured in this array, as well as the childModelMethods set.
						This is to allow them to be deleted from the set once the line is removed.
					*/
					const modelRegistry: PartialModelMethod<T>[] = []
					;(<HTMLElement>ret).insertBefore(
						[
							...row.type.endsWith(`map`) ? [<PanelRow<T>>{
								type: `inline-textarea`,
								text: ``,
								placeholder: `Data name`,
								width:`15%`,
								model(_, elem) {
									rowValuesBuffer.push(stringify(elem[$](`input`)!.value))
								},
								modelRegistry,
							}] : [],
							dataValueRow((_,v) => {rowValuesBuffer.push(`${v}`)}, modelRegistry, true)
						].reduce(reducer, line), plusButton)

					modelRegistry.forEach(m => childModelMethods.add(m))

					line.append(el(`<button class="${buttonClass()} harlowe-4-rowMinus">${
							fontIcon(`minus`)
						}</button>`))
					line[$](`:scope > .harlowe-4-rowMinus`)?.[ON](`click`, () => {
						line.remove()
						/*
							When the line is removed, all of its model() methods must be freed, too.
						*/
						modelRegistry.forEach(m => childModelMethods.delete(m))
						if ((<HTMLElement>ret).childNodes.length === 0) {
							makeRow()
						}
						update()
						renumber()
					})
				}
				const {modelRows} = row
				row.model = m => {
					/*
						The process for actually obtaining a value from the child rows is:
						clear the rowValues buffer, then populate it by firing all of the model() methods
						that were captured in the modelRegistry.
					*/
					rowValuesBuffer = []
					;[...childModelMethods].reduce((m, fn) => (fn(m), m), m)
					modelRows?.(m, rowValuesBuffer)
				}
				plusButton![ON](`click`, () => { makeRow(); update(); renumber() })

			} break; case `scroll-wrapper`:
				ret = el(`<div class="harlowe-4-scrollWrapper"></div>`)
				row.contents.reduce(reducer, ret)

			/*
				The "Create" and "Cancel" buttons. This is always the last row of a panel.
			*/
			break; case `confirm`: {
				/*
					If this is Twine 2.4, wrap all preceding elements inside a scrollable container div.
					This is a special convenience hack that saves me having to use "scroll-wrapper" a lot.
				*/
				if (!twine23) {
					const wrapper = el(`<div class="harlowe-4-scrollWrapper"></div>`)
					wrapper.append(...panelElem.childNodes)
					panelElem.append(wrapper)
				}
				const buttons = el(`<div class="harlowe-4-confirmButtons" style="padding-bottom:8px;"></div>`)
				const cancel = el(`<button class="${buttonClass()}">${fontIcon(`times`)} Cancel</button>`)
				const confirm = el(`<button class="${buttonClass(true)} create">${fontIcon(`check`)} Add</button>`)
				confirm.setAttribute(`style`, disabledButtonCSS)
				updaterFns.push(m => {
					const setAttr = !m.valid ? `setAttribute` : `removeAttribute`
					confirm[setAttr](`style`, disabledButtonCSS)
					if (m.valid) {
						if (typeof m.wrapStart === `function`) {
							m.wrapStart = m.wrapStart(m)
						}
						if (typeof m.wrapEnd === `function`) {
							m.wrapEnd = m.wrapEnd(m)
						}
					}
				})
				
				/*
					Because of a circular dependency, switchPanel and wrapSelection are injected into this module's exported object by Toolbar.
				*/
				cancel[ON](`click`, () => ToolbarPanel.switchPanel())
				confirm[ON](`click`, () => {
					const m = model()
					if (typeof m.wrapStart === `function`) {
						m.wrapStart = m.wrapStart(m)
					}
					if (typeof m.wrapEnd === `function`) {
						m.wrapEnd = m.wrapEnd(m)
					}
					ToolbarPanel.wrapSelection(m.output() + m.wrapStart, m.wrapEnd, ``, m.innerText, m.wrapStringify)
					ToolbarPanel.switchPanel()
				})
				buttons.append(cancel,confirm)
				ret = buttons
			}
			break; default:
				console.error(`Invalid PanelRow type: ${row.type}`)
				return panelElem
		}
		if (nested) {
			const u = row.update
			row.update = (m, el) => {
				const checked = panelElem[$](`:scope > input:checked`)
				Array.from(panelElem[$$](`div,br ~ *`)).forEach(e => e[`${checked ? `remove` : `set`}Attribute`](`hidden`,``))
				Array.from(panelElem[$$](`input,select`)).slice(1).forEach(e => e[`${checked ? `remove` : `set`}Attribute`](`disabled`,``))
				u?.(m, el)
			}
		}

		/*
			The "model" and "update" functions are attached by default if they exist.
			If an alternative modelRegistry array was passed in (i.e. by datavalue-rows), then use that instead.
		*/
		row.model && ((`modelRegistry` in row && row.modelRegistry) || modelFns).push(m => row.model!(m, ret!))
		row.update && updaterFns.push(m => row.update!(m, ret!))
		/*
			Append and return the panel element.
		*/
		ret && panelElem.append(ret)
		/*
			This is something of a hack... by stashing the update() function on the element in this otherwise unused handler spot,
			it can be called whenever panels are switched.
		*/
		panelElem.onreset = update
		return panelElem
	},
	panelElem)

	panelRows.splice(0, panelRows.length)
	return ret
}

export { folddownPanel as Panel, dataValueRow, ToolbarPanel, PanelRow, Model }
