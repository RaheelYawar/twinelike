import type CodeMirror from "codemirror"
import { Doc, Editor, StringStream } from "codemirror"
import { Primitive } from "type-fest"
/*
	Some parts of this mode uses undocumented features of CodeMirror 5.65.16's API.
	Because this is the final version of CodeMirror 5, this can be considered stable.
*/
type OnTarget = { on: (name:string, fn: Callback) => void, _handlers?: Obj<(Callback)[]> }
type UndocumentedStringStream = StringStream & { lineOracle: { line: number, doc: UndocumentedDoc }}
type UndocumentedEditor = Editor & { constructor: typeof CodeMirror, doc: UndocumentedDoc, display: { wrapper:HTMLElement }}
type UndocumentedDoc = Doc & OnTarget & { cm: UndocumentedEditor }

// Basic type utilities.
type Obj<T> = Record<string, T>
type Callback = (...args:any[]) => void

/*
	Various utility functions and data definitions used in multiple Toolbar modules.
*/
const {round} = Math
/*
	This is a copy of Utils.insensitiveName(), used to check macro names.
*/
const insensitiveName = (e:string) => `${e}`.toLowerCase().replace(/-|_/g, ``)

type ShortDefsEntry = {name: string, sig: string, returnType: string, aka: string[], abstract: string, anchor: string, category: string, categoryOrder: string}

/*
	This SHORTDEFS comment + {} is actually replaced with an object literal listing
	of the currently defined Harlowe macros at compile-time, from the metadata script.
*/
const ShortDefs = <{
	Macro: Obj<ShortDefsEntry>
}>/*SHORTDEFS*/ {}

if (!Object.keys(ShortDefs).length) {
	throw Error(`ShortDefs wasn't inserted at build time`)
}

const builtinColourNames: Obj<string> = {
	"#e61919": `red`,
	"#e68019": `orange`,
	"#e5e619": `yellow`,
	"#80e619": `lime`,
	"#19e619": `green`,
	"#19e5e6": `cyan`,
	"#197fe6": `blue`,
	"#1919e6": `navy`,
	"#7f19e6": `purple`,
	"#e619e5": `magenta`,
	"#ffffff": `white`,
	"#000000": `black`,
	"#888888": `grey`,
}

/*
	These icons are copy-pasted from FAIcons.dev.
*/
const fontIcon = (name:string, w=20, h=20) =>
	`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" width="${w}" height="${h}"><path fill='currentColor' d="${
		{
			search: `M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z`,
			'align-center': `M432 160H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0 256H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zM108.1 96h231.81A12.09 12.09 0 0 0 352 83.9V44.09A12.09 12.09 0 0 0 339.91 32H108.1A12.09 12.09 0 0 0 96 44.09V83.9A12.1 12.1 0 0 0 108.1 96zm231.81 256A12.09 12.09 0 0 0 352 339.9v-39.81A12.09 12.09 0 0 0 339.91 288H108.1A12.09 12.09 0 0 0 96 300.09v39.81a12.1 12.1 0 0 0 12.1 12.1z`,
			'align-right': `M16 224h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16zm416 192H16a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm3.17-384H172.83A12.82 12.82 0 0 0 160 44.83v38.34A12.82 12.82 0 0 0 172.83 96h262.34A12.82 12.82 0 0 0 448 83.17V44.83A12.82 12.82 0 0 0 435.17 32zm0 256H172.83A12.82 12.82 0 0 0 160 300.83v38.34A12.82 12.82 0 0 0 172.83 352h262.34A12.82 12.82 0 0 0 448 339.17v-38.34A12.82 12.82 0 0 0 435.17 288z`,
			'list-ol': `M48 48a48 48 0 1 0 48 48 48 48 0 0 0-48-48zm0 160a48 48 0 1 0 48 48 48 48 0 0 0-48-48zm0 160a48 48 0 1 0 48 48 48 48 0 0 0-48-48zm448 16H176a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h320a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-320H176a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h320a16 16 0 0 0 16-16V80a16 16 0 0 0-16-16zm0 160H176a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h320a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16z`,
			'list-ul': `M61.77 401l17.5-20.15a19.92 19.92 0 0 0 5.07-14.19v-3.31C84.34 356 80.5 352 73 352H16a8 8 0 0 0-8 8v16a8 8 0 0 0 8 8h22.83a157.41 157.41 0 0 0-11 12.31l-5.61 7c-4 5.07-5.25 10.13-2.8 14.88l1.05 1.93c3 5.76 6.29 7.88 12.25 7.88h4.73c10.33 0 15.94 2.44 15.94 9.09 0 4.72-4.2 8.22-14.36 8.22a41.54 41.54 0 0 1-15.47-3.12c-6.49-3.88-11.74-3.5-15.6 3.12l-5.59 9.31c-3.72 6.13-3.19 11.72 2.63 15.94 7.71 4.69 20.38 9.44 37 9.44 34.16 0 48.5-22.75 48.5-44.12-.03-14.38-9.12-29.76-28.73-34.88zM496 224H176a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h320a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-160H176a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h320a16 16 0 0 0 16-16V80a16 16 0 0 0-16-16zm0 320H176a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h320a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zM16 160h64a8 8 0 0 0 8-8v-16a8 8 0 0 0-8-8H64V40a8 8 0 0 0-8-8H32a8 8 0 0 0-7.14 4.42l-8 16A8 8 0 0 0 24 64h8v64H16a8 8 0 0 0-8 8v16a8 8 0 0 0 8 8zm-3.91 160H80a8 8 0 0 0 8-8v-16a8 8 0 0 0-8-8H41.32c3.29-10.29 48.34-18.68 48.34-56.44 0-29.06-25-39.56-44.47-39.56-21.36 0-33.8 10-40.46 18.75-4.37 5.59-3 10.84 2.8 15.37l8.58 6.88c5.61 4.56 11 2.47 16.12-2.44a13.44 13.44 0 0 1 9.46-3.84c3.33 0 9.28 1.56 9.28 8.75C51 248.19 0 257.31 0 304.59v4C0 316 5.08 320 12.09 320z`,
			'border-style': `M240 416h-32a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm-96 0h-32a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm192 0h-32a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm96-192h-32a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0 96h-32a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0 96h-32a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-288h-32a16 16 0 0 0-16 16v32a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16v-32a16 16 0 0 0-16-16zm0-96H32A32 32 0 0 0 0 64v400a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16V96h368a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16z`,
			columns: `M464 32H48C21.49 32 0 53.49 0 80v352c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V80c0-26.51-21.49-48-48-48zM224 416H64V160h160v256zm224 0H288V160h160v256z`,
			eye: `M288 144a110.94 110.94 0 0 0-31.24 5 55.4 55.4 0 0 1 7.24 27 56 56 0 0 1-56 56 55.4 55.4 0 0 1-27-7.24A111.71 111.71 0 1 0 288 144zm284.52 97.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400c-98.65 0-189.09-55-237.93-144C98.91 167 189.34 112 288 112s189.09 55 237.93 144C477.1 345 386.66 400 288 400z`,
			comment: `M256 32C114.6 32 0 125.1 0 240c0 49.6 21.4 95 57 130.7C44.5 421.1 2.7 466 2.2 466.5c-2.2 2.3-2.8 5.7-1.5 8.7S4.8 480 8 480c66.3 0 116-31.8 140.6-51.4 32.7 12.3 69 19.4 107.4 19.4 141.4 0 256-93.1 256-208S397.4 32 256 32z`,
			plus: `M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z`,
			minus: `M416 208H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h384c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z`,
			times: `M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z`,
			check: `M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z`,
			'chevron-up': `M240.971 130.524l194.343 194.343c9.373 9.373 9.373 24.569 0 33.941l-22.667 22.667c-9.357 9.357-24.522 9.375-33.901.04L224 227.495 69.255 381.516c-9.379 9.335-24.544 9.317-33.901-.04l-22.667-22.667c-9.373-9.373-9.373-24.569 0-33.941L207.03 130.525c9.372-9.373 24.568-9.373 33.941-.001z`,
			gear: `M495.9 166.6c3.2 8.7 .5 18.4-6.4 24.6l-43.3 39.4c1.1 8.3 1.7 16.8 1.7 25.4s-.6 17.1-1.7 25.4l43.3 39.4c6.9 6.2 9.6 15.9 6.4 24.6c-4.4 11.9-9.7 23.3-15.8 34.3l-4.7 8.1c-6.6 11-14 21.4-22.1 31.2c-5.9 7.2-15.7 9.6-24.5 6.8l-55.7-17.7c-13.4 10.3-28.2 18.9-44 25.4l-12.5 57.1c-2 9.1-9 16.3-18.2 17.8c-13.8 2.3-28 3.5-42.5 3.5s-28.7-1.2-42.5-3.5c-9.2-1.5-16.2-8.7-18.2-17.8l-12.5-57.1c-15.8-6.5-30.6-15.1-44-25.4L83.1 425.9c-8.8 2.8-18.6 .3-24.5-6.8c-8.1-9.8-15.5-20.2-22.1-31.2l-4.7-8.1c-6.1-11-11.4-22.4-15.8-34.3c-3.2-8.7-.5-18.4 6.4-24.6l43.3-39.4C64.6 273.1 64 264.6 64 256s.6-17.1 1.7-25.4L22.4 191.2c-6.9-6.2-9.6-15.9-6.4-24.6c4.4-11.9 9.7-23.3 15.8-34.3l4.7-8.1c6.6-11 14-21.4 22.1-31.2c5.9-7.2 15.7-9.6 24.5-6.8l55.7 17.7c13.4-10.3 28.2-18.9 44-25.4l12.5-57.1c2-9.1 9-16.3 18.2-17.8C227.3 1.2 241.5 0 256 0s28.7 1.2 42.5 3.5c9.2 1.5 16.2 8.7 18.2 17.8l12.5 57.1c15.8 6.5 30.6 15.1 44 25.4l55.7-17.7c8.8-2.8 18.6-.3 24.5 6.8c8.1 9.8 15.5 20.2 22.1 31.2l4.7 8.1c6.1 11 11.4 22.4 15.8 34.3zM256 336c44.2 0 80-35.8 80-80s-35.8-80-80-80s-80 35.8-80 80s35.8 80 80 80z`,
		}[name]
	}"/></svg>`

const GCD = (a:number,b:number):number => !a? b: !b? a: a>b? GCD(a-b,b) : GCD(a,b-a)
const fourDecimals = (n:number) => round(n*10000)/10000

function toHarloweColour(c:string, alpha:number) {
	let colour: string | ReturnType<typeof hexToHSL> = c
	function hexToHSL(str:string) {
		str = str.slice(1)
		const
			r = parseInt(str.slice(0,2), 16) / 255,
			g = parseInt(str.slice(2,4), 16) / 255,
			b = parseInt(str.slice(4,6), 16) / 255,
			Max = Math.max(r, g, b),
			Min = Math.min(r, g, b),
			// Lightness is the average of the highest and lowest values.
			l = (Max + Min) / 2,
			delta = Max - Min

		if (Max === Min) {
			// If all three RGB values are equal, it is a gray.
			return { h:0, s:0, l }
		}
		// Calculate hue and saturation as follows.
		let h:number
		switch (Max) {
			case r: h = (g - b) / delta + (g < b ? 6 : 0); break
			case g: h = (b - r) / delta + 2; break
			case b: h = (r - g) / delta + 4; break
		}
		h = Math.round(h! * 60)

		const s = l > 0.5
			? delta / (2 - Max - Min)
			: delta / (Max + Min)
		return { h, s, l }
	}

	colour = colour.toLowerCase()
	if (+alpha === 0) {
		return `transparent`
	}
	if (+alpha < 1) {
		colour = hexToHSL(colour)
		return `(hsl:${fourDecimals(colour.h)},${fourDecimals(colour.s)},${fourDecimals(colour.l)},${fourDecimals(alpha)})`
	}
	return colour in builtinColourNames
		? builtinColourNames[colour]
		: (colour[1] === colour[2] && colour[3] === colour[4] && colour[5] === colour[6]) ? `#${colour[1]}${colour[3]}${colour[5]}` : colour
}

function toCSSColour(colour:string, alpha:number|string) {
	if (+alpha === 0) {
		return `transparent`
	}
	if (+alpha < 1) {
		colour = colour.slice(1)
		const
			r = parseInt(colour.slice(0,2), 16),
			g = parseInt(colour.slice(2,4), 16),
			b = parseInt(colour.slice(4,6), 16)
		return `rgba(${r},${g},${b},${alpha})`
	}
	return colour
}

/*
	The optional styles are a set of styles that depend on toolbar preferences.
	They are recreated every time a toolbar pref is changed, and every time an editor is opened.
*/
function setOptionalStyles({codeUsesCodeFont = true}) {
	const versionClass = `cm-harlowe-4-`
	/*
		This is created in the same way as the #cm-harlowe-4-styles element in mode.js
	*/
	let harloweOptionalStyles = document.querySelector(`style#${versionClass}optionalStyles`)
	if (!harloweOptionalStyles) {
		harloweOptionalStyles = document.createElement(`style`)
		harloweOptionalStyles.setAttribute(`id`,`${versionClass}optionalStyles`)
		document.head.appendChild(harloweOptionalStyles)
	}
	let codeEditorFontFamily = ``
	let codeEditorFontScale = 1
	if (codeUsesCodeFont) {
		/*
			To get the TwineJS Code Editor font pref, this slightly convoluted search must be performed...
		*/
		try {
			for (let p of localStorage.getItem(`twine-prefs`)?.split(`,`) || []) {
				let {name, value} = JSON.parse(localStorage.getItem(`twine-prefs-${p}`)!)
				if (name === `codeEditorFontFamily`) {
					/*
						The codeEditorFontFamily vlaue is either a var(--), or a textual font family.
						This disambiguation check should hold up, I think...
					*/
					codeEditorFontFamily = value.includes(` `) ? `"${value}"` : value
				} else if (name === `codeEditorFontScale`) {
					codeEditorFontScale = value
				}
			}
		} catch (e) {
			// Silently fail if no TwineJS prefs could be read.
		}
	}
	/*
		All of the optional styles are created now.
	*/
	harloweOptionalStyles.innerHTML =
		codeUsesCodeFont ? `.${versionClass}root:not([class^='${versionClass}text']):not([class^='${versionClass}verbatim']) { ${
			codeEditorFontFamily ? `font-family:${codeEditorFontFamily}` : ``
		}; ${
			codeEditorFontScale ? `font-size:${codeEditorFontScale*100}%` : ``
		}` : ``
}

/*
	Used for storing and retrieving Harlowe toolbar prefs from localStorage.

	Current preferences:

	- tooltips [Boolean]: whether to show the tooltips
*/
function getPrefs(): Obj<Primitive> {
	try {
		return JSON.parse(localStorage.getItem(`harlowe-prefs`)!) || {}
	}
	catch (e) {
		return {}
	}
}
function setPref(p:string, val: Primitive) {
	try {
		const prefs = getPrefs()
		prefs[p] = val
		localStorage.setItem(`harlowe-prefs`, JSON.stringify(prefs))

		setOptionalStyles(prefs)
	}
	catch (e) {
		return {}
	}
}

/*
	A crude element-creation function.
*/
const P = document.createElement(`p`)
function el(html:string): HTMLElement {
	P.innerHTML = html
	return <HTMLElement>P.firstChild
}

/*
	Feature detection.
*/
const twine23 = !!document.querySelector(`html[data-version^="2.3."]`)

/*
	Used for creating buttons with the correct TwineJS CSS class.
*/
const buttonClass = (primary?: boolean) => !twine23 ? `icon-button variant-${primary ? `primary` : `secondary`} ` : ` `

const disabledButtonCSS = `opacity:0.5;pointer-events:none`

export {
	Obj,
	Callback,
	OnTarget,
	UndocumentedDoc,
	UndocumentedEditor,
	UndocumentedStringStream,
	ShortDefsEntry,
	ShortDefs,
	toHarloweColour,
	toCSSColour,
	GCD,
	fourDecimals,
	el,
	twine23,
	buttonClass,
	builtinColourNames,
	fontIcon,
	insensitiveName,
	getPrefs,
	setPref,
	setOptionalStyles,
	disabledButtonCSS
}
