import { Doc, EditorChangeCancellable, TextMarker } from 'codemirror'
import {AnyToken, Markup} from '../markup.js'
import {ShortDefs, insensitiveName, getPrefs, setOptionalStyles,twine23, Obj, ShortDefsEntry, UndocumentedDoc, UndocumentedEditor, UndocumentedStringStream, OnTarget } from './utils.js'
import { Toolbar as toolbar, ToolbarCommands as commands } from './toolbar.js'
import tooltips from './tooltips.js'

let {lex} = Markup
/*
	Produce an object holding macro names, using both their names and their aliases.
*/
const validMacros = Object.entries(ShortDefs.Macro).reduce((a: Obj<ShortDefsEntry>,[name,macro])=> {
	[name, ...macro.aka].forEach(name => a[name] = macro)
	return a
}, {})
/*
	The mode is defined herein.
*/
const mode = () => {
	let cm: UndocumentedEditor

	/*
		Story data is obtained from localStorage every time the editor is opened.
	*/
	let passages: Set<string>
	let passageTags: Set<string>
	const storyData = () => {
		/*
			These types incompletely reflect the JSON used by Twine 2.
		*/
		passages = new Set()
		passageTags = new Set()
		/*
			1: Find the list of all stories.
		*/
		let stories: string[]
		try {
			stories = localStorage.getItem(`twine-stories`)!.split(`,`)
		} catch(e) {
			return
		}
		/*
			2: Get the story with the most recent lastUpdate AND whose name is contained in the current window title
			(which is the only part of the 2.4 DOM that lists the current story).
			This isn't a perfect check by any means, but since this functionality provides optional extra highlighting,
			it's not too serious an issue...
		*/
		let currentStory, highestLastUpdate = 0
		for (let s of stories) {
			try {
				type StoryJSON = {
					name: string
					lastUpdate: string
					id:string
				}
				const story = <StoryJSON>JSON.parse(localStorage.getItem(`twine-stories-${s}`)!)
				const lastUpdate = Date.parse(story.lastUpdate)
				if (lastUpdate > highestLastUpdate && document.title.includes(story.name)) {
					currentStory = story
					highestLastUpdate = lastUpdate
				}
			} catch(e) {
				continue
			}
		}
		if (!currentStory) {
			return
		}
		/*
			3: Find the list of all passages, and add the ones that are in this story.
		*/
		try {
			type PassageJSON = {
				tags: string[]
				text: string
				name: string
				story:string
			}
			for (let pName of localStorage.getItem(`twine-passages`)?.split(`,`) || []) {
				let p = <PassageJSON>JSON.parse(localStorage.getItem(`twine-passages-${pName}`)!)
				if (p.story === currentStory.id) {
					passages.add(p.name)
					for (let t of p.tags) {
						passageTags.add(t)
					}
				}
			}
		} catch(e) {
			return
		}
	}

	/*
		To handle 2.4's multi-editor mode, this WeakMap stores multiple parse trees (plus referenceTokens) tied to CodeMirror docs.
	*/
	const editors = new WeakMap<Doc, EditorData>()

	const docData = (doc: Doc) => {
		if (!editors.has(doc)) {
			/*
				Use refreshTree() to create all the relevant data structures for this doc, including the tree.
			*/
			refreshTree(doc)
		}
		return editors.get(doc)!
	}

	/*
		This contains various actions to perform on newly-lexed tokens from refreshTree().
	*/
	function lexTreePostProcess(data: EditorData, token: AnyToken, prevToken: AnyToken | undefined, parents: AnyToken[]) {
		if (token.type === `variable` || token.type === `tempVariable`
				|| token.type === `hook` || token.type === `hookName`) {
			data.referenceTokens[token.type].push(token)
		}
		/*
			Don't syntax-highlight the interiors of strings.
		*/
		if (token.type === `string`) {
			token.children = []
		}
		/*
			If the previous token was a comment line --, simply continue to use its styling and don't syntax-highlight this at all.
		*/
		if (prevToken?.type === `comment`) {
			data.cssClasses[token.start] = data.cssClasses[prevToken.start]
			return
		}
		/*
			Assemble the CSS class string for this token and stash it on the cssClasses cache.
			The resulting CSS class string contains the cumulative styles of the token and all
			parents above it.
		*/
		let counts: Obj<number> = {}
		let cssClasses = ``
		for (let i = -1; i < parents.length; i += 1) {
			const {type,text} = i === -1 ? token : parents[i]
			// If the type is "verbatim" or "htmlComment", erase all of the class names before it.
			if (type === `verbatim` || type === `htmlComment`) {
				cssClasses = ``
			}
			let name = `harlowe-4-${type}`
			counts[name] = (counts[name] || 0) + 1
			// If this name has been used earlier in the chain, suffix
			// this name with an additional number.
			if (counts[name] > 1) {
				name += `-${counts[name]}`
			}
			switch(type) {
				/*
					Strings matching passage names or tag names get special highlighting.
				*/
				case `string`: {
					const val = text.slice(1,-1)
					if (passages.has(val)) {
						name += ` harlowe-4-passageString`
					}
					else if (passageTags.has(val)) {
						name += ` harlowe-4-tagString`
					}
					break
				}
				/*
					It's an error if a text node appears inside a macro, but not inside a code hook.
				*/
				case `text`: {
					if (text.trim()) {
						const insideMacro = parents.slice(i + 1).reduce((a: boolean | undefined,t) =>
								a === undefined ? t.type === `macro` ? true : t.type === `hook` ? false : a : a,
								undefined
							)
						if (insideMacro) {
							name += ` harlowe-4-error`
						}
					}
					break
				}
				/*
					Use the error style if the macro's name doesn't match the list of
					existant Harlowe macros.
				*/
				case `macroName`: {
					const firstGlyph = text[0]
					if (firstGlyph === `_` || firstGlyph === `$`) {
						name += ` harlowe-4-customMacro harlowe-4-${firstGlyph === `_` ? `tempV` : `v`}ariable`
						break
					}
					const macroName = insensitiveName(text.slice(0,-1))
					if (!Object.hasOwn(validMacros, macroName)) {
						name += ` harlowe-4-error`
					}
					else {
						/*
							Colourise macro names based on the macro's return type.
							This is done by concatenating the cm-harlowe-4-macroName class
							with an additional modifier containing the return type.
						*/
						name += `-${validMacros[macroName].returnType.toLowerCase()}`
					}
					break
				}
			}
			cssClasses += `${name} `
		}
		/*
			Having assembled the CSS class for this token, add it to the map.
		*/
		data.cssClasses[token.start] = cssClasses
		// If this token has children...
		token.children?.length && (data.cssClasses[
			/*
				Reapply this token's styles after the last of its children have passed.
			*/
			token.children[token.children.length-1].end
		] = cssClasses)
		/*
			Now recur.
		*/
		for (let i = 0; i < token.children.length; i+=1) {
			lexTreePostProcess(data, token.children[i], token.children[i-1], [token].concat(parents))
		}
	}

	type EditorData = {
		tooltipsEnabled: boolean
		lastAction: string
		tree: AnyToken
		// These caches are used to implement special highlighting when the cursor
		// rests on variables or hookNames, such that all the other variable/hook
		// tokens are highlighted as well.
		referenceTokens: {
			variable: AnyToken[]
			tempVariable: AnyToken[]
			hook: AnyToken[]
			hookName: AnyToken[]
		}
		/*
			This cache is used for holding the computed CodeMirror CSS tokens
			from lexTreePostProcess(). It is used in the CodeMirror mode's token() event.
		*/
		cssClasses: Obj<string>
		cursorMarks: TextMarker[]
	}
	/*
		Refresh (re-lex) an existing doc's tree.
	*/
	function refreshTree(doc: Doc) {
		let data: EditorData
		/*
			If the doc doesn't exist, quickly create it now.
		*/
		if (!editors.has(doc)) {
			data = <EditorData>{
				tooltipsEnabled: true,
				lastAction: ``,
			}
			editors.set(doc, data)
		}
		else {
			data = editors.get(doc)!
		}
		data.tree = lex(doc.getValue())
		data.referenceTokens = {
			variable: [],
			tempVariable: [],
			hook: [],
			hookName: [],
		}
		data.cssClasses = Object.create(null)
		/*
			Erase the existing cursorMarks.
		*/
		data.cursorMarks?.forEach(mark => mark.clear())
		data.cursorMarks = []
		for (let i = 0; i < data.tree.children.length; i+=1) {
			lexTreePostProcess(data, data.tree.children[i], data.tree.children[i-1], [data.tree])
		}
	}
	
	/*
		This 'beforeChange' event handler applies a hack to CodeMirror to force it
		to rerender the entire text area whenever a change is made, not just the change.
		This allows 'backtrack' styling, such as unclosed brackets, to be possible
		under CodeMirror.
	*/
	function forceFullChange(changeObj: EditorChangeCancellable, oldText: string) {
		if (!changeObj.update) {
			return
		}
		/*
			First, obtain the text area's full text line array, truncated
			to just the line featuring the change.
		*/
		const line = changeObj.from.line
		
		let newText = oldText
			.split(`\n`)
			.slice(0, changeObj.from.line + 1)
		
		/*
			Join it with the change's text.
		*/
		newText[line] =
			newText[line].slice(0, changeObj.from.ch)
			+ changeObj.text[0]
		
		/*
			If the change is multi-line, the additional lines should be added.
		*/
		newText = newText.concat(changeObj.text.slice(1))
		
		/*
			Now, register this change.
		*/
		changeObj.update({line:0, ch:0}, changeObj.to, newText)
		
		return newText.join(`\n`)
	}

	/*
		This 'cursorActivity' event handler applies CodeMirror marks based on
		the token that the cursor is resting on.
	*/
	function cursorMarking(doc: Doc) {
		const data = docData(doc)
		let {tree, cursorMarks, referenceTokens} = data
		if (cursorMarks.length) {
			cursorMarks.forEach(mark => mark.clear())
			cursorMarks = data.cursorMarks = []
		}
		const token = <AnyToken>tree.tokenAt(doc.indexFromPos(doc.getCursor()))
		// If the cursor is at the end of the passage, or there is no text, then
		// the returned token will be null.
		if (!token) {
			return
		}
		/*
			First, mark the containing token for the cursor's current position.
			This illuminates the boundaries between tokens, and provides makeshift
			bracket/closer matching.
		*/
		cursorMarks.push(doc.markText(
			doc.posFromIndex(token.start),
			doc.posFromIndex(token.end),
			{className: `cm-harlowe-4-cursor`}
		))
		/*
			If the token is a variable or hookName, then
			highlight certain other instances in the text.
			For variables, hooks and hookNames, highlight all other occurrences of
			the variable in the passage text.
		*/
		if (token.type === `variable` || token.type === `tempVariable`
				|| token.type === `hookName` || token.type === `hook`) {
			// <hooks| should highlight matching ?hookNames.
			const type = token.type === `hook` ? `hookName` : token.type
			referenceTokens[type].forEach(e => {
				if (e !== token && `name` in e && e.name === token.name) {
					cursorMarks.push(doc.markText(
						doc.posFromIndex(e.start),
						doc.posFromIndex(e.end),
						{className: `cm-harlowe-4-variableOccurrence`}
					))
				}
			})
		}
		/*
			Also for hookNames and hooks, highlight the nametags of the
			named hook(s) that match this one's name.
		*/
		if (token.type === `hookName` || token.type === `hook`) {
			(<(AnyToken & { type: `hook` | `hookName `})[]>referenceTokens.hook).forEach(e => {
				if (e !== token && e.name && e.name === token.name) {
					const tagStart =
						// This assumes that the end of the hook's text consists of its <tag|,
						// and nothing else.
						`tagPosition` in e && e.tagPosition === `appended` ? (e.end - e.name.length) - 1
						// This assumes that the start of the hook's text is its |tag>.
						: e.start + 1

					cursorMarks.push(doc.markText(
						doc.posFromIndex(tagStart),
						doc.posFromIndex(tagStart + e.name.length),
						{className: `cm-harlowe-4-hookOccurrence`}
					))
				}
			})
		}
	}

	/*
		Find/Replace functionality.
		This is in here instead of toolbar.js because on('change') needs to re-run existing searches
		if the doc is edited while the find/replace panel is open.
		When a search is performed (using find()), currentQuery becomes a FindReplaceQuery object,
		and a CodeMirror overlay (below) is added that highlights the matches.

		Matches are {start, end, groups} objects, where groups are RegExp.exec() capturing groups.
	*/
	type FindReplaceQuery = {
		query:string
		onlyIn:string
		matchCase:boolean
		useRegExp:boolean
		// The following are caches for the currently-active search.
		// This is the compiled RegExp made from the query (if useRegExp is true).
		regExp?:RegExp
		// A function to be called when results are found, which updates the UI.
		updateResultsDisplay?: VoidFunction
		// Both of these only exist as mirrors of the bindings below, so that updateResultsDisplay() can use them.
		matches?: number
		matchIndex?: number
	}
	type LineCh = { line: number, ch: number }
	let matches: { start:LineCh, end:LineCh, groups?:string[] }[] = []
	/*
		The matchIndex refers to the currently highlighted match, the target of "Replace One" operations.
	*/
	let matchIndex: number
	let currentQuery: FindReplaceQuery | undefined
	/*
		findFromIndex allows a search to begin from a given index, setting the matchIndex correctly.
	*/
	let findFromIndex = -1
	const findOverlay = {
		token(stream: UndocumentedStringStream) {
			/*
				To highlight, simply go through each match and apply the CSS class if the stream
				is inside it.
				Assumption: all matches entries are in ascending order.
			*/
			const { line } = stream.lineOracle
			const ch = stream.pos
			for (let i = 0; i < matches.length; i += 1) {
				const { start, end } = matches[i]

				if (start.line > line || end.line < line) {
					continue
				}
				/*
					This checks that the stream is currently within this match's range.
					Because the end ch is noninclusive, "end.ch > ch" is used instead of "end.ch >= ch".
				*/
				if (start.line <= line && end.line >= line) {
					if ((start.line < line || start.ch <= ch) && (end.line > line || end.ch > ch)) {
						(end.line > line) ? stream.skipToEnd() : stream.pos = end.ch
						return (matchIndex === i) ? `harlowe-4-findResultCurrent` : `harlowe-4-findResult`
					}
					else if (start.line === line && start.ch > ch) {
						stream.pos = start.ch
						return
					}
				}
			}
			stream.skipToEnd()
		}
	}
	/*
		The main finding function.
		This can begin a search from a specific index (such as after using "Replace One").
	*/
	function harlowe4Find(q:FindReplaceQuery) {
		cm.removeOverlay(findOverlay)
		matches = []
		matchIndex = -1
		q.matches = undefined
		/*
			Don't initialise a search for "".
		*/
		if (!q.query) {
			currentQuery = undefined
			return
		}
		currentQuery = q
		const {doc} = cm
		/*
			The focused match is the one immediately after (or at) the cursor, or the first one if there is none after.
		*/
		const cursorIndex = findFromIndex > -1 ? findFromIndex : Math.max(0, doc.indexFromPos(doc.getCursor()) - 1)
		/*
			The actual work in finding the results is done using this RegExp. It is cached so that replace() can use it, too.
		*/
		try {
			q.regExp = new RegExp(q.useRegExp ? q.query : q.query.replace(/[-[\]/{}()*+?.\\^$|]/mg, `\\$&`), q.matchCase ? `g` : `gi`)
		} catch(e) {
			// If useRegExp is on, and the regExp is incomplete, exit early.
			currentQuery = undefined
			return
		}
		const fullText = doc.getValue()
		const tree = docData(doc).tree
		const {onlyIn} = q
		let match
		matchLoop: while ((match = q.regExp.exec(fullText))) {
			/*
				Process a result if it's at the front of the input stream.
			*/
			const matchLength = match[0].length
			if (!matchLength) {
				break
			}
			const {index} = match
			/*
				Obtain the RegExp capturing groups, if any.
			*/
			const groups = match.slice(1)
			
			if (onlyIn === `Only in prose` || onlyIn === `Only in code`) {
				/*
					Search for text and string tokens in the result's branch.
					If there are any, and "Only prose" is set, then break the loop (thus skipping the return at the end.)
					If there are any, and "Only code" is set, then it's invalid - end and go to the next token.
				*/
				let currentBranch = tree.pathAt(index)
				let currentToken = currentBranch[0]
				for (let j = index; j < index + matchLength; j += 1) {
					if (j > currentToken.end) {
						currentBranch = tree.pathAt(j)
						currentToken = currentBranch[0]
					}
					let i
					for (i = 0; i < currentBranch.length; i+=1) {
						const {type} = currentBranch[i]
						if (type === `text` || type === `string`) {
							/*
								If this is a text/string node and "Only code" is set, then it's invalid. Otherwise, it's valid.
							*/
							if (onlyIn === `Only in code`) {
								continue matchLoop
							}
							break
						}
					}
					/*
						If no text or string tokens were found, and "Only prose" is set, then it's invalid - end and go to the next token.
					*/
					if (i === currentBranch.length && onlyIn === `Only in prose`) {
						continue matchLoop
					}
				}
			}
			/*
				Limit the search if "Only selection" is set. This requires looping through every CodeMirror selection
				(whose anchor-head order isn't obvious) and checking.
			*/
			else if (onlyIn === `Only in selection`) {
				const selections = doc.listSelections()
				let done = false
				for (let i = 0; i < selections.length && !done; i += 1) {
					const pos1 = doc.indexFromPos(selections[i].anchor),
						pos2 = doc.indexFromPos(selections[i].head)
					if (index >= Math.min(pos1, pos2) && index + matchLength < Math.max(pos1, pos2)) {
						done = true
					}
				}
				if (!done) {
					continue matchLoop
				}
			}
			/*
				Add this match to the highlighter overlay's array.
			*/
			const start = doc.posFromIndex(index)
			const end = doc.posFromIndex(index + matchLength)
			matches.push({start, end,
				// Only store the groups if they actually exist.
				// There may not actually be any performance benefit for doing this, though...
				groups: groups.length ? groups : undefined})
			if (matchIndex === -1) {
				/*
					Update the matchIndex if this is the match immediately after the cursor.
				*/
				if (index > cursorIndex) {
					matchIndex = matches.length - 1
				}
				/*
					Don't scroll into view if this is a continued search.
				*/
				if (!findFromIndex) {
					cm.scrollIntoView(start, cm.display.wrapper.offsetHeight / 2)
				}
			}
		}
		/*
			If no matchIndex was set above, set it now.
		*/
		if (matchIndex === -1) {
			matchIndex = 0
		}
		cm.addOverlay(findOverlay)
		/*
			The find panel's results counter is updated as such. (See the panel itself for more details.)
		*/
		q.matches = matches.length
		q.matchIndex = matchIndex
		q.updateResultsDisplay?.()
		/*
			Reset this thing now.
		*/
		findFromIndex = -1
	}
	function harlowe4FindNext(dir: 1 | -1) {
		matchIndex = (matchIndex + dir) % matches.length
		if (matchIndex < 0) {
			matchIndex += matches.length
		}
		matches[matchIndex] && cm.scrollIntoView(matches[matchIndex].start, cm.display.wrapper.offsetHeight / 2)
		/*
			This crudely refreshes the overlay.
		*/
		cm.removeOverlay(findOverlay)
		cm.addOverlay(findOverlay)
		/*
			The find panel's results counter is updated as such. (See the panel itself for more details.)
		*/
		currentQuery!.matchIndex = matchIndex
		currentQuery!.updateResultsDisplay?.()
	}
	function harlowe4Replace(newStr:string, all:boolean) {
		const {doc} = cm
		const match = matches[matchIndex]
		if (!all && match) {
			/*
				If groups were captured, perform the replacement here.
			*/
			if (match.groups?.length) {
				newStr = newStr.replace(/\$(\d+)/g, (_,index) => match.groups![+index - 1] || `$${index}`)
			}
			findFromIndex = doc.indexFromPos(match.start) + newStr.length - 1
			doc.replaceRange(newStr, match.start, match.end)
		}
		/*
			Due to the slow, buggy nature of bundling multiple replaceRange() calls into a CodeMirror operation(),
			this full replacement is done with a single replaceRange() that re-computes the matches using the original query RegExp.
		*/
		else if (matches.length) {
			const veryStart = matches[0].start
			const veryEnd = matches[matches.length-1].end
			doc.replaceRange(doc.getValue().slice(doc.indexFromPos(veryStart), doc.indexFromPos(veryEnd)).replace(currentQuery!.regExp!,
				// Because this uses JavaScript's String#replace, the capturing group syntax ($1, $2) in newStr can be used as-is.
				newStr
			), veryStart, veryEnd)
		}
		// Since this triggers change(), nothing more needs to be done to refresh the overlay.
	}

	/*
		Because mode() can be called multiple times by TwineJS, special preparation must be done before attaching event handlers.
		Each event handler here is a named function with "harlowe4" in their name, so that their copies can be spotted in the _handlers array.
	*/
	const on = (target: OnTarget, name:string, fn: (...args:any[]) => void) => (!target._handlers || !(target._handlers[name] || []).some(e => e.name === fn.name)) && target.on(name, fn)
	
	let init: null | ((doc: UndocumentedDoc) => void) = doc => {
		if (!cm) {
			cm = doc.cm
			/*
				Add line bullets (currently used in just the docs editor only).
			*/
			if (window === this) {
				cm.setOption(`lineNumbers`, true)
				cm.setOption(`lineNumberFormatter`, () => `\u2022`)
			}
		}
		/*
			Install the toolbar, if it's Twine 2.3. (This function will early-exit if the toolbar's already installed.)
		*/
		if (twine23) toolbar?.(cm, { foregroundColor:`#888`})

		/*
			Refresh the story data.
		*/
		storyData()

		/*
			Refresh the optional CodeMirror styles based on the toolbar prefs.
		*/
		setOptionalStyles(getPrefs())

		/*
			Use the Harlowe lexer to compute a full parse tree.
		*/
		refreshTree(doc)
		/*
			Attach the all-important beforeChanged event, but make sure it's only attached once.
			Note that this event is removed by TwineJS when it uses swapDoc to dispose of old docs.
		*/
		on(doc, `beforeChange`, function harlowe4beforeChange(_: unknown, change: EditorChangeCancellable) {
			/*
				Do nothing if this is detached from the DOM.
			*/
			if (!doc.cm.display.wrapper.parentNode) {
				return
			}
			const oldText = doc.getValue()
			forceFullChange(change, oldText)
		})
		on(doc, `change`, function harlowe4Change() {
			/*
				Do nothing if this is detached from the DOM.
			*/
			if (!doc.cm.display.wrapper.parentNode) {
				return
			}
			/*
				'change' events are immediately followed by 'cursorActivity' events.
				To denote that a 'cursorActivity' event was preceded by 'change',
				the event is recorded as a "last action" of the doc.
			*/
			docData(doc).lastAction = `changing`

			refreshTree(doc)
			/*
				Re-compute the current search query, if there is one.
			*/
			if (currentQuery && matches[matchIndex]) {
				/*
					Don't reset findFromIndex if harlowe4Replace() changed it.
				*/
				if (findFromIndex === -1) {
					findFromIndex = doc.indexFromPos(matches[matchIndex].start) - 1
				}
				harlowe4Find(currentQuery)
			}
		})
		on(doc, `cursorActivity`, function harlowe4CursorActivity() {
			cursorMarking(doc)
			const data = docData(doc)
			/*
				The aforementioned lastAction set by 'change' is read here.
				- "change" denotes a 'change' action that occurred some time ago, whereas
				- "changing" denotes a 'change' action that occured immediately before.
			*/
			data.lastAction = data.lastAction === `changing` ? `change` : `cursorActivity`
			tooltips?.(doc, data)
		})
		/*
			Perform specific style alterations based on certain specific token types.
		*/
		on(cm, `renderLine`, function harlowe4RenderLine(_, __, lineElem: Element) {
			Array.from(lineElem.querySelectorAll(`.cm-harlowe-4-colour`)).forEach(elem => {
				/*
					It may be a bit regrettable that the fastest way to get the HTML colour of a Harlowe
					colour token is to re-lex it separately from the tree, but since it's a single token, it should nonetheless be quick enough.
					(Plus, colour tokens are relatively rare in most passage prose).
				*/
				const {colour} = <AnyToken & { type: `colour` }>lex(elem.textContent!, ``, `macro`).tokenAt(0)
				/*
					The following CSS produces a colour stripe below colour literals, which doesn't interfere with the cursor border.
				*/
				elem.setAttribute(`style`, `background:linear-gradient(to bottom,transparent,transparent 80%,${colour} 80.1%,${colour})`)
			})
		})
		// Remove the tooltip, if it exists.
		// This can't actually be in the Tooltips module because it must only be installed once.
		on(cm, `scroll`, function harlowe4Scroll() {
			const tooltip = document.querySelector(`.harlowe-4-tooltip`)
			tooltip?.remove()
		})
		/*
			These are signalled only by the Find/Replace Toolbar panel.
		*/
		on(cm, `harlowe-4-find`, harlowe4Find)
		on(cm, `harlowe-4-findNext`, harlowe4FindNext)
		on(cm, `harlowe-4-replace`, harlowe4Replace)
		on(cm, `harlowe-4-findDone`, function harlowe4FindDone() {
			cm.removeOverlay(findOverlay)
		})
		/*
			Unset this function, now that this is all done.
		*/
		init = null
	}

	type State = {
		pos: number
		disconnected: boolean | null
		// This is used to preserve the style of the previous line, if
		// its token extends through multiple lines.
		styleBeforeNewline: string
	}
	
	return {
		startState: () => (<State>{
			pos: 0,
			disconnected: null,
			styleBeforeNewline: ``,
		}),
		blankLine(state:State) {
			state.pos++
		},
		token(stream:UndocumentedStringStream, state:State) {
			const {doc} = stream.lineOracle
			/*
				If the CM doc is disconnected from the DOM (somehow), don't bother doing anything.
			*/
			if (state.disconnected === null ? (state.disconnected = !doc.cm.display.wrapper.parentNode) : state.disconnected) {
				state.pos++
				stream.next()
				return null
			}
			/*
				Install the event handlers, if they haven't already been.
			*/
			init?.(doc)
			/*
				Fetch the cssClasses cache for this doc.
			*/
			const {cssClasses} = docData(doc)
			const ret = cssClasses[state.pos]
				/*
					Extend the previous line's style, if necessary.
				*/
				|| state.styleBeforeNewline || null
			/*
				Advance pos until reaching the next position of a cssClass in the cache,
				or the end of the line.
			*/
			do {
				state.pos++
				stream.next()
			}
			while ((cssClasses[state.pos] === ret || !(state.pos in cssClasses)) && !stream.eol())
			/*
				If we are currently at a \n, advance off it.
			*/
			if (stream.eol()) {
				/*
					Cache the style so that it can be used for the next line.
				*/
				state.styleBeforeNewline = ret!
				state.pos++
			}
			/*
				If we aren't, discard the styleBeforeNewline cache so that it isn't used any further.
			*/
			else {
				state.styleBeforeNewline = ``
			}
			return ret
		},
	}
}
if (`CodeMirror` in window) {
	(<{defineMode: (...args:any[]) => void}>window.CodeMirror).defineMode(`harlowe-4`, mode)
} else {
	(<{editorExtensions?: unknown}><unknown>this).editorExtensions = {
		twine: {
			2: {
				codeMirror: {
					mode,
					toolbar,
					commands,
				},
			},
		},
	}
}
/*
	In order to provide styling to the Harlowe mode, CSS must be dynamically injected
	when the mode is defined. This is done now, by creating a <style> element with ID
	"cm-harlowe" and placing our CSS in it.
*/
/*
	If the style element already exists, it is reused. Otherwise, it's created.
*/
let harloweStyles = document.querySelector(`style#cm-harlowe-4`)
if (!harloweStyles) {
	harloweStyles = document.createElement(`style`)
	harloweStyles.setAttribute(`id`,`cm-harlowe-4`)
	document.head.appendChild(harloweStyles)
}
/*
	The CODEMIRRORCSS string is replaced with the output of the script "codemirrorcss.js".
*/
harloweStyles.innerHTML = `CODEMIRRORCSS`
