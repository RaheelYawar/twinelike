/*
	VarScope.
	This is a root prototype object which houses temporary variables, inside a Section's stack.
	This isn't frozen so that its values can be overridden.
*/
import { objectName, toSource, unstorableValue } from "../utils/operationutils.js"
import { AnyStorable, CustomCommand, TwineError, Changer, AnyUnstorable } from "../datatypes.js"
import {ValueRef, ValueRefSerialised} from "../state/valueref.js"
import {Markup} from "../markup/markup.js"
import {Section} from "../section.js"
import { LoadGameError, Obj } from "../utils.js"

const {lex} = Markup
const {create} = Object

type CustomCommandSerialised = { changer: string, toSource: string, hook: string, variables: VarScopeSerialised }
type VariableStoreSerialised = Obj<null | string | CustomCommandSerialised | ValueRefSerialised>
type VarScopeSerialised = { typeDefs: Obj<string>, values: VariableStoreSerialised }

class VarScope {
	/*
		Note that it's not possible for userland TwineScript to directly access or
		modify this base object.
	*/
	get objectName() { return this.name }

	/*
		Inside a TypeDefs is every variable name that this variables collection contains, mapped to a Harlowe datatype.

		TODO: Move most of the type-checking out of VarRef into here.
	*/
	typeDefs: Obj<AnyStorable> = Object.create(null)

	/*
		The user-facing name of this scope, which is displayed in Debug Mode.
	*/
	name: string
	/*
		This is either `global` or `temp`, indicating whether it represents global variables (in both Current and past Moments)
		or a hook or lambda's temp variable scope.
	*/
	type: string
	/*
		The "parent" scope for this temp scope.
		Used only in VarRef.set() to allow inner hooks to modify outer hooks' values.
	*/
	parent?: VarScope

	/*
		The internal backing store for variable values.
	*/
	variableStore: Obj<AnyStorable | null>
	/*
		Value Refs (used to reconstruct long values from save files) are tracked as well.
	*/
	valueRefs?: Obj<ValueRef>

	delete(prop:string) {
		/*
			By setting this to null, previous turns' variableStores are shadowed by its absence.
		*/
		this.variableStore[prop] = null
		delete this.typeDefs[prop]
	}
	/*
		Because CurrentVarScope overrides this, the signature for that override needs to be listed here.
	*/
	set(prop:string, value:AnyStorable, valueRef?: ValueRef): void
	set(prop:string, value:AnyStorable) {
		this.variableStore[prop] = value
	}
	getProperty(prop:string) {
		const ret = this.variableStore[prop]
		/*
			null denotes deleted values, but shouldn't be exposed to getProperty() consumers, who expect
			AnyValue or undefined.
		*/
		return ret === null ? undefined : ret
	}
	defineType(prop:string, type:AnyStorable) {
		this.typeDefs[prop] = type
	}
	constructor(name:string, type: `temp`|`global` = `temp`, inheritFrom: unknown = null) {
		this.name = name
		this.type = type
		/*
			Temp variable scopes within nested hooks inherit from outer scopes.
			This is implemented using the prototype chain.
		*/
		this.variableStore = create(inheritFrom instanceof VarScope ? inheritFrom.variableStore :
			/*
				To prevent errors when creating variables called "toString" or "isPrototypeOf" etc.,
				this MUST be a null prototype object.
			*/
			null)
		if (inheritFrom instanceof VarScope) {
			this.parent = inheritFrom
		}
	}

	/*
		Used by Moment.flatten() to flatten variable scopes from different Moments into a single Moment.
	*/
	flatten(others: VarScope[]) {
		let deletions: Obj<boolean> = {}
		for (let other of others) {
			/*
				The typeDefs object (of inaccessible/non-writable data structures) doesn't need to have its contents cloned.
			*/
			for (let varName in other.typeDefs) {
				this.typeDefs[varName] ||= other.typeDefs[varName]
			}
			for (let prop in other.variableStore) {
				if (!(prop in this.variableStore)) {
					/*
						The JSON value "null" represents variables deleted by (move:).
					*/
					if (other.variableStore[prop] === null) {
						deletions[prop] = true
					}
					if (!deletions[prop]) {
						this.variableStore[prop] = other.variableStore[prop]
						/*
							If this variable had a valueRef at this turn, and the valueRef is NOT
							a "via" valueRef (which uses 'it' to reference past turns), then save the valueRef as well.
						*/
						const ref = other.valueRefs?.[prop]
						if (other.valueRefs && ref && !(`via` in ref)) {
							other.valueRefs[prop] ||= ref
						}
					}
				}
			}
		}
		/*
			Having flattened it down, the final moment shouldn't have any valueRefs remaining.
			This code removes any that remain.
		*/
		for (let prop in this.valueRefs) {
			const ref = this.valueRefs[prop]
			if (ref && (`via` in ref)) {
				delete this.valueRefs[prop]
			}
		}
	}
	
	/*
		Used to serialise the variableStore record into a JSON object, but using valueRefs in place of any values which have them
		(as well as a unique special case for CustomCommands).
	*/
	#serialiseVariableStore() {
		const store = this.variableStore
		const ret: VariableStoreSerialised = {}
		for (const prop in store) {
			const value = store[prop]
			/*
				Custom commands must be serialised in this rather complicated manner, involving a special TwineScript method
				named customCommand for retrieving its internals.

				TODO: Move this to CustomCommand#serialise()?
			*/
			if (value instanceof CustomCommand) {
				const desc = value.customCommand()
				ret[prop] = {
					/*
						The desc.changer only contains the changers that were attached to (output:).
						If none were present, it is undefined, which gets serialised here to the empty string.
					*/
					changer: desc.changer ? toSource(desc.changer) : ``,
					/*
						TODO: Figure out what should happen if the CustomCommand has no toSource
					*/
					toSource: <string>desc.toSource,
					hook: toSource(desc.hook),
					variables: desc.variables.serialise(),
				}
			}
			/*
				ValueRefs can be serialised by just spreading them, as all their properties are data, and all their methods are on the prototype.
			*/
			else if (this.valueRefs && prop in this.valueRefs) {
				ret[prop] = <ValueRefSerialised>{ ...this.valueRefs[prop]}
			}
			/*
				"null", representing deleted variables, is passed as-is to become a JSON null.
				(Currently (Jan 2022), though, nothing can delete values.)
			*/
			else {
				ret[prop] = value === null ? null : toSource(value)
			}
		}
		return ret
	}

	/*
		Convert this VarScope into a JSON-compatible object for save-file writing.
	*/
	serialise() {
		/*
			Serialising the TypeDefs and ValueRefs requires a little special-casing.
		*/
		const typeDefsSerialised: Obj<string> = {}
		for (let prop in this.typeDefs) {
			/*
				Since the datatypes inside are Harlowe values,
				they should be serialised to source as well.
			*/
			typeDefsSerialised[prop] = toSource(this.typeDefs[prop])
		}
		return {
			typeDefs: typeDefsSerialised,
			/*
				ValueRefs, remember, are serialised /in place of/ the values they represent.
			*/
			values: this.#serialiseVariableStore()
		}
	}

	/*
		Convert a JSON-compatible object into a new VarScope.
	*/
	static deserialise(name = `a past turn's variables`, type: `temp`|`global` = `global`, obj: VarScopeSerialised, pastTimeline: VarScope[], section: Section) {
		let ret = new VarScope(name,type)
		let {values, typeDefs} = obj
		const errorMessageOpener = `The variables on turn ${pastTimeline.length+1} couldn't be reconstructed. `
		for (let key in values) {
			let value = values[key]
			/*
				There shouldn't be any explicit nulls in serialisations, but just in case...
			*/
			if (value === null) {
				continue
			}
			/*
				As in serialiseVariableStore(), CustomCommand deserialisation is a special case.
			*/
			if (typeof value === `object` && `changer` in value) {
				/*
					The empty string denotes that there were no changers attached to (output:) in this command.
					As such, it is now restored to an explicit undefined.
				*/
				const changer: unknown = value.changer === `` ? undefined : section.eval(lex(value.changer, ``, `macro`))
				if (changer !== undefined && !(changer instanceof Changer)) {
					throw new LoadGameError(`${errorMessageOpener}This custom command's (output:)-attached changers couldn't be recreated: ${value.toSource}`)
				}
				const hook = section.eval(lex(value.hook, ``, `macro`))
				if (hook instanceof TwineError) {
					throw new LoadGameError(`${errorMessageOpener}This custom command's hook couldn't be recreated: ${value.toSource}`)
				}
				const customCommand = new CustomCommand({
					changer,
					hook: <string>hook,
					/*
						TODO: Is this the right name?
					*/
					variables: VarScope.deserialise(`a custom command's variables`, `temp`, value.variables, pastTimeline, section),
					toSource: value.toSource
				})
				/*
					This is the best that can be done right now.
				*/
				if (customCommand instanceof TwineError) {
					throw new LoadGameError(`${errorMessageOpener}This custom command couldn't be recreated: ${value.toSource}`)
				}
				ret.variableStore[key] = customCommand
			}
			/*
				Normal objects (as opposed to strings of source) are serialised ValueRefs.
			*/
			else if (typeof value === `object`) {
				const v = ValueRef.dereference(key, value, pastTimeline, section)
				if (v instanceof TwineError) {
					throw new LoadGameError(`${errorMessageOpener}An error was produced when recreating a variable from a reference: ${v.message}`)
				}
				ret.variableStore[key] = v
				/*
					Save and re-use this ValueRef for the next time the game is saved.
				*/
				;(ret.valueRefs ||= Object.create(null))[key] = new ValueRef(value)
			}
			else {
				const v = section.eval(lex(value, ``, `macro`))
				if (v instanceof TwineError) {
					throw new LoadGameError(`${errorMessageOpener}An error was produced when recreating a variable from a reference: ${v.message}`)
				}
				let unstorable: AnyUnstorable
				if ((unstorable = unstorableValue(value))) {
					throw new LoadGameError(`${errorMessageOpener}A value was recreated that can't be stored in a variable: ${objectName(unstorable)}`)
				}
				ret.variableStore[key] = <AnyStorable>v
			}
		}
		for (let key in typeDefs) {
			const v = section.eval(lex(typeDefs[key], ``, `macro`))
			if (v instanceof TwineError) {
				throw new LoadGameError(`${errorMessageOpener}An error was produced when recreating a variable's datatype: ${v.message}`)
			}
			let unstorable: AnyUnstorable
			if ((unstorable = unstorableValue(v))) {
				throw new LoadGameError(`${errorMessageOpener}A variable's datatype was recreated that can't be stored in a variable: ${objectName(unstorable)}`)
			}
			ret.typeDefs[key] =  <AnyStorable>v
		}
		return ret
	}
}

export default VarScope