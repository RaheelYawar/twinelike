import $ from "jquery"
/*
	TwineNotifiers are special debug notifications created by the TwineScript runtime in debug mode.
	They are used to signify when a special event has occurred.
*/
class TwineNotifier {

	message: string

	constructor(message: string) {
		this.message = message
	}

	render() {
		/*
			This is attached as an attr instead of body text, so that
			its text isn't considered part of the element by jQuery#text().
		*/
		return $(`<tw-notifier>`).attr(`message`, this.message)
	}

}

Object.preventExtensions(TwineNotifier)
Object.preventExtensions(TwineNotifier.prototype)

export default TwineNotifier