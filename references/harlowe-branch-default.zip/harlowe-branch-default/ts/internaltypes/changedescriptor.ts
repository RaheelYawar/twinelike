import $ from "jquery"
import {ExceptMethods, Obj, assert, transitionIn} from "../utils.js"
import Renderer from "../renderer.js"
import { AnyStorable, Changer, Enchantment, HookSet, ImageAsset, JQueryCSSParameter, Lambda } from "../datatypes.js"
import { Section } from "../section.js"
import { AnyToken } from "../markup/markup.js"

const {exec} = Renderer

const {assign,keys,seal,hasOwn} = Object
const {isArray} = Array
/*
	When a new Section (generally a hook or expression) is about to be rendered,
	a ChangeDescriptor is created and fed into all of the Changers which are
	attached to the Section. They mutate the ChangeDescriptor, and the result describes
	all of the changes that must be made to the Section on rendering.
*/

/*
	A quick helper function which converts "verbatim" hooks' source into text nodes, EXCEPT newlines, which become raw <br>s
	or <tw-consecutive-br>s. Returns an array designed for use with $().
*/
const verbatim = (source: string | AnyToken[]) =>
	(typeof source === `string` ? source : source.map(e => e.text).join(``)).split(/\n/g).reduce((a: (Text | HTMLElement)[], e,i,{length}) =>
		a.concat(document.createTextNode(e), i !== length - 1 ? document.createElement(e.length ? `br` : `tw-consecutive-br`) : []), [])

type ChangeDescriptorProperties = ExceptMethods<Partial<ChangeDescriptor>>

type NewTarget = { target: HookSet, append: string/*`append` | `prepend` | `replace`*/, before?: boolean }

class ChangeDescriptor {
	// The hook's source (either an array of lexed tokens, or a string), which can be finagled before it is run.
	declare source: string | AnyToken[]
	// Used by (append-with:), these are {source,append} objects to apply to the source at render time.
	declare appendSource?: Array<{ source:string | AnyToken[], append: string/*`append` | `prepend` | `replace`*/ }>
	// Whether or not this code is enabled. (Disabled code won't be used until something enables it).
	declare enabled: boolean
	// Used by (link:) and its ilk, these are {descriptor, changer} objects used to create and style the link element that
	// delays the displays of this hook. Each enabler should create an element that removes the CD from this array when activated.
	declare enablers?: Array<{ descriptor: ChangeDescriptor, changer: Changer }>
	// Whether to render the source at all, or display it verbatim.
	declare verbatim: boolean
	// Where to render the source, if not the hookElement.
	declare target?: JQuery | (() => JQuery)
	// Which jQuery method name to append the source to the dest with. Empty if the descriptor is merely enchanting text.
	declare append: string
	// Alternative targets (which are {target,append} objects) to use instead of the original.
	declare newTargets?: NewTarget[]
	// Which built-in transition to use.
	declare transition: string | null
	// The duration of the transition, in ms, or null/undefined if the default speed should be used.
	declare transitionTime?: number
	// Whether or not the transition given above should not be used, but saved for an interaction element
	// that reuses this ChangeDescriptor, such as a (link:). This replaces the transition with "instant"
	// but leaves the "transition" value untouched.
	declare transitionDeferred?: boolean
	// The duration, in ms, to delay the start of the transition.
	declare transitionDelay?: number
	// If a keyboard key or mouse button is held down, skip this many milliseconds in the transition.
	declare transitionSkip?: number
	// A jQuery .css()-compatible property that makes a "transform-origin" value for this element as it transitions.
	declare transitionOrigin?: string | JQueryCSSParameter | (() => string)
	// How many frames a transition should be expedited (because it was accelerated by (t8n-skip:))
	declare expedite?: number
	// An object of {[temp variable] : values array} pairs, which the source should loop over. Used only by (for:) and custom commands.
	loopVars?: Obj<AnyStorable[]> =  Object.create(null)
	//  A set of CSS styles to apply inline to the hook's element.
	styles: JQueryCSSParameter[] = []
	// Array of objects of attributes to apply to the <tw-expression> using $.fn.attr().
	// Some attributes' values can be functions that reference existing values. Therefore,
	// rather than a single object, this must be an array of objects.
	// Used by (hook:) and (css:).
	attr: Obj<string | number | boolean | ((this:HTMLElement, attr: string, value: string) => string | number | boolean)>[] = []
	// Data to attach to the <tw-hook> (NOT the <tw-expression>) using $.fn.data().
	data: {
		/*
			Used to allow (rerun:) to retrieve the source of a hidden hook.
		*/
		originalSource?: string | AnyToken[]
		hidden?: boolean
		/*
			Used by link macros.
		*/
		passageT8n?: {
			time?: number
			depart?: string
			departOrigin?: (this:HTMLElement) => (string | JQueryCSSParameter)
			arrive?: string
			arriveOrigin?: (this:HTMLElement) => (string | JQueryCSSParameter)
		}
		linkPassageName?: string
		section?: Section
		/*
			Various command macro events.
		*/
		enchantmentEvent?: VoidFunction
		clickEvent?: (expr: JQuery) => void
		errorEvent?: (expr: JQuery) => void
		inputBoxEvent?: (expr: JQuery) => void
		checkboxEvent?: (expr: JQuery) => void
		fullscreenEvent?: (expr: JQuery) => void
		dropdownEvent?: (expr: JQuery) => void
		forgetUndosEvent?: (expr: JQuery) => void
		twoWayBindEvent?: (expr: JQuery, obj: unknown, name: string) => void
		imageLoadEvent?: (expr: JQuery, image: ImageAsset) => void
		/*
			Used by (live:).
		*/
		live?: { delay: number } | {
			event: Lambda | {
				when: true
				filter: (section: Section) => boolean[]
			}
		}
		/*
			Used by (hover-style:).
		*/
		hoverChanger?: Changer
	} = {}
	// Functions which add enchantments that are specific to the hook.
	// Because of a circular dependency, they call addEnchantment themselves. Used only by (enchant-in:) and its ilk.
	declare innerEnchantments?: ((a:JQuery | HookSet) => Enchantment)[]
	// A Section that 'owns' this ChangeDescriptor.
	declare section?: Section
	// Used by certain time-specific characteristics of this descriptor (currently, just transitions).
	declare timestamp: number
	// Used by (out:), it prevents the attached hook from being run inside the custom macro (rather than outside).
	declare output: boolean

	/*
		This method produces a short list of properties this descriptor has, which were altered by the changers
		run against it (or supplied to it at creation).
		It's used by (hover-style:) to ensure that the changers it receives only affect styles.

		TODO: See if a more efficient way of doing this is possible.
	*/
	summary() {
		return [
			`source`, `appendSource`, `enabled`, `verbatim`, `target`, `append`, `newTargets`,
			`transition`, `transitionTime`, `transitionDeferred`, `transitionDelay`,
			`transitionSkip`, `transitionOrigin`, `innerEnchantments`, `enablers`, `output`,
		]
		.filter(e => hasOwn(this,e))
		.concat(<string[]>[
			this.attr.length && `attr`,
			this.styles?.length && `styles`,
			this.loopVars && keys(this.loopVars).length && `loopVars`,
			keys(this.data).length && `data`,
		].filter(Boolean))
	}

	/*
		This creates an inheriting ChangeDescriptor, and is basically
		another shorthand for the old create-assign pattern.
		ChangeDescriptors can delegate to earlier descriptors if need be.
		Passed-in properties can be added to the descriptor, and a single
		(presumably composed) Changer as well.
	*/
	constructor(properties?: Partial<ChangeDescriptorProperties>) {
		/*
			Of course, we can't inherit array contents from the prototype chain,
			so we have to copy the arrays.
		*/
		properties && assign(this, properties)
	}
	
	/*
		This method applies the style/attribute/data entries of this descriptor
		to the target HTML element.
	*/
	update() {
		const {newTargets, transition, transitionDeferred, append} = <ChangeDescriptorProperties>this
		let {target} = <ChangeDescriptorProperties>this
		/*
			If this is an enabler descriptor (such as created by (link:)) it's possible the target property was a method deferring the retrieval
			of the actual target, as a necessity for being attached to commands like (icon-undo:). Resolve that method now.
		*/
		if (typeof target === `function`) {
			target = target()
		}
		/*
			target should never be falsy. Nevertheless...
		*/
		if (!target) {
			return
		}
		
		/*
			This loop iterates over every DOM element that the target
			ultimately includes.
		*/
		const forEachTarget = (elem: JQuery) => {
			/*
				Apply the style attributes to the element.
			*/
			if (isArray(this.styles) && this.styles.length > 0) {
				/*
					Some styles can be applied right away - these are string properties
					of the styles objects (for instance, "condense" is {"letter-spacing": "-0.08em"}).
					Others depend on the pre-existing CSS to calculate their values (for instance,
					"blurrier" converts the dominant text colour into a text shadow colour,
					changing the text itself to transparent.) These must be applied afterward,
					as they depend on probing the current styles with .css().
				*/
				const [independent, dependent] = this.styles.reduce((a: [JQueryCSSParameter[], JQueryCSSParameter[]], style) => {
					/*
						Dependent styles are function properties of the styles objects,
						and this loop sifts through to separate them from independent styles.
					*/
					keys(style).forEach(k => {
						const v = style[k]
						a[+(typeof v === `function`)].push({[k]:v})
					})
					return a
				}, [[],[]])

				/*
					Now, the independent CSS can be applied immediately.
				*/
				independent.forEach(e => elem.css(e))
				/*
					If the user has complicated story CSS, it's not possible
					to determine the computed CSS of an element until it's connected to the
					DOM. So, now this .css call is deferred for 1 frame, which should
					(._.) be enough time for it to become attached.
				*/
				setTimeout(() => {
					dependent.forEach(e => elem.css(e))
				})
			}
			/*
				If HTML attributes were included in the changeDescriptor, apply them now.
			*/
			if (this.attr) {
				this.attr.forEach(e => elem.attr(e))
			}
			/*
				Same with jQuery data (such as functions to call in event of, say, clicking).
			*/
			if (this.data) {
				elem.data(this.data)
			}
		}

		/*
			forEachTarget should be run on every target element, be there a set or a single one.
			As in render(), the newTargets should be used instead of the original if present.
		*/
		let targets: JQuery | HookSet | Array<JQuery | HookSet> = target
		if (isArray(newTargets) && newTargets.length) {
			targets = newTargets.map(t => t.target)
		}

		if (isArray(targets)) {
			for (let i = 0; i < targets.length; i += 1) {
				/*
					It's OK for length>1 jQuery collections to be treated as single
					elements here, because the methods called on them (data(), attr(), css())
					work regardless of number of contained elements.
				*/
				let t = targets[i]
				/*
					When update() is called, all of the targets in newTargets should be jQuerys
					instead of HookSets.
					TODO: Figure out why (Jan 2024).
				*/
				;(`jquery` in t) && forEachTarget(t)
			}
		} else {
			forEachTarget(targets)
		}

		/*
			If this isn't a descriptor that's appending/replacing code, a new transition has
			been installed on this existing hook.
			Transition it using this descriptor's given transition, if it wasn't deferred (i.e. behind a link).
		*/
		if (transition && !transitionDeferred && !append) {
			/*
				Hooks should only animate if they're appearing in the passage for the first time. To determine
				this, find the nearest parent with a timestamp (installed by render() below) and compare that
				to the current time.
			*/
			let stamped = target, ts: number
			do {
				ts = stamped.data(`timestamp`)
				!ts && (stamped = stamped.parent())
			}
			while (!ts && stamped.length)
			transitionIn(target, transition, this.transitionTime, this.transitionDelay, this.transitionSkip,
				/*
					This delta expedites the animation - if it's expedited past its natural end,
					it's as if it isn't re-animated (which it shouldn't).
				*/
				ts ? Date.now() - ts : 0,
				this.transitionOrigin
			)
		}
	}
	
	/*
		This method renders TwineMarkup, executing the expressions
		within. The expressions only have visibility within this passage.
	*/
	render(): JQuery {
		const
			{transition, transitionTime, transitionDeferred, enabled, enablers, data, section, newTargets, innerEnchantments, appendSource, output} = this,
			source = <string>this.source
		let
			{target, append} = this

		/*
			If this is an enabler descriptor (such as created by (link:)) it's possible the target property was a method deferring the retrieval
			of the actual target, as a necessity for being attached to commands like (icon-undo:). Resolve that method now.
		*/
		if (typeof target === `function`) {
			target = target()
		}
		/*
			target should never be falsy. Nevertheless...
		*/
		if (!target) {
			return $()
		}
		let oldTarget = target

		assert(append, `This ChangeDescriptor doesn't have an 'append' method chosen!`)

		/*
			If this is an (out:) changer, don't run this at all yet. (Wait until this CD has been outputted from the custom macro,
			whereupon this boolean is set to false).
		*/
		if (output) {
			return $()
		}

		/*
			Overriding all other aspects of this CD are the enablers, which create alternative elements in this CD's place. This overrides even (if:).
		*/
		if (enablers?.length) {
			const {descriptor, changer} = enablers[0]
			const createdElement = descriptor.render()
			/*
				Enablers come with a changer to apply directly to the newly-rendered link element. This is applied
				using the following slightly crude construction, similar to how Enchantment enchants a scope.
			*/
			if (changer) {
				const cd = new ChangeDescriptor({ section, target:createdElement })
				changer.run(cd)
				cd.update()
			}
			return createdElement
		}

		/*
			If this isn't enabled, nothing needs to be rendered. However,
			the source needs to be saved in case the (show:) or (rerun:) macro is used on this.
			We store it as "originalSource" in every element's jQuery data store.
		*/
		if (!enabled || (target.attr(`hidden`) !== undefined)) {
			/*
				You may wonder if this should use the descriptor's 'innerSource', which is used by
				(link:) to store the "inner" source behind the link's <tw-link> source. What should
				happen is that when the hidden hook is shown, the link's <tw-link> is shown, which then
				remains clickable and able to reveal the innerSource.

				Also, this should not use newTargets, as a construction of the form "(hide:)(replace:?b)|a>[]"
				followed by (show:?a) should result in ?a appearing, instead of nothing happening. (And
				(show:?b) shouldn't do anything, either.)
			*/
			new ChangeDescriptor({target,
				/*
					In the hidden hook, preserve HTML attributes (which includes 'name') but exclude 'style'.
				*/
				attr: this.attr.filter(e => !(`style` in e)),
				data: { ...data, originalSource:source, hidden:true}}).update()
			return $()
		}

		let t: JQuery | NewTarget[] = target
		/*
			newTargets are targets specified by revision macros (such as ?foo in (replace:?foo))
			which should be used instead of the original.
		*/
		if (isArray(newTargets) && newTargets.length) {
			t = newTargets
		}
		/*
			If there's no target (after modifying newTargets), something incorrect has transpired.
		*/
		assert(t, `ChangeDescriptor has source but not a target!`)
		/*
			For "collection" targets (a HookSet, newTarget array, or a length>1 jQuery), each target must be rendered separately,
			by performing recursive render() calls. Then, return a jQuery containing every created element,
			so that consumers like Section.renderInto() can modify all of their <tw-expressions>, etc.
		*/
		let dom = $()
		;(<NewTarget[]>(<(JQuery | NewTarget)[]>[]).concat(t)
			// If the target is a jQuery, it's either just a normal ChangeDescriptor targeting a single hook, or
			// a recursive call of the below collection rendering loop. If so, don't keep recursing.
			.filter(target => !(`jquery` in target)))
			// Henceforth, all elements in this array are either HookSets, or NewTarget objects (containing HookSets).
			// Convert both of these types to the same type of object: a pair of { elements, append };
			.map(({append:append_, before = false, target}) => {
				return {
					/*
						Assertion: if this has NewTargets, then it has a Section.
					*/
					elements: target.hooks(section!)
						.filter((_,e) =>
							/*
								"before" should only be true if this newTarget was created by
								(replace:), (append:) or (prepend:).
								These macros are scoped to only target hooks and text that
								has already rendered - earlier in the passage or section to
								this changed hook (i.e. the element in oldTarget).
							*/
							!(before
								/*
									Of course, we should only prevent targeting elements that *haven't rendered yet*.
									There isn't a very idiomatic way of determining this, but assuming that it's
									A: detached from the DOM,
								*/
								&& e.compareDocumentPosition(document) & 1
								/*
									and B: later in the node tree, seems a safe enough assumption.
								*/
								&& e.compareDocumentPosition(oldTarget[0]) & 2)
						),
					append:append_,
				}
			},[])
			// Now, iterate over all of them.
			.forEach(({elements, append}) => {
				elements.each((_,Elem) => {
					let elem = $(Elem)
					/*
						Generate a new descriptor which has the same properties
						(rather, delegates to the old one via the prototype chain)
						but has just this hook/word as its target.
						Then, render using that descriptor.
					*/
					dom = dom.add((<ChangeDescriptor>Object.setPrototypeOf({ target: elem, append, newTargets:null }, this)).render())
					/*
						The above call to .hooks() potentially created <tw-pseudo-hook> elements. If this is one
						of them, remove it.
					*/
					elem.filter(`tw-pseudo-hook`).contents().unwrap()
				})
			})
		/*
			Return the compiled DOM, or return an empty set if the target is a collection
			and the above loop didn't produce anything.
		*/
		if (dom.length || isArray(t)) {
			return dom
		}
		/*
			Henceforth, the target is a single jQuery.
		*/

		/*
			Check to see that the given jQuery method in the descriptor
			actually exists, and potentially tweak the name if it does not.
		*/
		let appendMethod = append
		assert(appendMethod in t || appendMethod === `replace`,  `The target doesn't have a '${appendMethod}' method.`)
		/*
			(replace:) should actually replace the interior of the hook with the
			content, not replace the hook itself (which is what .replaceWith() does).
			So, we need to do .empty() beforehand, then change the method to "append"
			(though "prepend" will work too).
		*/
		if (appendMethod === `replace`) {
			/*
				There's one exception to the above, however - if the target is a text node
				(such as in (enchant:?hook's chars)) then replaceWith is fine.
			*/
			if (t[0] instanceof Text) {
				appendMethod = `replaceWith`
			}
			else {
				t.empty()
				appendMethod = `append`
			}
			/*
				If I wished to add a variant of (replace:) that did remove the entire
				hook, then I'd change append to "replaceWith".
			*/
		}
		/*
			Two more tweaks to the jQuery method name are needed for text nodes,
			in addition to the above.
		*/
		if (t[0] instanceof Text) {
			if (appendMethod === `append`) {
				appendMethod = `after`
			}
			if (appendMethod === `prepend`) {
				appendMethod = `before`
			}
		}
		/*
			Render the TwineMarkup source into a HTML DOM structure.
			
			You may notice that the design of this and renderInto() means
			that, when a HookSet has multiple targets, each target has
			its own distinct rendering of the same TwineMarkup.
			
			(Note: source may be '' if the descriptor's append method is "remove".
			In which case, let it be an empty set.)
			
			Notice also that the entire expression is wrapped in $():
			a jQuery must be returned by this method, and $(false)
			conveniently evaluates to $(). Otherwise, it converts the
			array returned by $.parseHTML into a jQuery (unless, of course,
			this has been changed with (verbatim:))
			
			This has to be run as close to insertion as possible because of
			the possibility of <script> elements being present - 
			$.parseHTML executes scripts immediately on encountering them (if
			the third arg is true) and it wouldn't do to execute them and then
			early-exit from this method.
		*/
		dom = <JQuery>(source ?
			this.verbatim ? $(verbatim(source)) : exec(source)
			: $(source))

		/*
			If the source has any addenda, compile that separately and insert it into the DOM structure.
			Note that by compiling it separately, partial structures in one addenda can't contaminate the original source.
		*/
		if (isArray(appendSource)) {
			appendSource.forEach(({source, append}) => {
				const addenda = <JQuery>(this.verbatim ? $(verbatim(source)) : exec(source))
				if (append === `append`) {
					dom = dom.add(addenda)
				}
				else if (append === `prepend`) {
					dom = addenda.add(dom)
				}
				else {
					dom = addenda
				}
			})
		}

		/*
			Now, insert the DOM structure into the target element.
			
			Here are the reasons why the DOM must be connected to the target before the
			expressions are evaluated:
			
			* Various Twine macros perform DOM operations on this pre-inserted jQuery set of
			rendered elements, but assume that all the elements have a parent item, so that e.g.
			.insertBefore() can be performed on them.
			
			* Also, and perhaps more saliently, Section uses .find() to select
			<tw-macro> elements etc., which assumes that the jQuery object has a single
			container element at its "root level".
			
			* Finally, live macros' interval functions deactivate themselves if the
			section is disconnected from Utils.storyElement, and if they initially
			run without being connected, they will immediately deactivate.
		*/
		/*
			Because JQuery's type only "allows" numeric indexing,
			this type-kludge is required.
		*/
		(<Obj<(a?:JQuery) => JQuery>><unknown>t)[appendMethod](
			// As mentioned above, dom may be empty if append is "remove".
			dom.length ? dom : undefined
		)
		/*
			This timestamp is used exclusively for transition enchantments, to determine whether
			to re-animate the hook enchanted by it.
		*/
		t.data(`timestamp`, Date.now())
		/*
			Apply the style/data/attr attributes to the target element.
		*/
		this.update()
		
		/*
			Transition it using this descriptor's given transition, if it wasn't deferred
			Note that this.update() won't perform transitionIn because append must be non-falsy here.
		*/
		if (transition && !transitionDeferred) {
			transitionIn(
				/*
					There's a slight problem: when we want to replace the
					target, we don't need to apply a transition to every
					element, so we just transition the target itself.
					
					But, when we're *appending* to the target, we don't want
					the existing material in it to be transitioned, so
					then we must resort to transitioning every element.
					
					This is #awkward, I know...
				*/
				append === `replace` ? target : dom,
				transition, transitionTime, this.transitionDelay, this.transitionSkip,
				// expedite should always be 0 for changeDescriptors that have their render() called, but,
				// for consistency...
				this.expedite,
				this.transitionOrigin
			)
		}

		/*
			After everything else is done, inner (enchant-in:) enchantments are created here.
		*/
		if (innerEnchantments) {
			/*
				Assertion: if this has innerEnchantments, then it has a Section.
			*/
			innerEnchantments.map(fn => fn(t)).forEach(ench => section!.addEnchantment(ench))
		}
		
		return dom
	}
}

/*
	These are the ChangeDescriptor defaults.
	Because summary() checks whether a ChangeDescriptor has been modified using hasOwn(),
	these defaults should be on the prototype instead of being class properties.
*/
assign(ChangeDescriptor.prototype, {
	source: ``,
	enabled: true,
	verbatim: false,
	append: `replace`,
	transition: ``,
	output: false,
	timestamp: 0,
})

seal(ChangeDescriptor)

export default ChangeDescriptor