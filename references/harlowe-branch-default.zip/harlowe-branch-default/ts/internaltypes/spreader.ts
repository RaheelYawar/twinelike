import {plural} from "../utils.js"
import { TypedVar, Datatype, TwineError, AnyValue, UserFacing, HarloweValue } from "../datatypes.js"
import {toSource, clone, objectName} from "../utils/operationutils.js"

/*
	This takes a plain sequence value, and wraps
	it in a special structure that denotes it to be spreadable.
	This is created by the spread (...) operator.
*/
export default class Spreader implements HarloweValue, UserFacing<Spreader> {
	value: AnyValue
	/*
		If a spreader is erroneously put in brackets (such as (...$arr)) then
		it becomes isolated as an object, and thus observable.
		Hence, it is "user-facing" during edge-cases.
	*/
	declare readonly typeID: string
	declare readonly typeName: string
	declare readonly unstorable: boolean
	static { Object.assign(this.prototype, {
		typeID: `spreader`,
		typeName:`a spreaded '...' value`,
		unstorable: true
	})}
	get objectName():string { return plural(typeof this.value === `string` || Array.isArray(this.value) ? [...this.value].length : 1, `spreaded '...' value`) }

	toSource() {
		return `${typeof this.value === `string` || Array.isArray(this.value) ? [...this.value].map(toSource) : `...${toSource(this.value)}`}`
	}
	static create(val: AnyValue | TwineError) {
		if (val instanceof TwineError) {
			return val
		}
		/*
			TypedVars and Datatypes have a special response to the spread operator: turn into
			"rest parameter" versions of themselves.
		*/
		if ((val instanceof TypedVar) || val instanceof Datatype) {
			const value2 = clone(val)
			/*
				Because currently (Feb 2024) it's not syntactically possible to have spreaded non-datatypes
				to the left of -type, this is a safe assertion.
			*/
			;((value2 instanceof TypedVar) ? <Datatype>value2.datatype : value2).rest = true
			return value2
		}
		if (!Array.isArray(val) && typeof val !== `string` && !(val instanceof Set)) {
			return new TwineError(`operation`,
				`I can't spread out ${
					objectName(val)
				}, because it is not a string, dataset, or array.`
			)
		}
		// Assertion is based on the containsError() check above.
		return new Spreader(val)
	}
	private constructor(val: AnyValue) {
		this.value = val
	}
}