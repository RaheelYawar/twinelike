import $ from "jquery"
import {assert, transitionOut, options, storyElement, detachStoryElement, reattachStoryElement, Obj } from "./utils.js"
import State from "./state.js"
import {Passages,Passage} from "./passages.js"
import {Section} from "./section.js"
import { AnyToken } from "./markup/markup.js"
import { Token } from "./markup/lexer.js"
import { ChangeDescriptor, TwineError } from "./datatypes.js"

/*
	Engine is a singleton class, responsible for rendering passages to the DOM.
*/
let Engine
let DebugMode: (initialError?:TwineError, code?: string) => void

/*
	Creates the HTML structure of the <tw-passage>. Sub-function of showPassage().

	@return {jQuery}
*/
function createPassageElement () {
	const
		container = $( `<tw-passage><tw-sidebar>` ),
		sidebar = container.children(`tw-sidebar`)
	
	// The default sidebar buttons consist of Undo (Back) and Redo (Forward) buttons.
	// The event code for these is in macrolib/commands.js, alongside the various "icon" macros.
	const
		back = $(`<tw-icon tabindex=0 alt="Undo" title="Undo">&#8630;</tw-icon>`),
		fwd  = $(`<tw-icon tabindex=0 alt="Redo" title="Redo">&#8631;</tw-icon>`)

	if (State.pastLength <= 0) {
		back.css(`visibility`, `hidden`)
	}
	if (State.futureLength <= 0) {
		fwd.css( `visibility`, `hidden`)
	}
	sidebar.append(back, fwd)

	return container
}

/*
	A small helper that adds a passage header or footer (or the main passage tree itself) to a given array.
	Because the array itself needs to be analysed (see below), this mutates the array in-place.
	setupPassage is a Passage map, or undefined if the main passage's name was given.
*/
function setupPassageElement(source: AnyToken[], tagTypeOrPassageName:string, setupPassage?: Passage) {
	let newToken: AnyToken | undefined
	if (!setupPassage) {
		newToken = Passages.getTree(tagTypeOrPassageName)
	}
	else {
		const name = setupPassage.get(`name`)
		const tree = Passages.getTree(name)
		if (tree.children.length) {
			newToken = <AnyToken>Object.setPrototypeOf({
				type: `include`,
				tag: tagTypeOrPassageName,
				name,
				children: tree.children,
				text: tree.text,
			}, Token.prototype)
		}
	}
	if (!newToken) {
		return
	}
	source.push(newToken)
}

/*
	Shows a passage by transitioning the old passage(s) out, and then adds the new passages.

	displayOptions allows stretchtext (boolean), transitionIn (string)
	or transitionOut (string) to be selected.
*/
type DisplayOptions = {
	stretch?:boolean
	loadedGame?:boolean
	transition?:ChangeDescriptor[`data`][`passageT8n`]
}
function showPassage (name:string, displayOptions: DisplayOptions = {}) {
	/*
		displayOptions should only contain 'stretch', 'transition' and 'loadgame' properties.
		The first two are used further below.
	*/
	const {loadedGame} = displayOptions

	const
		// The passage
		passageData = Passages.get(name),
		// The <tw-story> element
		story = storyElement

	let
		/*
			The <tw-story>'s parent is usually <body>, but if this game is embedded
			in a larger HTML page, it could be different.
		*/
		parent = story.parent(),
		{
			// Whether or not this should be a stretchtext transition
			stretch,
			// The transition definition object.
			transition: {
				depart: depart = `instant`,
				arrive: arrive = `dissolve`,
				departOrigin,
				arriveOrigin,
				time,
			} = {},
		} = displayOptions

	/*
		Find each <tw-enchantment> with an "enchantedProperties" data name, which holds properties
		tweaked on <tw-story> to avoid CSS clashes, and unset those properties.
	*/
	parent.findAndFilter(`tw-enchantment`).each((_,E) => {
		let e=$(E)
		const enchantedProperties = <string[]>e.data(`enchantedProperties`)
		if (enchantedProperties) {
			/*
				An identical line to this appears in Enchantment.disenchant()
			*/
			story.css(enchantedProperties.reduce((a: Obj<string>, e)=>(a[e] = ``,a),{}))
		}
		/*
			If this is enchanting <tw-story>, then immediately disenchant.
			Note that since old passages take awhile to transition out, disenchanting everything
			else within them would be unwise.
		*/
		if (e[0] === parent[0]) {
			parent = story.unwrap().parent()
		}
	})

	/*
		Early exit: the wrong passage name was supplied.
		Author error must never propagate to this method - it should have been caught earlier.
	*/
	assert(!!passageData, `No passage named "${name}"!`)
	
	/*
		Find out how many tw-passage elements there are currently in the
		destination element.
	*/
	const oldPassages = story.children(`tw-passage`).not(`.transition-out, .transition-out *`)

	const tags = (passageData.get(`tags`) || []).join(` `)
	const newPassage = createPassageElement()

	/*
		The departOrigin and arriveOrigin values are functions that produce CSS property strings,
		similar to jQuery .css() objects. While Utils.transitionIn() can handle these, they sadly
		must be run before the element is detached from the DOM, as these functions tend to use .offset().
	*/
	let departOriginStr = departOrigin?.call(oldPassages[0])
	let arriveOriginStr = arriveOrigin?.call(newPassage[0])

	/*
		Cache the width of the <tw-passage> elements before detaching the <tw-story> (below),
		for use when transitioning out (also below).
		Because this only applies if stretchtext is false, this only needs the first <tw-passage>'s width
		(as there should be no more <tw-passage>s transitioning out).
	*/
	const willTransitionOut = !stretch && depart
	const oldPassageWidth = willTransitionOut && oldPassages.css(`width`)
	
	/*
		Because rendering a passage is a somewhat intensive DOM manipulation,
		the <tw-story> is detached before and reattached after.
	*/
	detachStoryElement()

	/*
		Make the passage's tags visible in the DOM, on both the <tw-passage> and
		the <tw-story>, for user CSS availability.
	*/
	newPassage.appendTo(story).attr({tags})

	/*
		If this isn't a stretchtext transition, send away all of the
		old passage instances.
	*/
	if (willTransitionOut) {
		// The above checks verify this assertion.
		transitionOut(oldPassages, depart, time, 0, 0, 0, departOriginStr)
		/*
			This extra adjustment is separate from the transitionOut method,
			as it should only apply to the block-level elements that are
			passages. It enables the new transitioning-in passage to be drawn
			over the departing passage. Note: this may prove to be too restrictive
			in the future and need to be made more subtle.
		*/
		oldPassages.css({
			/*
				Note that both of these rely on the <tw-transition-container> having position:relative, which is currently (Nov 2023) only
				due to a CSS reset on *.
			*/
			position: `absolute`,
			/*
				This painfully forces the <tw-passage>s to retain the same width as they did
				when in normal document flow, so that block-level elements inside it retain roughly the
				correct widths.
			*/
			width() {
				// The willTransitionOut check above confirms this assertion.
				return oldPassageWidth !== `0px` ? <string>oldPassageWidth : `100%`
			}
		})
	}

	/*
		Only the most recent passage's tags are present on the <tw-story>.
	*/
	story.attr({tags})
	
	const section = new Section(newPassage)
	/*
		The 'loadgame' display option should prevent (load-game:) loops from happening
		(loading directly into a (load-game:) macro).
	*/
	if (loadedGame) {
		section.loadedGame = true
	}

	/*
		Actually do the work of rendering the passage now.
	*/
	const source: AnyToken[] = []
	/*
		We add, to the passage source, the source of the 'header' and 'footer' tagged passages.
		We explicitly include these passages inside <tw-header> elements
		so that they're visible to the author when they're in debug mode, and can clearly
		see the effect they have on the passage.
	*/
	/*d:
		header tag

		It is often very useful to want to reuse a certain set of macro calls in every passage,
		or to reuse an opening block of text. You can do this by giving the passage the special
		tag `header`, or `footer`. All passages with these tags will have their source text included at the top
		(or, for `footer`, the bottom) of every passage in the story, as if by an invisible (display:) macro call.

		If many passages have the `header` tag, they will all be displayed, ordered by their passage
		name, sorted alphabetically, and by case (capitalised names appearing before lowercase names).

		#transclusion 1
	*/
	/*d:
		debug-header tag
		
		This special tag is similar to the `header` tag, but only causes the passage
		to be included if you're running the story in debug mode.

		This has a variety of uses: you can put special debug display code in this
		passage, which can show the status of certain variables or provide links
		to change the game state as you see fit, and have that code
		be present in every passage in the story, but only during testing.

		All passages tagged with `debug-header` will run after the passages tagged `header` will run,
		ordered by their passage name, sorted alphabetically, and by case (capitalised names appearing
		before lowercase names).

		#transclusion 4
	*/
	/*d:
		footer tag

		This special tag is identical to the `header` tag, except that it places the passage
		at the bottom of all visited passages, instead of the top.

		#transclusion 2
	*/
	/*d:
		debug-footer tag
		
		This special tag is identical to the `debug-header` tag, except that it places the passage
		at the bottom of all visited passages, instead of the top.

		All passages tagged with `debug-footer` will run, in alphabetical order
		by their passage name, after the passages tagged `footer` have been run.

		#transclusion 5
	*/
	/*
		We only add the startup and debug-startup passages if this is the very first passage.
		Note that the way in which source is modified means that startup code
		runs before header code.
	*/
	/*d:
		startup tag

		This special tag is similar to `header`, but it will only cause the passage
		to be included in the very first passage in the game.

		This is intended to simplify the story testing process: if you have setup
		code which creates variables used throughout the entire story, you should put it in
		a passage with this tag, instead of the starting passage. This allows you to test your
		story from any passage, and, furthermore, easily change the starting passage if you wish.

		All passages tagged with `startup` will run, in alphabetical order
		by their passage name, before the passages tagged `header` will run.

		#transclusion 3
	*/
	/*d:
		debug-startup tag
		
		This special tag is similar to the `startup` tag, but only causes the passage
		to be included if you're running the story in debug mode.

		This has a variety of uses: you can put special debugging code into this
		passage, or set up a late game state to test, and have that code run
		whenever you use debug mode, no matter which passage you choose to test.

		All passages tagged with `debug-startup` will run, in alphabetical order
		by their passage name, after the passages tagged `startup` will run.

		#transclusion 6
	*/
	/*
		Only run the startup passage if no past turns exist and if no turns were erased.
	*/
	if (State.pastLength <= 0 && State.turns === 1) {
		for(let p of Passages.getTagged(`startup`)) {
			setupPassageElement(source, `startup`, p)
		}
		if (options.debug) {
			for(let p of Passages.getTagged(`debug-startup`)) {
				setupPassageElement(source, `debug-startup`, p)
			}
		}
	}
	for(let p of Passages.getTagged(`header`)) {
		setupPassageElement(source, `header`, p)
	}
	if (options.debug) {
		for(let p of Passages.getTagged(`debug-header`)) {
			setupPassageElement(source, `debug-header`, p)
		}
	}
	setupPassageElement(source, name)
	for(let p of Passages.getTagged(`footer`)) {
		setupPassageElement(source, `footer`, p)
	}
	if (options.debug) {
		for(let p of Passages.getTagged(`debug-footer`)) {
			setupPassageElement(source, `debug-footer`, p)
		}
	}
	
	/*
		Then, run the actual passage.
	*/
	section.renderInto(
		source,
		newPassage,
		/*
			Use the author's styles, assigned using TwineScript,
			as well as this basic, default ChangeDescriptor-like object
			supplying the transition.
		*/
		{ transition: arrive, transitionTime: time, transitionOrigin: arriveOriginStr }
	)

	/*
		Re-enable (load-game:) usage immediately after the passage has rendered. While this won't stop
		certain (load-game:) loops caused by guarding each call with very low (after:) timeouts or whatnot,
		it's still fairly good at stopping unintentional loops.
	*/
	section.loadedGame = false
	
	reattachStoryElement()
	/*
		In stretchtext, scroll the window to the top of the inserted element,
		minus an offset of 5% of the viewport's height.
		Outside of stretchtext, just scroll to the top of the <tw-story>'s element.
	*/
	scroll(
		0,
		stretch
			? newPassage.offset()!.top - ($(window).height()! * 0.05)
			: story[0].getBoundingClientRect().top + document.body.scrollTop
	)
}

Engine = {
	
	/*
		Moves the game state backward one turn. If there is no previous state, this does nothing.
	*/
	goBack(displayOptions?: DisplayOptions) {
		if (State.rewind()) {
			showPassage(State.passage, displayOptions)
		}
	},

	/*
		Moves the game state forward one turn, after a previous goBack().
	*/
	goForward(displayOptions?: DisplayOptions) {
		if (State.fastForward()) {
			showPassage(State.passage, displayOptions)
		}
	},

	/*
		Displays a new passage, advancing the game state forward.
	*/
	goToPassage(name:string, displayOptions?: DisplayOptions) {
		// Update the state.
		State.play(name)
		showPassage(name, displayOptions)
	},

	/*
		Displays a new passage, WITHOUT advancing the game state forward.
	*/
	redirect(name:string, displayOptions?: DisplayOptions) {
		State.redirect(name)
		showPassage(name, displayOptions)
	},

	toggleFullscreen() {
		const html = document.documentElement
		/*
			A little bit of finagling with the method names is necessary for IE 11 support (as of Sep 2020).
		*/
		if (document.fullscreenElement) {
			document.exitFullscreen()
		}
		else {
			/*
				This currently doesn't do anything if the fullscreen request fails, on the extremely blithe assumption that
				fullscreen access wouldn't have changed between the check for fullscreenEnabled when the passage was created,
				and this button being clicked.
			*/
			html.requestFullscreen.call(
				/*
					The <tw-story> element can't be used as the fullscreen element, because it's detached and reattached often
					(including when it's enchanted with (enchant:?page)).
					Using <html> also has the advantage of bringing along the debug panel for the ride into fullscreen.
				*/
				html
			)
		}
	},
	
	/*
		Displays a new passage WITHOUT changing the game state.
		Used exclusively by state-loading routines.
	*/
	showPassage,

	/*
		Used by (debug:) to launch the debugger if it's not open already.
	*/
	enableDebugMode() {
		DebugMode && DebugMode()
	},

	/*
		Used to resolve a circular dependency with debugmode/mode and engine. debugmode/mode registers itself using
		this one-time method.
	*/
	registerDebugMode(mode: typeof DebugMode) {
		!DebugMode && (DebugMode = mode)
	},
}

export default Object.freeze(Engine)
