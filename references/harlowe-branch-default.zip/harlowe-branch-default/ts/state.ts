import $ from "jquery"
import { storyElement, options, assert, LoadGameError } from "./utils.js"
import {Passages} from "./passages.js"
import {Moment,MomentSerialised} from "./state/moment.js"
import { AnyStorable, Datatype, VarScope } from "./datatypes.js"
import {ValueRef} from "./state/valueref.js"
import { Merge } from "type-fest"
import { PRNG, seed, seedIter, setPRNG } from "./state/prng.js"
import { Section } from "./section.js"

/*
	State
	Singleton controlling the running game state.
*/
const {assign, create, defineProperty} = Object
const {isArray} = Array
/*
	This ensures that serialisation of Maps and Sets works as expected.
*/
defineProperty(Map.prototype, `toJSON`, { value: undefined })
defineProperty(Set.prototype, `toJSON`, { value: undefined })

/*
	A browser compatibility check for localStorage and sessionStorage.
*/
const hasStorage = [`localStorage`,`sessionStorage`].map(name => {
	/*
		This is, to my knowledge, the only surefire way of measuring localStorage's
		availability.
		* On some browsers, window.localStorage will throw when run in an <iframe sandbox>
		* On some browsers, setItem() will throw in Private Browsing mode.
	*/
	try {
		return !!window[<keyof Window>name]
			&& (() => {
				window[<keyof Window>name].setItem(`test`, `1`)
				window[<keyof Window>name].removeItem(`test`)
				return true
			})()
	} catch (e) {
		return false
	}
})

/*
	Debug Mode event handlers are stored here by on(). "forward" and "back" handlers are called
	when the present changes, and thus when play(), fastForward() and rewind() have been called.
	"load" handlers are called exclusively in deserialise(). "redirect" and "forgetUndos" are
	called for their respective methods.
*/
const eventHandlers = {
	forward: <((passageName: string, fastForward?:`fastForward`) => void)[]>[],
	back: <VoidFunction[]>[],
	load: <((timeline: Moment[]) => void)[]>[],

	beforeForward: <VoidFunction[]>[],
	beforeBack: <VoidFunction[]>[],
	beforeLoad: <VoidFunction[]>[],

	forgetUndos: <VoidFunction[]>[],
}

/*
	Stack of previous states.
	This includes both the past (moments the player has created) as well as the future (moments
	the player has undone).
	Count begins at 0 (the game start).
*/
let timeline: Moment[] = []

/*
	Index to the game state just when the current passage was entered.
	This represents where the player is within the timeline.
	Everything beyond this index is the future. Everything before and including is the past.
	It usually equals timeline.length-1, except when the player undos.
*/
let recent = -1

/*
	The present - the resultant game state after the current passage executed.
	This is a 'potential moment' - a moment that could become the newest to enter the timeline.
	This is pushed onto the timeline (becoming "recent") when going forward,
	and discarded when going backward.
	Its passage name should equal that of recent.
*/
let present = new Moment()

/*
	A cache of the serialised JSON form of the past moments. Invalidated (made falsy) whenever pastward temporal movement
	occurs. Why isn't the present included? Because the present is liable to change as (set:) macros are run. Remember that
	each past moment reflects the game state as the passage was *left*, not entered.
*/
let serialisedPast = ``
/*
	The (define:) definitions are stored in this scope. This doesn't use any typeDefs (each value is prevented from being 
	overwritten by a special case in varRef.canSet()), and should never be changed after the story begins.
*/
const definitions = new VarScope(`definitions`, `global`)

/*
	The current global game state.
	This is a special "cache" Moment that contains the entirety of the game state,
	not just diffs, for quick and reliable lookups.
	This is progressively mutated as the game progresses,
	and deltas of these changes (on a per-turn basis) are stored in Moments in the Timeline array.
*/
type CurrentType = Merge<Moment, {
	/*
		Moment uses a different variableScope class than Current.
	*/
	variables: CurrentVariableScope
	/*
		The history cache, essentially a flattened version of pastVisits, is used for speeding up (history:) lookups, which are commonly used in storylets and other places.
	*/
	history: string[]
	reconstruct: (timeline?: Moment[]) => void
	reconstructHistory: () => void
}>

let Current = <CurrentType>assign(
		/*
			Because Moment's constructor does nothing important that reconstruct() doesn't already do,
			it doesn't need to be invoked.
		*/
		create(Moment.prototype), {
	/*
		Whenever a turn is undone or the game state is reloaded entirely, the Current must be rebuilt.
	*/
	reconstruct(timeline: Moment[] = []) {
		Current.variables = new CurrentVariableScope(`this story's variables`, `global`)
		/*
			Before flattening, all of these need to be emptied.
		*/
		Current.history = []
		Current.visits = []
		/*
			Because these two are non-cumulative (the latest (mock-visits:)/(mock-turns:) call overrides the previous)
			and flatten() uses "=== undefined" to check before reassigning (because it normally acts on plain Moments),
			these need to be set to "undefined" instead of empty arrays or numbers.
		*/
		Current.mockVisits = undefined
		Current.mockTurns = undefined
		/*
			Flatten every moment into the new State.
		*/
		Current.flatten(timeline)
		/*
			Flatten the (define:) definitions into this. By doing this after flattening the timeline,
			it helps ensure that "impossible" changes to the definitions are overwritten (even though they can't happen).
		*/
		Current.variables.flatten([definitions])
		/*
			Having done that, mockVisits and mockTurns need to return to their normal types if they weren't assigned to.
		*/
		Current.mockVisits ||= []
		Current.mockTurns ||= 0
		/*
			Now we're done, except for recalibrating the PRNG and updating the history cache.
		*/
		Current.reconstructHistory()
		/*
			Restore the initial seed state.
		*/
		setPRNG(Current.seed, Current.seedIter)
		/*
			A note about seed, seedIter and passage: Current does not maintain copies of these properties
			because there is no need to. As such, these should be reset to empty values to ensure they are not erroneously used.
		*/
		Current.seed = undefined
		Current.seedIter = undefined
		Current.passage = ``
	},

	reconstructHistory() {
		Current.history = <string[]>(Current.pastVisits || []).slice(Current.forgetVisits || 0).reduce((a,e)=>(<string[]>a).concat(e), [])
		if (Current.mockVisits) {
			/*
				(mock-visits:) always adds its strings to the start.
			*/
			Current.history = (Current.mockVisits || []).concat(Current.history)
		}
	}
})

/*
	This is a special VarScope which, upon being updated, updates the present Moment to match
	whatever change occurred.
*/
class CurrentVariableScope extends VarScope {
	delete(prop:string) {
		super.delete(prop)
		/*
			Setting this Moment's variable to 'null' marks it as deleted, for serialisation.
			Note that the SystemVariables store has this as 'undefined' (via the previous
			statement) so this (probably) isn't visible outside of State.
		*/
		present.variables.variableStore[prop] = null
		delete present.variables.valueRefs?.[prop]
	}

	set(prop:string, value: AnyStorable, valueRef?: ValueRef) {
		super.set(prop, value, valueRef)
		/*
			It's not necessary to clone (pass-by-value) the value when placing it on the delta,
			because once placed in the variable store, it should be impossible to mutate
			the value anymore - only by replacing it with another set().
		*/
		present.variables.variableStore[prop] = value
		/*
			The value reference (used for save file reconstruction) is also recorded.
		*/
		if (valueRef) {
			(present.variables.valueRefs ||= Object.create(null))[prop] = valueRef
		}
		/*
			Second attempt at producing a valueRef:
			When a data structure has been permuted, attempt to construct a smaller serialisation of that
			change, based on the previous known value for the variable.
		*/
		else if ((isArray(value) || value instanceof Map || value instanceof Set || typeof value === `string`) &&
				/*
					3.3.5: Special valueRef bug triage switch (to be removed in a future version).
				*/
				!options.uncompressedStructures) {
			for(let i = recent; i >= 0; i -= 1) {
				const v = timeline[i].variables.variableStore[prop]
				if (v !== undefined && v !== null) {
					const viaValueRef = ValueRef.modifierRef(v, value, `it`)
					/*
						If it was serialised as just {via:"it"}, then we've discovered that
						the new value is identical to the previous value. If that's the case, simply
						delete this variable from the present moment instead of creating a valueRef
						for it.
					*/
					if (viaValueRef) {
						if (viaValueRef.via === `it`) {
							delete present.variables.variableStore[prop]
						} else {
							(present.variables.valueRefs ||= Object.create(null))[prop] = viaValueRef
						}
					}
					break
				}
			}
		}
	}

	defineType(prop:string, type: Datatype) {
		super.defineType(prop,type)
		present.variables.typeDefs[prop] = type
	}
}
/*
	Finish setting up Current and present. This initial reconstruct() initialises Current's specific variables.
*/
Current.reconstruct()
present.seed = seed
present.seedIter = seedIter

/*
	The current game's state.
*/
const State = {
	/*
		Getters/setters
	*/

	/*
		Get the current passage name.
		Used as a common argument to Engine.showPassage()
	*/
	get passage() {
		return present.passage
	},
	
	/*
		Get the current variables.
	*/
	get variables() {
		return Current.variables
	},

	/*
		Is there an undo cache?
	*/
	get pastLength() {
		return recent
	},

	/*
		Used by the "turns" identifier.
	*/
	get turns() {
		return recent + 1 + (Current.turns || 0) + (Current.mockTurns || 0)
	},

	/*
		Is there a redo cache?
	*/
	get futureLength() {
		return (timeline.length - 1) - recent
	},

	/*
		Get and set the current mockVisits and mockTurns state.
		These replace all previous instantiations.
	*/
	get mockVisits() {
		return Current.mockVisits || []
	},

	set mockVisits(value:string[]) {
		Current.mockVisits = value
		present.mockVisits = value
		Current.reconstructHistory()
	},

	get mockTurns() {
		return Current.mockTurns || 0
	},

	set mockTurns(value:number) {
		Current.mockTurns = value
		present.mockTurns = value
	},

	/*
		Used by (history:). Because storylets are liable to call (history:) a lot,
		it's ideal to do as little work as necessary in this.
	*/
	history() {
		return Current.history
	},

	/*
		Used by (forget-undos:). All moments before the specified index are flattened into the new first moment.
		This cannot erase timeline[recent];

		Note that this should simply never be called when used in a past moment (not the one at the end of the timeline)
		so we can assume that recent is always timeline.length-1.
	*/
	forgetUndos(ind:number) {
		if (ind < 0) {
			ind = timeline.length + ind
		}
		const excised = timeline.splice(0, Math.min(timeline.length - 1, ind))
		if (!excised.length) {
			return
		}
		/*
			We can freely change recent to be the *new* end of the timeline, because of the aforementioned
			prohibition of using this in past moments.
		*/
		recent = timeline.length - 1
		/*
			Flatten the excised moments onto the new first moment.
		*/
		const first = timeline[0]
		first.flatten(excised)
		/*
			Because flatten() won't put the final moment's "passage" into the pastVisits
			array yet (because "visits" only applies to past passages, as per (history:)) we must do it
			ourselves here.
		*/
		;(first.pastVisits ||= []).push(excised[excised.length-1].passage)
		/*
			"turns" is only ever increased by (forget-undos:), and represents erased turns that must
			nonetheless be counted by the turns identifier. Here, each excised turn increments the counter.
		*/
		first.turns = (first.turns || 0) + excised.length
		/*
			Rather than reconstruct the entire Current based on the above change,
			it's simpler to just update its own "turns" in kind.
		*/
		Current.turns = (Current.turns || 0) + excised.length
		/*
			If the first moment (that is, the only moment that cannot be undone past)
			has a forgetVisits number, erase all of the specified visits before it.
			Because all other moments can still be undone, their erased visits can't actually be erased yet.
		*/
		if (first.forgetVisits) {
			first.pastVisits = first.pastVisits.slice(first.forgetVisits - first.turns)
			/*
				Modify the forgetVisits number of this turn, now that (some of) the given visits are permanently erased,
				so that history() doesn't "erase" them again.
			*/
			first.forgetVisits -= first.turns
		}
	
		serialisedPast = ``
		/*
			This handler updates all (link-undo:) and (icon-undo:) links
			whenever the *entire* past has been erased.
		*/
		if (recent === 0) {
			$(`tw-link[undo], tw-icon[alt='Undo']`, storyElement).each((_, link) => {
				($(link).closest(`tw-expression, tw-hook`).data(`forgetUndosEvent`) || Object)(link)
			})
		}
		
		// Call the 'forgetUndos' event handler.
		eventHandlers.forgetUndos.forEach(fn => fn())
	},

	forgetVisits(ind:number) {
		if (ind < 0) {
			ind = timeline.length + ind
		}
		/*
			You can't erase visits from the turns after the current turn.
		*/
		if (ind > recent + (Current.turns || 0)) {
			ind = recent + (Current.turns || 0)
		}
		present.forgetVisits = Current.forgetVisits = Math.max(Current.forgetVisits || 0, ind)
		Current.reconstructHistory()
	},

	/*
		Did we ever visit this passage, given its name?
		Return the number of times visited.
	*/
	passageNameVisited(name:string) {
		let ret = 0

		if (!Passages.get(name)) {
			return 0
		}
		for (let i = 0; i < Current.history.length; i++) {
			ret += +(name === Current.history[i])
		}

		return ret
	},

	/*
		Direct access to the timeline. Used nowhere except for populating the Debug UI.
	*/
	timeline,
	/*
		Direct access to the definitions. Used only by (define:).
	*/
	definitions,

	/*
		Movers/shakers
	*/

	/*
		Push the present state to the timeline, and create a new state.
	*/
	play(newPassageName:string) {
		assert(present, `present is undefined!`)
		// Call the 'beforeForward' event handler. This doesn't take the passage name,
		// as it's intended for direction-agnostic events.
		eventHandlers.beforeForward.forEach(fn => fn())

		// Push the soon-to-be past passage name into the cache.
		if (present.passage) {
			/*
				If redirects were performed this turn, place the soon-to-be past passage name into the subarray holding those redirects.
			*/
			if (present.visits?.length && Array.isArray(Current.pastVisits) && Array.isArray(Current.pastVisits[Current.pastVisits.length-1])) {
				(<string[]>Current.pastVisits[Current.pastVisits.length-1]).push(present.passage)
			}
			else {
				/*
					Otherwise, just put the string at the end of the visits array.
				*/
				(Current.pastVisits ||= []).push(present.passage)
			}
			/*
				Also update the history cache, which is essentially a flattened version of pastVisits.
			*/
			(Current.history ||= []).push(present.passage)
		}
		// Assign the passage name.
		present.passage = newPassageName

		// Clear the future, and add the present to the timeline.
		timeline = timeline.slice(0,recent+1).concat(present)
		recent += 1
		
		// Create a new present
		newPresent(newPassageName)
		// Call the 'forward' event handler with this passage name.
		eventHandlers.forward.forEach(fn => fn(newPassageName))
	},

	/*
		Push the present state to the timeline, and create a new state.
	*/
	redirect(newPassageName:string) {
		assert(present, `present is undefined!`)
		// The departing passage name still goes into the cache.
		if (present.passage) {
			/*
				If previous redirects were performed this turn, place the soon-to-be past passage name into the subarray holding those redirects.
			*/
			if (present.visits?.length && Array.isArray(Current.pastVisits) && Array.isArray(Current.pastVisits[Current.pastVisits.length-1])) {
				(<string[]>Current.pastVisits[Current.pastVisits.length-1]).push(present.passage)
			}
			else {
				/*
					Otherwise, create a new sub-array.
				*/
				(Current.pastVisits ||= []).push([present.passage])
			}
			/*
				Also update the history cache, which is essentially a flattened version of pastVisits.
			*/
			(Current.history ||= []).push(present.passage)
		}
		/*
			Each moment stores the passages visited by (redirect:)s that occured during it,
			solely for the sake of (history:). Note that this must be done AFTER the above, due to the present.visits?.length check.
		*/
		(present.visits ||= []).push(newPassageName)

		// Assign the passage name.
		present.passage = newPassageName
	},

	/*
		Rewind the state. This will fail and return false if the player is at the first moment.
	*/
	rewind(steps = 1) {
		let moved = false

		for (; steps > 0 && recent > 0; steps--) {
			moved = true
			recent -= 1
		}
		if (moved) {
			// Call the 'beforeBack' event handler.
			eventHandlers.beforeBack.forEach(fn => fn())

			serialisedPast = ``

			newPresent(timeline[recent].passage)
			/*
				Recompute the present variables based on the timeline.
			*/
			Current.reconstruct(timeline.slice(0, recent + 1))
			// Call the 'back' event handler.
			eventHandlers.back.forEach(fn => fn())
		}
		return moved
	},

	/*
		Undo the rewinding of a state. Fails if no moments are in the future to be redone.
		Currently only accepts numbers.
		
		@param {Number} The number of turns to move forward.
		@return {Boolean} Whether the fast-forward was actually performed.
	*/
	fastForward(steps = 1) {
		let moved = false
		for (; steps > 0 && timeline.length > 0; steps--) {
			moved = true
			recent += 1
		}
		if (moved) {
			eventHandlers.beforeForward.forEach(fn => fn())

			newPresent(timeline[recent].passage)
			/*
				Recompute the present variables based on the timeline.
			*/
			Current.reconstruct(timeline.slice(0, recent + 1))
			/*
				Call the 'fast forward' event handler. This is used exclusively by debug mode,
				which is why it has the "fastForward" direction string passed in.
			*/
			eventHandlers.forward.forEach(fn => fn(timeline[recent].passage, `fastForward`))
		}
		return moved
	},

	/*
		This is used only by Debug Mode - it lets event handlers be registered and called when the State changes.
		"forward" functions have the signature (passageName, isFastForward). "back" functions have no signature.
		"load" functions have the signature (timeline), where timeline is the entire timeline Moments array.
	*/
	on(name: keyof typeof eventHandlers, fn: VoidFunction) {
		if (typeof fn === `function` && !eventHandlers[name].includes(fn)) {
			eventHandlers[name].push(fn)
		}
		return State
	},

	/*
		This method is only for Harlowe debugging purposes. It is called nowhere except for the test specs
		and the documentation's live preview feature.
	*/
	reset() {
		eventHandlers.beforeLoad.forEach(fn => fn())
		timeline = []
		recent = -1
		Current.reconstruct()
		present = new Moment()
		// This slightly hamfisted approach to resetting the definitions saves on having to implement a method for it
		// that would only be used by this method.
		Object.keys(definitions.variableStore).forEach(e => delete definitions.variableStore[e])
		setPRNG()
		present.seed = seed
		present.seedIter = 0
		serialisedPast = ``
		eventHandlers.load.forEach(fn => fn(timeline))
	},

	hasStorage: hasStorage[0],
	hasSessionStorage: hasStorage[1],

	/*
		A way to set the RNG seed.
		The new seed and seedIter is stored as a hidden variable in present.variables.
	*/
	setSeed(seed:string) {
		setPRNG(seed)
		present.seed = seed
		present.seedIter = 0
	},

	/*
		A way to call the current PRNG, while also storing the changed seedIter
		as a hidden variable in present.variables.
	*/
	random: () => {
		const ret = PRNG()
		present.seedIter = seedIter
		return ret
	},

	/*
		The following is an in-place Fisher–Yates shuffle.
		Used only in data structure macros and value macros.
	*/
	shuffled<T>(...list: T[]) {
		const ret = list.reduce((a:T[], e, ind) => {
			// Obtain a random number from 0 to ind inclusive.
			const j = (this.random()*(ind+1)) | 0
			if (j === ind) {
				a.push(e)
			}
			else {
				a.push(a[j])
				a[j] = e
			}
			return a
		},[])
		present.seedIter = seedIter
		return ret
	},

	/*
		Populates the Current moment's variables with State.defintions, without calling Current.reconstruct() in full.
		Used only by Harlowe.ts, immediately after calling Passages.
	*/
	addDefinitions() {
		Current.variables.flatten([definitions])
	},

	/*
		Serialise the game history, from the present backward (ignoring the redo cache)
		into a JSON string.
		
		Returns The serialised state (in two strings), or two empty strings if serialisation failed.
	*/
	serialise(newPresent:boolean) {
		let
			/*
				- If serialisedPast isn't set yet, serialise everything up to the present.
				- At the start of each turn (i.e newPresent == true), serialise the recently finished moment,
				and the new moment.
				- During a turn (i.e. (save-game:) or whatever),
				serialise only the current moment (assume serialisedPast is up to date).
			*/
			whatToSerialise = timeline.slice(!serialisedPast ? 0 : newPresent ? recent-1 : recent, recent+1)

		let pastToSerialise = whatToSerialise.slice(0, -1)
		let updatedPast = serialisedPast
		try {
			/*
				If there's no extra pastToSerialise, serialisedPast doesn't need to be updated.
			*/
			if (pastToSerialise.length) {
				/*
					The amount of ] marks that must be repeatedly sliced off with .slice(0,-1) and .slice(1) to
					concatenate these JSON serialised arrays together is very #awkward.
				*/
				updatedPast = (!updatedPast ? `[` : `${updatedPast.slice(0, -1)},`) + JSON.stringify(pastToSerialise.map(e => e.serialise())).slice(1)
			}
			return {
				past: updatedPast,
				pastAndPresent: `${updatedPast.slice(0, -1) + (updatedPast ? `,` : `[`) + JSON.stringify(whatToSerialise.at(-1)!.serialise())}]`,
			}
		}
		catch(e) {
			return { past: ``, pastAndPresent: `` }
		}
	},
	/*
		Deserialise the string and replace the current history.
		Since an error with save data isn't necessarily an author error, the errors returned
		by this function aren't TwineErrors.
	*/
	deserialise(section:Section, str:string) {
		let timelineJSON: MomentSerialised[]
		
		try {
			timelineJSON = JSON.parse(str)
		}
		catch(e) {
			throw new LoadGameError(`The save data is unintelligible.`)
		}
		/*
			Verify that the timeline is an array.
		*/
		if (!isArray(timelineJSON)) {
			throw new LoadGameError(`The save data isn't a sequence of past turns.`)
		}
		
		let reconstructedMoments: Moment[] = []
		for(let i = 0; i < timelineJSON.length; i += 1) {
			reconstructedMoments.push(Moment.deserialise(timelineJSON[i], reconstructedMoments, section))
		}
		timeline = reconstructedMoments
		recent = timeline.length - 1
		eventHandlers.load.forEach(fn => fn(timeline))
		serialisedPast = ``
		Current.reconstruct(timeline.slice(0, recent + 1))
		newPresent(timeline[recent].passage)
		return true
	}
}

/*
	This enables session storage to preserve the game state across reloads, even when the browser
	(such as that of a phone) doesn't naturally preserve it using something like FF's bfcache.
*/
function saveSession(serialisation:string) {
	if (State.hasSessionStorage) {
		/*
			Since we're in the middle of navigating to another Moment, just silently disregard errors.
		*/
		try {
			sessionStorage.setItem(`Saved Session`, serialisation)
		} catch(e) {
			// Again, silently disregard errors.
			return
		}
	}
}

/*
	A private method to create a new present after altering the state.
	@param {String} The name of the passage the player is now currently at.
*/
function newPresent(newPassageName:string) {
	present = new Moment(newPassageName)

	/*
		Update the serialisedPast cache, so that the moment that used to be
		the present is included in it. This is how serialisedPast is incrementally
		increased as the game progresses.
	*/
	let pastAndPresent
	;({past:serialisedPast, pastAndPresent} = State.serialise(true))

	saveSession(pastAndPresent)
}

Object.seal(Moment)
export default State
