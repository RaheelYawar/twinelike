
/*
	This generates the 3.3.8 docs, except with the 4.0 changelog included.
*/
import fs from 'fs'
import metadata from './metadata.js'
let changeLog = ''
changeLog += `\n<h1 id=section_${metadata.Changes.defCode}>${metadata.Changes.defName}</h1>\n`;
changeLog += metadata.Changes.output()[0];
/*
	Convert to HTML with Marked
*/
changeLog = (await import('marked')).default(changeLog);
let outputFile = (''+fs.readFileSync('./harlowe3Docs.html'))
	.replace("{{CHANGELOG}}", changeLog)
	.replace("{{UNSTABLE}}", new Date().getFullYear()+"-"+("0"+(new Date().getMonth()+1)).slice(0,2)+"-"+("0"+new Date().getDate()).slice(1,3))
fs.writeFileSync("dist/index.html", outputFile);
