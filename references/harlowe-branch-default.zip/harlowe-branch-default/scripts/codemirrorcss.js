
import { CSS } from '../ts/utils/typecolours.js'
import { execSync } from 'child_process'

/*
	This is used by any Harlowe build product that has a CodeMirror syntax highlighter in it.
*/
const versionClass = 'cm-harlowe-4-';
const toolbarStyles = (execSync('sass ./scripts/toolbar.css --style compressed') + '').replace(/\ufeff/,''),
	animations = (execSync('sass ./scss/animations.scss --style compressed') + '').replace(/\ufeff/,'').replace(/@keyframes /g, "@keyframes harlowe-4-");

export default
		// The cursor token highlight should ignore the most common tokens, unwrapped text tokens, as well as verbatim tokens.
		`.${versionClass}cursor:not([class^='${versionClass}verbatim']):not([class^='${versionClass}text ${versionClass}root']) { border-bottom: 2px solid darkgray; }` +

		`.${versionClass}findResult { background-color: hsla(280,100%,70%,0.4) !important; } .${versionClass}findResultCurrent { background-color: hsla(320,100%,70%,0.6) !important; }` +

		// Visible tabs
		`.${versionClass}root .cm-tab { text-decoration: line-through dotted #888; border-right: dotted 1px #888; }` +
		
		".CodeMirror {padding: 0 !important}" +
		// The line number bullets (see the lineNumbers option, above), are a bit too dark by default.
		".CodeMirror-linenumber {color: hsla(0,0%,80%,1.0);}" +
		// Also, the gutters sometimes encroach on the text area for some reason.
		".CodeMirror-gutters {left: 0px !important;}" + CSS + animations + toolbarStyles;
