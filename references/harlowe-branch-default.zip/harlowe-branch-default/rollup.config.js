import commonjs from '@rollup/plugin-commonjs'
import nodeResolve from '@rollup/plugin-node-resolve'
import terser from '@rollup/plugin-terser'
import typescript from '@rollup/plugin-typescript'

export default {
	input: 'ts/harlowe.ts',
	output: {
		file: 'build/harlowe-min.js',
		format: 'iife',
		compact: true,
		sourcemap: true,
	},
	plugins: [
		nodeResolve({ preferBuiltins: false }),
		terser({
			ecma: 2023
		}),
		commonjs(),
		typescript(),
	],
	onwarn(warning, rollupWarn) {
		if (warning.code !== 'CIRCULAR_DEPENDENCY') {
			rollupWarn(warning);
		}
	}
}
