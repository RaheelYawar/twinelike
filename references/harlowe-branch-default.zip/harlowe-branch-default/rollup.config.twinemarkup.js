import terser from '@rollup/plugin-terser'
import Metadata from "./scripts/metadata.js"
import CodeMirrorCSS from "./scripts/codemirrorcss.js"
import typescript from '@rollup/plugin-typescript'

export default {
	input: `ts/markup/codemirror/mode.ts`,
	/*
		Go to stdout
	*/
	context: 'this',
	plugins: [
		terser({
			ecma: 2023,
			keep_fnames: true
		}),
		typescript({ tsconfig: 'ts/markup/codemirror/tsconfig.json' }),
		{
			name: 'shortdefs',
			/*
				Convert the `SHORTDEFS` object to a compilation of the actual ShortDefs,
				and convert the `CODEMIRRORCSS` string to a compilation of the actual CodeMirror mode CSS.
				For speed, these are keyed to specific files.
			*/
			transform(code,id) {
				return id.endsWith('utils.ts')
					? code.replace("/*SHORTDEFS*/ {}", JSON.stringify(Object.entries(Metadata).reduce((a, [k,v]) => Object.assign(a, v.shortDefs ? {[k]: v.shortDefs()} : {}), {})))
					: id.endsWith('mode.ts') ? code.replace("`CODEMIRRORCSS`", JSON.stringify(CodeMirrorCSS)) : code
			}
		}
	],
}
