Introduction 2: Unstable 4.0 builds now available!

By popular demand: you can now access the latest **in-progress** build of Harlowe 4.0, for your own personal use as an installable story format in Twine. Be warned that Harlowe 4 has *intentional incompatibility* with Harlowe 3 code, Harlowe 3 CSS, and Harlowe 3 browser support, and that all use of these builds is entirely without warranty! Please scrutinise the <a href="#section_changes">change log</a> to fully understand what changes Harlowe 4 brings.

<a href="harlowe4-unstable.js" style="font-size:110%;font-style:bold">Click here to get the unstable build (last updated {{UNSTABLE}})</a>

Unstable builds are updated *at least within a week of all new developments*.
