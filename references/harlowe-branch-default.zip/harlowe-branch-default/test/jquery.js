import "../node_modules/jquery/dist/jquery.min.js"
export default jQuery.noConflict(true)