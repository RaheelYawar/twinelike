describe(`live macros`, () => {
	'use strict'

	// TODO: Add (live:) macro tests
	describe(`the (event:) macro`, () => {
		it(`requires a 'when' lambda`, () => {
			expect(`(event:)[]`).markupToError()
			expect(`(event:1)[]`).markupToError()
			expect(`(event: each _a,2)[]`).markupToError()
			expect(`(event:_a via true,2)[]`).markupToError()
			expect(`(event:_a making _b where true,2)[]`).markupToError()
			expect(`(event: when $a > 2)[]`).not.markupToError()
		})
		it(`errors when placed in passage prose while not attached to a hook`, () => {
			expect(`(event: when $a > 2)`).markupToError()
		})
		it(`doesn't immediately display the hook`, (done) => {
			let p = runPassage(`(event:when $a is 2)[baz]`)
			setTimeout(() => {
				expect(p.text()).not.toBe(`baz`)
				done()
			},20)
		})
		it(`displays the attached hook only when the lambda's condition becomes true`, (done) => {
			let p = runPassage(`(event: when $a is 2)[bar](link:'foo')[(set:$a to 2)]`)
			expect(p.text()).toBe(`foo`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				expect(p.text()).toBe(`bar`)
				done()
			},20)
		})
		it(`works with temp variables in the hook`, (done) => {
			let p = runPassage(`(link:'foo')[(set:$a to 2, _b to 'bar')](event: when $a is 2)[_b]`)
			expect(p.text()).toBe(`foo`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				expect(p.text()).toBe(`bar`)
				done()
			},20)
		})
		it(`works with temp variables in the lambda`, (done) => {
			let p = runPassage(`(event: when _a is 2)[bar](link:'foo')[(set:_a to 2)]`)
			expect(p.text()).toBe(`foo`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				expect(p.text()).toBe(`bar`)
				done()
			},20)
		})
		it(`works with style changers`, (done) => {
			let p = runPassage(`(text-color:'#fadaba')+(event: when $a is 2)[Wow](link:'foo')[(set:$a to 2)]`)
			expect(p.text()).toBe(`foo`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				expect(p.find(`tw-hook`)).toHaveColour(`#fadaba`)
				done()
			},20)
		})
		it(`works with (transition:)`, (done) => {
			let p = runPassage(`(t8n:'pulse')+(t8n-time:12s)+(event: when $a is 2)[Wow](link:'foo')[(set:$a to 2)]`)
			expect(p.text()).toBe(`foo`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				expect($(`tw-story .transition-in[data-t8n="pulse"]`).length).toBe(1)
				done()
			},20)
		})
		it(`currently can't attach to bare commands`, () => {
			expect(`(event: when $a is 2)(print:$a)(link:'foo')[(set:$a to 2)]`).markupToError()
		})
		it(`only renders the hook once`, (done) => {
			let p = runPassage(`(set:$b to 'qux')(event: when $a is 2)[(set:$a to 0)$b](link:'foo')[(set:$a to 2)(link:'bar')[(set:$b to 'baz')(set:$a to 2)quux]]`)
			expect(p.text()).toBe(`foo`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				p.find(`tw-link`).click()
				setTimeout(() => {
					expect(p.text()).toBe(`quxquux`)
					done()
				},20)
			},20)
		})
	})
	describe(`the (after:) macro`, () => {
		it(`requires a positive number, and an optional non-negative number`, () => {
			expect(`(after:)[]`).markupToError()
			expect(`(after:1)[]`).not.markupToError()
			expect(`(after:1,1)[]`).not.markupToError()
			expect(`(after:0)[]`).markupToError()
			expect(`(after:1,-0.1)[]`).markupToError()
		})
		it(`doesn't immediately display the hook`, (done) => {
			let p = runPassage(`(after: 12s)[baz]`)
			setTimeout(() => {
				expect(p.text()).not.toBe(`baz`)
				done()
			},20)
		})
		it(`displays the attached hook only when the given time has elapsed`, (done) => {
			let p = runPassage(`(after:30ms)[bar]`)
			expect(p.text()).toBe(``)
			setTimeout(() => {
				expect(p.text()).toBe(`bar`)
				done()
			},
			// Because Firefox randomly permutes setTimeout's timeout to avoid fingerprinting, the time has to be this generous.
			80)
		})
	})
	describe(`the (after-error:) macro`, () => {
		it(`takes no values`, () => {
			expect(`(after-error:)[]`).not.markupToError()
			expect(`(after-error:1)[]`).markupToError()
			expect(`(after-error:1,1)[]`).markupToError()
		})
		it(`doesn't immediately display the hook`, (done) => {
			let p = runPassage(`(after-error:)[baz]`)
			setTimeout(() => {
				expect(p.text()).not.toBe(`baz`)
				done()
			},20)
		})
		it(`displays the attached hook only when an error occurs elsewhere`, (done) => {
			let p = runPassage(`(after-error:)[bar](link:'Yo')[(primt:2)]`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				expect(p.find(`tw-hook:first-of-type`).text()).toBe(`bar`)
				done()
			},
			// Because Firefox randomly permutes setTimeout's timeout to avoid fingerprinting, the time has to be this generous.
			80)
		})
	})
	describe(`the (more:) macro`, () => {
		it(`takes no arguments`, () => {
			expect(`(more:)[]`).not.markupToError()
			expect(`(more:when visits is 2)[]`).markupToError()
		})
		it(`errors when placed in passage prose while not attached to a hook`, () => {
			expect(`(more:)`).markupToError()
		});
		[[`link`,`(link-reveal:"foo")`,`tw-link`,`click`],
		[`(link-show:)`,`(link-show:"foo",?bar)`,`tw-link`,`click`],
		[`passage link`, `(link-reveal:"f")[(replace:?a)[oo]][[[oo->test]]]<a|`,`tw-link`,`click`],
		[`click enchantment`,`foo(click:"foo")`,`tw-enchantment`,`click`],
		[`mouseover enchantment`,`foo(mouseover:"foo")`, `tw-enchantment`, `mouseover`]].forEach((e) => {
			let name = e[0], code = e[1], el = e[2], event = e[3]
			it(`doesn't immediately display the hook if ${  name  }s are in the passage`, (done) => {
				let p = runPassage(`${code}[](more:)[bar]`)
				setTimeout(() => {
					expect(p.text()).toBe(`foo`)
					done()
				},20)
			})
			it(`displays the hook once all ${  name  }s are gone`, (done) => {
				let p = runPassage(`${code}[](more:)[bar]`)
				expect(p.text()).toBe(`foo`)
				p.find(el).first()[event]()
				setTimeout(() => {
					expect(p.text()).toBe(`foobar`)
					done()
				},20)
			})
		})
		it(`multiple (more:) hooks will appear in order and may block one another`, (done) => {
			let p = runPassage(`(link:'foo')[](more:)[qux](more:)[(link:'bar')[]]`)
			p.find(`tw-link`).click()
			setTimeout(() => {
				expect(p.text()).toBe(`quxbar`)
				
				p = runPassage(`(link:'foo')[](more:)[(link:'bar')[]](more:)[qux]`)
				p.find(`tw-link`).click()
				setTimeout(() => {
					expect(p.text()).toBe(`bar`)
					done()
				},20)
			},20)
		})
	})
})
