describe(`identifiers`, () => {
	'use strict'
	describe(`the 'it' identifier`, () => {
		it(`refers to the left side of a recent comparison`, () =>{
			expect(`(set:$red to 3)(print: $red > 2 and it < 4)`).markupToPrint(`true`)
			expect(`(set:$red to 3)(set:$blue to 6)(print: $red > 2 and $blue > 2 and it > 4)`).markupToPrint(`true`)
			expect(`(set:$red to 'egg')(print: $red contains 'g' and it contains 'e')`).markupToPrint(`true`)
			expect(`(set:$red to 'egg')(set:$blue to 'g')(print: $blue is in $red and it is in 'go')`).markupToPrint(`true`)
		})
		it(`is case-insensitive`, () =>{
			expect(`(set:$red to 'Bee')(set:$red to IT + 's')(set:$red to iT + '!')$red`).markupToPrint(`Bees!`)
		})
		it(`also refers to the left side of a 'to' operation`, () =>{
			expect(`(set:$red to 'Bee')(set:$red to it + 's')$red`).markupToPrint(`Bees`)
		})
		it(`can be used in sub-expressions`, () =>{
			expect(`(put:'Bee' into $red)(set: $red to (substring: it, 2, 3))$red`).markupToPrint(`ee`)
		})
		it(`can't be used in an 'into' operation`, () =>{
			expect(`(put:'Bee' into $red)(put:$red + 's' into it)`).markupToError()
		})
		it(`can't be used as the subject of a 'to' operation`, () =>{
			expect(`(set:$red to 1)(set:it to it + 2)`).markupToError()
		})
		it(`also refers to the variable of a 'where' lambda`, () => {
			expect(`(find: _a where it > 2, 1, 3, 6, 1)`).markupToPrint(`3,6`)
			expect(`(altered: _a via it + 1, 2,5)`).markupToPrint(`3,6`)
		})
		it(`can be used in a lambda when the variable name is missing`, () => {
			expect(`(find: where it > 2, 1, 3, 6, 1)`).markupToPrint(`3,6`)
			expect(`(altered: via it + 1, 2,5)`).markupToPrint(`3,6`)
		})
	})
	describe(`implicit 'it'`, () => {
		it(`is added for incomplete comparisons`, () =>{
			expect(`(set:$red to 3)(print: $red > 2 and < 4)`).markupToPrint(`true`)
			expect(`(set:$red to 'egg')(print: $red contains 'g' and contains 'e')`).markupToPrint(`true`)
			expect(`(set:$red to 'egg')(set:$blue to 'g')(print: $blue is in $red and is in 'go')`).markupToPrint(`true`)
		})
	})
	describe(`the 'its' property access syntax`, () => {
		it(`accesses properties from the left side of a recent comparison`, () =>{
			expect(`(set:$red to 'egg')(print: $red is 'egg' and its length is 3)`).markupToPrint(`true`)
		})
		it(`is case-insensitive`, () =>{
			expect(`(set:$red to 'egg')(print: $red is 'egg' and iTS length is 3)`).markupToPrint(`true`)
		})
		it(`also accesses properties from the left side of a 'to' operation`, () =>{
			expect(`(set:$red to 'Bee')(set:$red to its 1st)$red`).markupToPrint(`B`)
		})
		it(`can have properties accessed from it`, () =>{
			expect(`(set:$red to (a:'Bee'))(set:$red to its 1st's 1st)$red`).markupToPrint(`B`)
		})
		it(`also works as "it's"`, () =>{
			expect(`(set:$red to 'egg')(print: $red is 'egg' and it's length is 3)`).markupToPrint(`true`)
			expect(`(set:$red to 'egg')(print: $red is 'egg' and iT'S length is 3)`).markupToPrint(`true`)
		})
	})
	describe(`the computed 'its' property access syntax`, () => {
		it(`accesses properties from the left side of a recent comparison`, () =>{
			expect(`(set:$red to 'egg')(print: $red is 'egg' and its ('length') is 3)`).markupToPrint(`true`)
		})
		it(`also accesses properties from the left side of a 'to' operation`, () =>{
			expect(`(set:$red to 'Bee')(set:$red to its (1))$red`).markupToPrint(`B`)
		})
		it(`can have properties accessed from it`, () =>{
			expect(`(set:$red to (a:'Bee'))(set:$red to its (1)'s 1st)$red`).markupToPrint(`B`)
			expect(`(set:$red to (a:'Bee'))(set:$red to its (1)'s (1))$red`).markupToPrint(`B`)
		})
	})
	describe(`the 'time' identifier`, () => {
		it(`refers to the elapsed milliseconds since the passage was rendered`, () =>{
			expect(`(print:time <= 20)`).markupToPrint(`true`)
			expect(`(set:$red to time)$red`).not.markupToError()
		})
		it(`works inside deferred hooks`, (done) =>{
			let p = runPassage(`(link:'Z')[(print: time >= 200 and time <= 300)]`)
			setTimeout(() => {
				p.find(`tw-link`).click()
				setTimeout(() => {
					expect(p.text()).toBe(`true`)
					done()
				})
			}, 200)
		})
		it(`works inside displayed passages`, (done) =>{
			createPassage(`(print:time >= 200 and time <= 300)`, `grault`)
			let p = runPassage(`(link:'Z')[(display:'grault')]`)
			setTimeout(() => {
				p.find(`tw-link`).click()
				setTimeout(() => {
					expect(p.text()).toBe(`true`)
					done()
				})
			}, 200)
		})
		it(`is case-insensitive`, () =>{
			expect(`(print: tIME)(print: timE)(print: tImE)`).not.markupToError()
		})
		it(`can't be used in an 'into' operation`, () =>{
			expect(`(put:2 into $red)(put:$red into time)`).markupToError()
		})
		it(`can't be used as the subject of a 'to' operation`, () =>{
			expect(`(set:time to 2)`).markupToError()
		})
		it(`isn't recognised inside 'exit'`, () =>{
			expect(`(print:exit)`).not.markupToError()
		})
	})
	describe(`the 'turns' identifier`, () => {
		it(`refers to the number of turns that have elapsed`, (done) =>{
			[`foo`,`bar`,`baz`,`foo`,`bar`,`foo`,`baz`].forEach((e) => {
				runPassage(``, e)
			})
			expect(runPassage(`(print: turns)`, `qux`).find(`tw-expression`).text()).toBe(`8`)
			expect(`(print: turns + 1)`).markupToPrint(`10`)
			Engine.goBack()
			setTimeout(() =>{
				expect($(`tw-passage tw-expression`).text()).toBe(`8`)
				done()
			},80)
		})
		it(`is case-insensitive`, () => {
			expect(`(print: tuRNS)(print: TURNS)(print: TuRNs)`).not.markupToError()
		})
		it(`can also be written as 'turn'`, () => {
			expect(`(print: turn)(print: TURN)(print: tuRn)`).not.markupToError()
			expect(`(print: turn is 2)`).markupToPrint(`true`)
		})
		it(`can't be used as the subject in an 'into' or 'to' operation`, () => {
			expect(`(put: 2 into turns)`).markupToError()
			expect(`(set: turns to 2)`).markupToError()
		})
	})
	describe(`the 'visits' identifier`, () => {
		it(`refers to the number of times this passage was visited, including the current time`, () =>{
			[`foo`,`bar`,`baz`,`foo`,`bar`,`foo`,`baz`].forEach((e) => {
				runPassage(``, e)
			})
			expect(runPassage(`(print: visits)`,`foo`).text()).markupToPrint(`4`)
			expect(runPassage(`(print: visits + 1)`,`baz`).text()).markupToPrint(`4`)
			expect(runPassage(`(print: visits is 1)`,`qux`).text()).markupToPrint(`true`)
		})
		it(`works inside displayed passages, but only refers to the outer passage`, () => {
			createPassage(`(print:visits)`, `grault`)
			goToPassage(`grault`)
			goToPassage(`grault`)
			goToPassage(`grault`)
			expect(`(display:'grault')`).markupToPrint(`1`)
		})
		it(`is case-insensitive`, () => {
			expect(`(print: viSiTs)(print: VISITs)(print: VISITs)`).not.markupToError()
		})
		it(`can also be written as 'visit'`, () => {
			expect(`(print: viSiT)(print: VISIT)(print: vISIT)`).not.markupToError()
			expect(runPassage(`(print: visit is 1)`,`qux`).text()).markupToPrint(`true`)
		})
		it(`can't be used as the subject in an 'into' or 'to' operation`, () => {
			expect(`(put: 2 into visits)`).markupToError()
			expect(`(set: visits to 2)`).markupToError()
		})
	})
	describe(`the 'exits' identifier`, () => {
		[[`link`,`(link-reveal:"foo")`],
		[`(link-show:)`,`(link-show:"foo",?bar)`],
		[`passage link`, `[[foo->grault]]`],
		[`click enchantment`,`foo(click:"foo")`,`foo1`],
		[`mouseover enchantment`,`foo(mouseover:"foo")`, `foo1`]].forEach((e) => {
			let name = e[0], code = e[1]
			it(`counts the number of ${  name  }s in the passage`, () => {
				createPassage(``, `grault`)
				expect(`${code}[](print:exits)`).markupToPrint(`foo1`)
				expect(`${code}[]${code.replace(/foo/g,`bar`)}[](print:exits)`).markupToPrint(`foobar2`)
				expect(`${code}[]${code.replace(/foo/g,`bar`)}[]${code.replace(/foo/g,`baz`)}[](print:exits)`).markupToPrint(`foobarbaz3`)
			})
		})
		it(`is case-insensitive`, () => {
			expect(`(print: exitS)(print: EXIts)(print: exITS)`).not.markupToError()
		})
		it(`can also be written as 'exit'`, () => {
			expect(`(print: EXit)(print: EXIT)(print: exit)`).not.markupToError()
			expect(runPassage(`[[qux]](print: exit is 1)`,`qux`).text()).markupToPrint(`quxtrue`)
		})
	})
	describe(`the 'pos' identifier`, () => {
		it(`can only appear in lambdas that aren't 'when' lambdas`, (done) => {
			expect(`(find:where pos is 2, 1)`).not.markupToError()
			expect(`(print:pos)`).markupToError()
			let p = runPassage(`(event:when pos is 2)[baz]`)
			setTimeout(() => {
				expect(p.find(`tw-error:not(.javascript)`).length).toBe(1)
				done()
			},20)
		})
		it(`equals the 1-indexed position of the data passed to the lambda`, () => {
			expect(`(altered:via pos,0,0,0,0,0,0)`).markupToPrint(`1,2,3,4,5,6`)
			expect(`(altered:_item via pos + _item,0,3,0,3,0,-3)`).markupToPrint(`1,5,3,7,5,3`)
		})
	})
	describe(`the 'user' identifier`, () => {
		it(`refers to a user preferences datamap with "width", "height", "orientation", "motion", "contrast" and "hover"`, () =>{
			expect(`(print: user is a datamap)`).markupToPrint(`true`)
			;[`width`,`height`,`orientation`,`motion`,`contrast`,`hover`].forEach((e) => {
				expect(`(print: "${e}" is in user)`).markupToPrint(`true`)
			})
			expect(`(print: (ds:...(datanames:user)) is (ds:"width","height","orientation","motion","contrast","hover"))`).markupToPrint(`true`)
		})
		it(`width and height are the innerWidth and innerHeight`, () => {
			expect(`(print: user's width is a number)`).markupToPrint(`true`)
			expect(`(set:$a to 0)<script>$a = innerWidth</script>(print: user's width is $a)`).markupToPrint(`true`)
			expect(`(set:$a to 0)<script>$a = innerHeight</script>(print: user's height is $a)`).markupToPrint(`true`)
		})
		/*
			These can't really be tested properly because their implementation (in section.ts) would just be reproduced here...
		*/
		it(`orientation is either "portrait" or "landscape"`, () => {
			expect(`(print: user's orientation is "portrait" or "landscape")`).markupToPrint(`true`)
		})
		it(`hover is a boolean`, () => {
			expect(`(print: user's hover is a boolean)`).markupToPrint(`true`)
		})
		it(`motion is "any" or "reduced"`, () => {
			expect(`(print: user's motion is "any" or "reduced")`).markupToPrint(`true`)
		})
		it(`contrast is "any", "less" or "more"`, () => {
			expect(`(print: user's motion is "any" or "less" or "more")`).markupToPrint(`true`)
		})
	})
})
