describe(`debugging macros`, () => {
	'use strict'
	beforeEach(() => {
		Utils.options.debug = true
	})
	afterEach(() => {
		Utils.options.debug = false
	})
	describe(`the (mock-visits:) macro`, () => {
		beforeEach(() => {
			let t = `(print:visits)`
			createPassage(t, `grault`)
			createPassage(t, `garply`)
			createPassage(t, `qux`)
		})
		it(`takes any number of passage name strings`, () => {
			expect(`(mock-visits:)`).markupToError()
			expect(`(mock-visits:'bar')`).markupToError()
			expect(`(mock-visits:'bar','baz')`).markupToError()
			expect(`(mock-visits:'qux')`).not.markupToError()
			expect(`(mock-visits:'qux','bar')`).markupToError()
			expect(`(mock-visits:'qux','qux','qux')`).not.markupToError()
			expect(`(mock-visits:'qux','garply','grault','grault')`).not.markupToError()
			expect(`(mock-visits:'qux','garply','grault','foo')`).markupToError()
		})
		// Can't test that it only works in debug mode, unfortunately.
		it(`alters the 'visits' keyword to mock visits to each of the given passages`, () => {
			runPassage(`(mock-visits:'qux','qux','qux','grault')`)
			let p = goToPassage(`qux`)
			expect(p.text()).toBe(`4`)
			p = goToPassage(`garply`)
			expect(p.text()).toBe(`1`)
			p = goToPassage(`grault`)
			expect(p.text()).toBe(`2`)
		})
		it(`each successive (mock-visits:) call overrides the last`, () => {
			runPassage(`(mock-visits:'qux','qux','qux','grault')`)
			let p = goToPassage(`qux`)
			expect(p.text()).toBe(`4`)
			runPassage(`(mock-visits:'garply')`)
			p = goToPassage(`garply`)
			expect(p.text()).toBe(`2`)
			Engine.goBack()
			Engine.goBack()
			expect($(`tw-passage > :last-child`).text()).toBe(`4`)
		})
		it(`alters the (history:) macro, adding its strings to the start`, () => {
			runPassage(`(mock-visits:'qux','qux','qux','grault')`)
			expect(`(history:)`).markupToPrint(`qux,qux,qux,grault,test`)
		})
		it(`alters the (visited:) macro`, () => {
			createPassage(`BEEP`,`grault`)
			createPassage(`BOOP`,`qux`)
			runPassage(`(mock-visits:'qux','qux','qux','grault')`)
			expect(`(print:(visited:"grault"))`).markupToPrint(`true`)
			expect(`(print:(visited:where its source is "BOOP"))`).markupToPrint(`true`)
		})
	})
	describe(`the (mock-turns:) macro`, () => {
		beforeEach(() => {
			runPassage(``)
			runPassage(``)
			runPassage(``)
		})
		it(`takes a non-negative integer`, () => {
			expect(`(mock-turns:)`).markupToError()
			expect(`(mock-turns:'bar')`).markupToError()
			expect(`(mock-turns:0.1)`).markupToError()
			expect(`(mock-turns:1)`).not.markupToError()
			expect(`(mock-turns:0)`).not.markupToError()
			expect(`(mock-turns:2,2)`).markupToError()
		})
		// Can't test that it only works in debug mode, unfortunately.
		it(`alters the 'turns' keyword to mock additional turns`, () => {
			runPassage(`(mock-turns:15)`)
			expect(`(print:turns)`).markupToPrint(`20`)
		})
		it(`each successive (mock-turns:) call overrides the last`, (done) => {
			expect(`(mock-turns:15)(print:turns)`).markupToPrint(`19`)
			expect(runPassage(`(mock-turns:1)(print:turns)`,`garply`).find(`:last-child`).text()).toBe(`6`)
			Engine.goBack()
			setTimeout(() =>{
				expect($(`tw-passage > :last-child`).text()).toBe(`19`)
				done()
			},80)
		})
	})
	describe(`the (assert:) macro`, () => {
		it(`takes a boolean`, () => {
			expect(`(assert:3<5)`).not.markupToError()
			expect(`(assert:6<8)`).not.markupToError()
			//expect(`(assert:)`).markupToError()
			//expect(`(assert:25)`).markupToError()
		})
		// TODO: Re-implement this.
		xit(`if given false, it produces an error that shows the call's source`, () => {
			expect(runPassage(`(assert:3<1)`).find(`tw-error`).text()).toContain(`(assert:3<1)`)
			expect(runPassage(`(assert:45)`).find(`tw-error`).text()).not.toContain(`(assert:45)`)
		})
	})
	describe(`the (assert-exists:) macro`, () => {
		it(`takes a string or hook name`, () => {
			expect(`(assert-exists:true)`).markupToError()
			expect(`(assert-exists:)`).markupToError()
			expect(`(assert-exists:25)`).markupToError()
			expect(`(assert-exists:?red)|red>[]`).not.markupToError()
			expect(`(assert-exists:'bess')bess`).not.markupToError()
		})
		it(`errors if the given hook does not exist in the passage`, () => {
			expect(`(assert-exists:?red)|red>[]`).not.markupToError()
			expect(`(assert-exists:'bess')bess`).not.markupToError()
		})
	})
	describe(`the (debug:) macro`, () => {
		beforeEach(() => {
			$(`tw-debugger`).detach()
			Utils.options.debug = false
		})
		afterAll(() => {
			if (!location.search.includes(`spec=`)) {
				Utils.options.debug = false
			}
		})

		it(`takes nothing`, () => {
			expect(`(debug:3)`).markupToError()
			expect(`(debug:)`).not.markupToError()
		})
		it(`produces a command that opens the debug mode panel`, () => {
			expect($(`tw-debugger`).length).toBe(0)
			expect(`(print:(Debug:) is a command)`).markupToPrint(`true`)
			runPassage(`(Debug:)`)
			expect($(`tw-debugger`).length).toBe(1)
		})
		it(`reopens the debug mode panel if debug mode is closed`, (done) => {
			expect($(`tw-debugger`).length).toBe(0)
			runPassage(`(Debug:)`)
			expect($(`tw-debugger`).length).toBe(1)
			$(`tw-debugger button.close`).click()
			setTimeout(() =>{
				expect($(`tw-debugger`).length).toBe(0)
				runPassage(`(Debug:)`)
				expect($(`tw-debugger`).length).toBe(1)
				done()
			},80)
		})
	})
})
