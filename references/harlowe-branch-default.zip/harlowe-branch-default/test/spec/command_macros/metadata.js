describe(`metadata macros`, () => {
	'use strict'
	describe(`the (storylet:) macro`, () => {
		afterEach(() => {
			clearState()
		})
		it(`accepts a 'when' lambda`, () => {
			expect(`(storylet:)`).markupToError()
			expect(`(storylet: each _a)`).markupToError()
			expect(`(storylet: when  true is true)`).not.markupToError()
			expect(`(storylet: where true is true)`).markupToError()
		})
		it(`displays nothing in passages when run`, () => {
			expect(`(storylet: when true is true)`).not.markupToError()
		})
		it(`cannot be printed or stored`, () => {
			expect(`(print: (storylet: when true is true))`).markupToError()
			expect(`(set: $a to (storylet: when true is true))`).markupToError()
		})
		it(`doesn't error when storylet macros are misused`, () => {
			expect(`(storylet: when $a is true)(storylet: when $c is true)`).not.markupToError()
			expect(`(if:true)[(storylet: when $a is true)]`).not.markupToError()
		})
		it(`errors at startup when a passage's (storylet:) appeared after a non-metadata macro`, () => {
			let errors
			errors = createPassage(`(set: $b to 1)(story-let: when $b is 1)`, `grault`)
			expect(errors.length).not.toBe(0)
			errors = createPassage(`(story-let: when $b is (a:))`, `grault`)
			expect(errors.length).toBe(0)
			errors = createPassage(`(set: $b to 1)(story-let: when $b is 1)`, `grault`)
			expect(errors.length).not.toBe(0)
		})
		it(`errors at startup when a passage has two or more (storylet:) calls`, () => {
			let errors = createPassage(`(storylet: when $a is true)(storylet: when $c is true)`, `grault`)
			expect(errors.length).not.toBe(0)
		})
		it(`errors at startup when a (storylet:) call overrides a (metadata:) call`, () => {
			let errors = createPassage(`(storylet: when $a is true)(metadata: 'storylet', when $c is true)`, `grault`)
			expect(errors.length).not.toBe(0)
		})
		it(`errors at startup when it causes an error`, () => {
			let errors
			errors = createPassage(`(storylet: where $a is true)`, `grault`)
			expect(errors.length).not.toBe(0)
		})
		it(`the lambda is accessible on the (passage:) datamap`, () => {
			createPassage(`(storylet: when true)`, `grault`)
			expect(`(source:(passages: where its name is 'grault')'s 1st's storylet)`).markupToPrint(`when true`)
		})
	})
	describe(`the (define:) macro`, () => {
		afterEach(() => {
			clearState()
		})
		it(`accepts one or more assignment requests using 'to'`, () => {
			expect(`(define:)`).markupToError()
			expect(`(define: 2)`).markupToError()
			expect(`(define: $a to 2)`).not.markupToError()
			expect(`(define: $a to 2, $b to "Red")`).not.markupToError()
			expect(`(define: $a to 2, "Red" into $b)`).markupToMetadataError()
			expect(`(define: 2 into $a)`).markupToMetadataError()
		})
		it(`errors if given temp variables`, () => {
			expect(`(define: _a to 2)`).markupToMetadataError()
		})
		it(`errors if given -type syntax other than const-type or any-type`, () => {
			expect(`(define: num-type $a to 2)`).markupToMetadataError()
			expect(`(define: str-type $b to '')`).markupToMetadataError()
			expect(`(define: const-type $c to 2)`).not.markupToMetadataError()
			expect(`(define: any-type $d to 2)`).not.markupToMetadataError()
		})
		it(`displays nothing in passages when run`, () => {
			expect(`HONEY(define: $a to 2)BEES`).markupToPrint(`HONEYBEES`)
		})
		it(`variables cannot be reassigned`, () => {
			expect(`(define: $a to 2, $b to 'RED', $y to (a:1), $z to (dm:'X',12,'Y',12))`).not.markupToMetadataError()
			expect(`(set: $a to 4)`).markupToError()
			expect(`(set: $z's 1st to 9)`).markupToError()
			expect(`(set: $y's 1st to 9)`).markupToError()
			expect(`(put: 5 into $a)`).markupToError()
			expect(`(unpack: (a:1) into (a:$a))`).markupToError()
			expect(`(seq-link: bind $b, 'RED', 'BLUE')`).markupToError()
			expect(`(seq-link: 2bind $b, 'RED', 'BLUE')`).markupToError()
		})
	})
	describe(`the (link-storylet:) macro`, () => {
		it(`accepts optional link text, plus a non-zero whole number or a 'where' lambda, plus optional unavailable text`, () => {
			expect(`(link-storylet: 'ears')`).markupToError()
			expect(`(link-storylet:)`).markupToError()
			expect(`(link-storylet: 0)`).markupToError()
			expect(`(link-storylet: 2.1)`).markupToError()
			expect(`(link-storylet: 2)`).not.markupToError()
			expect(`(link-storylet: -1)`).not.markupToError()
			expect(`(link-storylet: 'ears', 2)`).not.markupToError()
			expect(`(link-storylet: 'ears', where its tags contains 'e')`).not.markupToError()
			expect(`(link-storylet: 'ears', 2, where its tags contains 'e')`).markupToError()
			expect(`(link-storylet: 'ears', where its tags contains 'e', 'foo')`).not.markupToError()
			expect(`(link-storylet: 'ears', 2, 'bar')`).not.markupToError()
		})
		it(`given an index n, creates a link to the nth open storylet, using the same order as (open-storylets:)`, () => {
			createPassage(`**foobarbaz(Story-let: when  true is true)**`, `grault`)
			createPassage(`|a>[(storylet: when  $a is 1)]`, `garply`)
			createPassage(`(storylet: when  true is false)`, `corge`)
			createPassage(`(storylet: when  $a is > 1)`, `quux`)
			runPassage(`(set: $a to 1)`)
			expect(`(link-storylet:1) (link-storylet:2)`).markupToPrint(`garply grault`)
			runPassage(`(set: $a to 2)`)
			expect(`(link-storylet:1) (link-storylet:2, 'foo')`).markupToPrint(`grault quux`)
		})
		it(`given an index n, links to the nth (open-storylets:) result`, () => {
			createPassage(`**foobarbaz(Story-let: when $a is 1)**`, `grault`)
			createPassage(`|a>[(storylet: when $a is 1)]`, `garply`)
			createPassage(`(storylet: when $a is > 1)`, `corge`)
			createPassage(`(storylet: when $a is > 1)`, `quux`)
			expect(`(set:$a to 1)(link-storylet: 2)`).markupToPrint(`grault`)
			expect(`(set:$a to 2)(link-storylet: 2, 'foo')`).markupToPrint(`quux`)
		})
		it(`if the index n is negative, links to the nthlast (open-storylets:) result`, () => {
			createPassage(`**foobarbaz(Story-let: when $a > 1)**`, `grault`)
			createPassage(`|a>[(storylet: when $a > 1)]`, `garply`)
			createPassage(`(storylet: when $a is > 1)`, `corge`)
			createPassage(`(storylet: when $a is > 1)`, `quux`)
			expect(`(set:$a to 2)(link-storylet: -1) (link-storylet: -2)`).markupToPrint(`quux grault`)
		})
		it(`given a 'where' lambda, creates a link to the first (open-storylets:) result to match the condition`, () => {
			createPassage(`**foobarbaz(Story-let: when $a is 1)**`, `grault`)
			createPassage(`|a>[(storylet: when $a is 1)]`, `garply`)
			createPassage(`(storylet: when $a is > 1)`, `corge`)
			createPassage(`(storylet: when $a is > 1)`, `quux`)
			expect(`(set:$a to 1)(link-storylet: where its name contains 't')`).markupToPrint(`grault`)
			expect(`(set:$a to 2)(link-storylet: where its name contains 'x')`).markupToPrint(`quux`)
		})
		it(`if there are no matches, prints the unavailable text, if given, or nothing`, () => {
			createPassage(`(storylet: when $a is > 1)`, `corge`)
			createPassage(`(storylet: when $a is > 1)`, `quux`)
			expect(`(set:$a to 1)(link-storylet: 2)`).markupToPrint(``)
			expect(`(set:$a to 2)(link-storylet: where its name is 'qux')`).markupToPrint(``)
			let p = runPassage(`(set:$a to 1)(link-storylet: 2, 'foobaz')`)
			expect(p.text()).toBe(`foobaz`)
			expect(p.find(`tw-link`).length).toBe(0)
			p = runPassage(`(set:$a to 2)(link-storylet: where its name is 'qux', 'foobaz')`)
			expect(p.text()).toBe(`foobaz`)
			expect(p.find(`tw-link`).length).toBe(0)
		})
		it(`uses the optional string as the link text instead of the passage name`, () => {
			createPassage(`(storylet: when $a is > 1)`, `corge`)
			createPassage(`(storylet: when $a is > 1)`, `quux`)
			expect(`(set:$a to 2)(link-storylet: 'foo', 1)`).markupToPrint(`foo`)
			expect(`(link-storylet: 'bar', where its name contains 'x')`).markupToPrint(`bar`)
		})
		it(`errors at runtime if a lambda causes an error`, () => {
			createPassage(`(storylet: when $a is 3 + 'r')`, `grault`)
			expect(`(link-storylet:1)`).markupToError()
			createPassage(`(storylet: when it is 2)`, `grault`)
			expect(`(link-storylet:1)`).markupToError()
		})
	})
	describe(`the (open-storylets:) macro`, () => {
		it(`returns a sorted array of passages with (storylet:) in their prose, whose lambda returns true`, () => {
			createPassage(`**foobarbaz(Story-let: when  true is true)**`, `grault`)
			createPassage(`|a>[(storylet: when  $a is 1)]`, `garply`)
			createPassage(`(storylet: when  true is false)`, `corge`)
			createPassage(`(storylet: when  $a is > 1)`, `quux`)
			runPassage(`(set: $a to 1)`)
			expect(`(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(`garply grault `)
			runPassage(`(set: $a to 2)`)
			expect(`(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(`grault quux `)
		})
		it(`uses an optional 'where' lambda to restrict the returned storylets`, () => {
			createPassage(`**foobarbaz(Story-let: when $a is 1)**`, `grault`)
			createPassage(`|a>[(storylet: when $a is 1)]`, `garply`)
			createPassage(`(storylet: when $a is > 1)`, `corge`)
			createPassage(`(storylet: when $a is > 1)`, `quux`)
			expect(`(set:$a to 1)(print:(open-storylets: where its name contains 't')'s 1st's name)`).markupToPrint(`grault`)
			expect(`(set:$a to 2)(print:(open-storylets: where its name contains 'x')'s 1st's name)`).markupToPrint(`quux`)
		})
		it(`errors at runtime if a lambda causes an error`, () => {
			createPassage(`(storylet: when $a is 3 + 'r')`, `grault`)
			expect(`(open-storylets:)`).markupToError()
			createPassage(`(storylet: when it is 2)`, `grault`)
			expect(`(open-storylets:)`).markupToError()
		})
		it(`sorts passages with a greater 'urgency' metadata number higher`, () => {
			createPassage(`(storylet: when true)(urgency:2)`, `grault`)
			createPassage(`(storylet: when true)`, `garply`)
			createPassage(`(storylet: when true)(urgency:-1)`, `aldo`)
			expect(`(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(`grault garply aldo `)
		})
		it(`only includes passages with the highest 'exclusivity' metadata number`, () => {
			createPassage(`(storylet: when $a is 1)(exclusivity:2)`, `grault`)
			createPassage(`(storylet: when $a is 1)(exclusivity:2)`, `qux`)
			createPassage(`(storylet: when $a or $b is 1)`, `garply`)
			createPassage(`(storylet: when $a or $b or $c is 1)(exclusivity:-1)`, `aldo`)
			createPassage(`(storylet: when $a or $b or $c is 1)(exclusivity:-2)`, `walter`)
			expect(`(set:$a to 1, $b to 0, $c to 0)(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(`grault qux `)
			expect(`(set:$a to 0, $b to 1, $c to 0)(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(`garply `)
			expect(`(set:$b to 0, $c to 1, $a to 0)(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(`aldo `)
		})
		describe(`when evaluating (storylet:) lambdas`, () => {
			it(`'visits' refers to the containing passage itself`, () => {
				createPassage(`(storylet: when visits > 3)`, `grault`)
				createPassage(`(storylet: when visits is 1)`, `garply`)
				goToPassage(`grault`)
				expect(`(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(``)
				goToPassage(`grault`)
				goToPassage(`grault`)
				goToPassage(`grault`)
				expect(`(for: each _a, ...(open-storylets:))[(print:_a's name) ]`).markupToPrint(`grault `)
			})
			it(`temp variables can't be referenced`, () => {
				createPassage(`(storylet: when _b is 1)`, `grault`)
				expect(`(set: _b to 1)(set: $a to (open-storylets:))`).markupToError()
			})
			it(`'exits' can't be referenced`, () => {
				createPassage(`(storylet: when exits is 1)`, `grault`)
				expect(`(set: _b to 1)(set: $a to (open-storylets:))`).markupToError()
			})
			it(`'time' can't be referenced`, () => {
				createPassage(`(storylet: when time is 1)`, `grault`)
				expect(`(set: _b to 1)(set: $a to (open-storylets:))`).markupToError()
			})
			it(`flow control blockers can't be used`, () => {
				createPassage(`(storylet: when (prompt: 'foo', 'bar') is 'baz')`, `grault`)
				expect(`(set: _b to 1)(set: $a to (open-storylets:))`).markupToError()
			})
		})
	})
	describe(`the (metadata:) macro`, () => {
		it(`accepts valid dataname and datavalue pairs`, () => {
			expect(`(metadata: 'foo')`).markupToError()
			expect(`(metadata: 'foo', 1, 'bar')`).markupToError()
			expect(`(metadata: true, 1)`).markupToError()
			expect(`(metadata: 'foo', 1, 'bar', 2)`).not.markupToError()
		})
		it(`displays nothing in passages when run`, () => {
			expect(`(metadata: 'foo', 1, 'bar', 2)`).markupToPrint(``)
		})
		it(`adds the given values to that passage's (passage:) datamap`, () => {
			createPassage(`(metadata: 'foo', 12, 'bar', 24)`, `grault`)
			expect(`(print: 'foo' of (passage:'grault'))`).markupToPrint(`12`)
		})
		it(`can be commented out`, () => {
			createPassage(`(metadata: 'foo', 12)\n--(metadata:'bar',14)`, `grault`)
			expect(`(print: 'foo' of (passage:'grault')) (print: 'bar' is in (passage:'grault'))`).markupToPrint(`12 false`)
		})
	});
	[`urgency`,`exclusivity`].forEach((name) => {
		describe(`the (${  name  }:) macro`, () => {
			it(`accepts only numbers`, () => {
				expect(`(${  name  }: 'foo')`).markupToError()
				expect(`(${  name  }: true)`).markupToError()
				expect(`(${  name  }: (a:))`).markupToError()
				expect(`(${  name  }: 2)`).not.markupToError()
			})
			it(`displays nothing in passages when run`, () => {
				expect(`(${  name  }: 2)`).markupToPrint(``)
			})
			it(`adds the given number to that passage's (passage:) datamap as the '${  name  }' data value`, () => {
				createPassage(`(${  name  }: 12)`, `grault`)
				expect(`(print: '${  name  }' of (passage:'grault'))`).markupToPrint(`12`)
			})
		})
	})
})
