describe(`setup passages`, () => {
	'use strict'
	beforeAll(() => {
		Utils.options.debug = true
	})
	afterAll(() => {
		Utils.options.debug = false
	});
	[false,true].forEach(function headerFooterTests(debug) {
		let header = debug ? `debug-header` : `header`
		let footer = debug ? `debug-footer` : `footer`
		let startup = debug ? `debug-startup` : `startup`
		
		describe(`the '${  header  }' tag`, () => {
			it(`makes the passage's source run before any other passage is run`, () => {
				createPassage(`(set: $red to turns)`,`header`,[header])
				expect(`$red`).markupToPrint(`1`)
				expect(`$red`).markupToPrint(`2`)
				expect(`$red`).markupToPrint(`3`)
			})
			it(`prepends the passage's source to every passage at runtime`, () => {
				createPassage(`Gee`,`header`,[header])
				expect(`wow`).markupToPrint(`Geewow`)
			})
			it(`creates proper <tw-include> elements`, () => {
				createPassage(`Gee`,`header`,[header])
				let p = runPassage(`wow`)
				expect(p.find(`tw-include`).text()).toBe(`Gee`)
				expect(p.text()).toBe(`Geewow`)
			})
			it(`tagged passages run in alphabetical order`, () => {
				createPassage(`(set: $red to it + 'D')`,`header4`,[header])
				createPassage(`(set: $red to it + 'B')`,`header2`,[header])
				createPassage(`(set: $red to it + 'C')`,`header3`,[header])
				createPassage(`(set: $red to 'A')`,`header1`,[header])
				expect(`$red`).markupToPrint(`ABCD`)
			})
			it(`cannot be 'punched through' with unclosed markup`, () => {
				createPassage(`Gee[==gosh`,`header`,[header])
				let p = runPassage(`wow`,`bar`)
				expect(p.find(`tw-include`).first().text()).toBe(`Geegosh`)
				expect(p.find(`tw-include tw-hook`).first().text()).toBe(`gosh`)
			})
			it(`affects hooks inside the passage`, () => {
				createPassage(`(click: ?red)[]`,`header`,[header])
				expect(runPassage(`|red>[Hmm]`,`1`).find(`tw-enchantment`).length).toBe(1)
			})
			it(`won't lead to infinite regress if it is displayed itself`, () => {
				createPassage(`Hey`,`header`,[header])
				expect(goToPassage(`header`).text()).toBe(`HeyHey`)
			})
			if (debug) {
				it(`tagged passages run after ordinary header passages`, () => {
					createPassage(`(set: $red to 'A')`,`setup2`,[`header`])
					createPassage(`(set: $red to $red + 'B')`,`setup1`,[header])
					expect(`$red`).markupToPrint(`AB`)
				})
			}
		})
		describe(`the '${  footer  }' tag`, () => {
			it(`makes the passage's source run after any other passage is run`, () => {
				createPassage(`(set: $red to $red + 1)`,`footer`,[footer])
				expect(`(set:$red to 0)$red`).markupToPrint(`0`)
				expect(`$red`).markupToPrint(`1`)
				expect(`$red`).markupToPrint(`2`)
			})
			it(`appends the passage's source to every passage at runtime`, () => {
				createPassage(`gee`,`footer`,[footer])
				expect(`Wow`).markupToPrint(`Wowgee`)
			})
			it(`creates proper <tw-include> elements`, () => {
				createPassage(`wow`,`footer`,[footer])
				let p = runPassage(`Gee`)
				expect(p.find(`tw-include`).text()).toBe(`wow`)
				expect(p.text()).toBe(`Geewow`)
			})
			it(`tagged passages run in alphabetical order`, () => {
				createPassage(`(set: $red to it + 'D')`,`footer4`,[footer])
				createPassage(`(set: $red to $red + 'B')`,`footer2`,[footer])
				createPassage(`(set: $red to it + 'C')`,`footer3`,[footer])
				createPassage(`(set: $red to 'A')`,`footer1`,[footer])
				runPassage(``)
				expect(`$red`).markupToPrint(`ABCD`)
			})
			it(`cannot be 'punched through' with unclosed markup`, () => {
				createPassage(`wow`,`footer2`,[footer])
				let p = runPassage(`Gosh[=`,`bar`)
				expect(p.find(`tw-hook tw-include`).length).toBe(0)
			})
			it(`affects hooks inside the passage`, () => {
				createPassage(`(click: ?red)[]`,`footer`,[footer])
				expect(runPassage(`|red>[Hmm]`,`1`).find(`tw-enchantment`).length).toBe(1)
			})
			it(`won't lead to infinite regress if it is displayed itself`, () => {
				createPassage(`Hey`,`footer`,[footer])
				expect(goToPassage(`footer`).text()).toBe(`HeyHey`)
			})
			if (debug) {
				it(`tagged passages run after ordinary footer passages`, () => {
					createPassage(`(set: $red to 'A')`,`setup2`,[`footer`])
					createPassage(`(set: $red to $red + 'B')`,`setup1`,[footer])
					runPassage(``)
					expect(`$red`).markupToPrint(`AB`)
				})
			}
		})
		describe(`the '${  startup  }' tag`, () => {
			it(`makes the passage's source run before the very first passage is run`, () => {
				createPassage(`(set: $red to turns)`,`setup`,[startup])
				expect(`$red`).markupToPrint(`1`)
				expect(`$red`).markupToPrint(`1`)
			})
			it(`creates proper <tw-include> elements`, () => {
				createPassage(`Gee`,`setup`,[startup])
				let p = runPassage(`wow`)
				expect(p.find(`tw-include`).text()).toBe(`Gee`)
				expect(p.text()).toBe(`Geewow`)
			})
			it(`tagged passages run in alphabetical order`, () => {
				createPassage(`(set: $red to 'A')`,`setup1`,[startup])
				createPassage(`(set: $red to $red + 'B')`,`setup2`,[startup])
				expect(`$red`).markupToPrint(`AB`)
			})
			it(`tagged passages run before header passages`, () => {
				createPassage(`(set: $red to 'A')`,`setup2`,[startup])
				createPassage(`(set: $red to $red + 'B')`,`setup1`,[header])
				expect(`$red`).markupToPrint(`AB`)
			})
			it(`affects hooks inside the passage`, () => {
				createPassage(`(click: ?red)[]`,`setup`,[startup])
				expect(runPassage(`|red>[Hmm]`,`1`).find(`tw-enchantment`).length).toBe(1)
			})
		})
	})
	it(`run in the intended order`, () => {
		createPassage(`foo`,`A`,[`startup`])
		createPassage(`bar`,`B`,[`debug-startup`])
		createPassage(`baz`,`D`,[`debug-header`])
		createPassage(`qux`,`C`,[`header`])
		createPassage(`corge`,`E`,[`debug-footer`])
		createPassage(`garply`,`F`,[`footer`])
		expect(`grault`).markupToPrint(`foobarquxbazgraultgarplycorge`)
	})
	it(`work when empty`, () => {
		createPassage(``,`A`,[`startup`])
		createPassage(``,`B`,[`debug-startup`])
		createPassage(``,`D`,[`debug-header`])
		createPassage(``,`C`,[`header`])
		createPassage(``,`E`,[`debug-footer`])
		createPassage(``,`F`,[`footer`])
		expect(`grault`).not.markupToError()
	})
})
