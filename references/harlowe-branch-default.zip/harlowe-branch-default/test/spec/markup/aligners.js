describe(`aligner syntax`, () => {
	'use strict'
	
	it(`right-aligns text with ==> on a single line, and ends right-alignment with <== on a single line`, () => {
		let passage = runPassage(`==>\ngarply\n<==\ngrault`)
		let align = passage.find(`tw-align`)
		expect(align.css(`text-align`)).toBe(`right`)
		expect(align.text()).toBe(`garply`)
		expect(passage.text()).toBe(`garply\ngrault`)
		expect(align.css(`margin-left`)).toMatch(/^(?:0px)?$/)
	})
	it(`ignores preceding and trailing whitespace`, () => {
		let align = runPassage(`   ==>   \ngarply\n   <==   `).find(`tw-align`)
		expect(align.length).toBe(1)
	})
	it(`must be on a single line`, () => {
		let align = runPassage(`==>garply\ngrault\n<==corge`).find(`tw-align`)
		expect(align.length).toBe(0)
	})
	it(`ignores the number of, and imbalance of, = signs used`, () => {
		[2,3,4,5,6,7,8,9,10].forEach((number) => {
			let align = runPassage(`${`=`.repeat(number)  }>\ngarply\n<${  `=`.repeat(number+2)}`).find(`tw-align`)
			expect(align.css(`text-align`)).toBe(`right`)
			expect(align.text()).toBe(`garply`)
			expect(align.css(`margin-left`)).toMatch(/^(?:0px)?$/)
		})
	})
	it(`centres text with a balanced =><=`, () => {
		let align = runPassage(`=><=\ngarply`).find(`tw-align`)
		expect(align.css(`text-align`)).toBe(`center`)
		expect(align.text()).toBe(`garply`)
		expect(align.attr(`style`)).toMatch(/max-width:\s*50%/)
		expect(align.attr(`style`)).toMatch(/margin-left:\sauto/)
		expect(align.attr(`style`)).toMatch(/margin-right:\sauto/)
	})
	it(`justifies text with <==>`, () => {
		let align = runPassage(`<==>\ngarply\n<==`).find(`tw-align`)
		expect(align.css(`text-align`)).toBe(`justify`)
		expect(align.text()).toBe(`garply`)
		expect(align.css(`margin-left`)).toMatch(/^(?:0px)?$/)
	})
	it(`aligns text with unbalanced ==><=`, () => {
		let align = runPassage(`==><====\ngarply`).find(`tw-align`)
		expect(align.css(`text-align`)).toBe(`center`)
		expect(align.attr(`style`)).toMatch(/margin-left:\s*17%/)
		
		align = runPassage(`=====><=\ngarply`).find(`tw-align`)
		expect(align.css(`text-align`)).toBe(`center`)
		expect(align.attr(`style`)).toMatch(/margin-left:\s*42%/)
	})
	it(`works if there is a header passage before it`, () => {
		createPassage(`Hello\n`,``,[`header`])
		let align = runPassage(`==><====\ngarply`).find(`tw-align`)
		expect(align.css(`text-align`)).toBe(`center`)
		expect(align.attr(`style`)).toMatch(/margin-left:\s*17%/)
	})
	it(`doesn't nest <tw-align> elements`, () => {
		let align = runPassage(`<==>\ngarply\n==>\ngrault\n<==`).find(`tw-align`)
		expect(align.first().text()).toBe(`garply`)
		expect(align.last().text()).toBe(`grault`)
		expect(align.length).toBe(2)
	})
	it(`does not consume preceding line breaks`, () => {
		[1,2,3,4].forEach((i) => {
			expect(runPassage(
				`A${  `\n`.repeat(i)  }==>\ngarply\n<==\n`
			).children(`br,tw-consecutive-br`).length).toBe(i)
		})
	})
	it(`won't create <br> elements afterward`, () => {
		expect(runPassage(`<==>\ngarply\n<==\n`).find(`tw-align + br`).length).toBe(0)
	})
})
