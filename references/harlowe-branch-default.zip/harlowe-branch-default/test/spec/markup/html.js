describe(`HTML in twinemarkup`, () => {
	'use strict'
	function expectHTMLToBecome(text, expected) {
		let r = runPassage(text)
		r.find(`[data-raw]`).removeAttr(`data-raw`)
		expect(r.html()).toBe(expected)
	}
	
	it(`due to the behaviour of jQuery.parseHTML(), orphaned end-tags are silently removed`, () => {
		expect(`Bee</b>`).markupToPrint(`Bee`)
	})

	it(`doesn't recognise tags that begin with a non-ASCII-letter`, () => {
		expect(`<3>Bee</3>`).markupToPrint(`<3>Bee`)
		expect(`<é>Bee</é>`).markupToPrint(`<é>Bee`)
	})

	describe(`span-level tags`, () => {
		it(`are rendered as HTML, with an added data-raw attribute`, () => {
			expect(runPassage(`<b>Bee</b>`).find(`b[data-raw]`).length).toBe(1)
		})
		it(`turn into their respective elements`, () => {
			expectHTMLToBecome(
				`<i>What</i> <b>is</b> <u>this</u>?`,
				`<i>What</i> <b>is</b> <u>this</u>?`
			)
		})
		it(`persist across line breaks`, () => {
			expectHTMLToBecome(
				`<i>What\n</i> <b>is\n</b> <u>this\n</u>?`,
				`<i>What<br></i> <b>is<br></b> <u>this<br></u>?`
			)
		})
	})
	describe(`block-level tags`, () => {
		it(`turn into their respective elements`, () => {
			expectHTMLToBecome(
				`<div>Hey</div>?`,
				`<div>Hey</div>?`
			)
		})
	})
	describe(`XML self-closing tags`, () => {
		it(`turn into their respective elements`, () => {
			expectHTMLToBecome(
				`<div /><b/>Hey`,
				`<div></div><b></b>Hey`
			)
		})
	})
	describe(`elements with attributes`, () => {
		it(`retain their attributes`, () => {
			let DOM = runPassage(`<div id='gerald' style='background-color:black'>Hey</div>?`)
			
			expect(DOM.find(`#gerald`).attr(`style`)).toMatch(/background-color:\s*black/)
		})
	})
	describe(`<script> tags`, () => {
		it(`execute their contained code`, () => {
			expect(runPassage(`Hey!<script>window.foo = 1;</script>`).find(`script`).length).toBe(1)
			expect(window.foo).toBe(1)
		})
		it(`can be used without escaping their contents`, () => {
			expect(runPassage(`<script>window.foo = "**bar**";</script>`).find(`script`).length).toBe(1)
			expect(window.foo).toBe(`**bar**`)
		})
		it(`can have src attributes`, (done) => {
			runPassage(`<script src="data:text/javascript;plain,window.foo=1//"></script>`)
			setTimeout(() => {
				expect(window.foo).toBe(1)
				done()
			},1000)
		})
		it(`can access global Harlowe variables`, () => {
			expect(`(set: $foo to 8)<script>$foo -= 1;</script>$foo`).markupToPrint(`7`)
		})
		it(`can access global Harlowe temp variables`, () => {
			expect(`(set: _foo to 9)<script>_foo += 4;</script>_foo`).markupToPrint(`13`)
			expect(`[(set: _foo to 8)[(set:_bar to 7)]<script>_foo = (typeof _bar === 'undefined');</script>(print:_foo)]`).markupToPrint(`true`)
		})
		it(`produces an error if a Javascript error occurs`, () => {
			spyOn(console,`error`)
			expect(`(set: _foo to 9)<script>_foo =</script>_foo`).markupToError(`13`)
			expect(console.error).toHaveBeenCalledTimes(1)
		})
		it(`errors if a non-Harlowe value is assigned to a Harlowe variable`, () => {
			[`new Map([['a',2]])`, `new Set([1,3,5])`, `[1,3,[5]]`, `true`, `2.111`, `'abc'`].forEach((e) =>{
				expect(`(set: $foo to 0)<script>$foo = ${  e  }</script>$foo`).not.markupToError()
			});
			[`NaN`,`Infinity`,`{}`,`new Map([[3,2]])`,`new Map([['a',{}]])`,`new Set([{}])`,`[{}]`,`/foo/g`,`document.body`,`null`,`undefined`].forEach((e) =>{
				expect(`(set: $foo to 0)<script>$foo = ${  e  }</script>$foo`).markupToError()
			})
		})
		it(`errors if a Harlowe-only value is accessed from Javascript`, () => {
			[`(hsl:200,0.5,0.5)`, `via it + 1`, `(text-style:'bold')`, `(v6m-print:'A')`].forEach((e) =>{
				expect(`(set: $foo to ${  e  })<script>window.foo = $foo</script>$foo`).markupToError()
			})
		})
		afterEach(() => {
			delete window.foo
		})
	})
	describe(`<style> tags`, () => {
		it(`can be used without escaping their contents`, () => {
			expect(runPassage(`<style>b { box-sizing: content-box; }</style><b>Hey</b>`).find(`b`).css(`box-sizing`)).toBe(`content-box`)
		})
	})
	describe(`<textarea> tags`, () => {
		it(`can be used without escaping their contents`, () => {
			expect(runPassage(`<textarea>**bar**</textarea>`).find(`textarea`).text()).toBe(`**bar**`)
		})
	})

	describe(`<table> tags`, () => {
		it(`won't allow line breaks to become erroneous <br> elements inside them`, () => {
			expect(runPassage(`<table>\n<tr> \n<td>X</td>C\nV</tr>\n?</table>`).find(`br`).length).toBe(0)
		})
		it(`will allow line breaks nested inside some other structure`, () => {
			expect(runPassage(`<table>''\n''<tr><td>X</td>''\n''</tr></table>`).find(`br`).length).toBe(2)
		})
		it(`will allow explicit <br> elements inside them to be automatically moved`, () => {
			expect(runPassage(`<table><br><tr><td>X</td><br></tr></table>`).find(`br + br`).length).toBe(1)
		})
	})
	
	let audioBase64 = [
		`data:audio/ogg;base64,T2dnUwACAAAAAAAAAAARBU1rAAAAAEjYPQIBHgF2b3JiaXMAAAAAAUAfAAAAAAAAYG0AAAAAAACZAU9nZ1MAAAAAAAAAAAAAEQVNawEAAABnX/A/Czv///////////+1A3ZvcmJpcysAAABYaXBoLk9yZyBsaWJWb3JiaXMgSSAyMDEyMDIwMyAoT21uaXByZXNlbnQpAAAAAAEFdm9yYmlzEkJDVgEAAAEADFIUISUZU0pjCJVSUikFHWNQW0cdY9Q5RiFkEFOISRmle08qlVhKyBFSWClFHVNMU0mVUpYpRR1jFFNIIVPWMWWhcxRLhkkJJWxNrnQWS+iZY5YxRh1jzlpKnWPWMUUdY1JSSaFzGDpmJWQUOkbF6GJ8MDqVokIovsfeUukthYpbir3XGlPrLYQYS2nBCGFz7bXV3EpqxRhjjDHGxeJTKILQkFUAAAEAAEAEAUJDVgEACgAAwlAMRVGA0JBVAEAGAIAAFEVxFMdxHEeSJMsCQkNWAQBAAAACAAAojuEokiNJkmRZlmVZlqZ5lqi5qi/7ri7rru3qug6EhqwEAMgAABiGIYfeScyQU5BJJilVzDkIofUOOeUUZNJSxphijFHOkFMMMQUxhtAphRDUTjmlDCIIQ0idZM4gSz3o4GLnOBAasiIAiAIAAIxBjCHGkHMMSgYhco5JyCBEzjkpnZRMSiittJZJCS2V1iLnnJROSialtBZSy6SU1kIrBQAABDgAAARYCIWGrAgAogAAEIOQUkgpxJRiTjGHlFKOKceQUsw5xZhyjDHoIFTMMcgchEgpxRhzTjnmIGQMKuYchAwyAQAAAQ4AAAEWQqEhKwKAOAEAgyRpmqVpomhpmih6pqiqoiiqquV5pumZpqp6oqmqpqq6rqmqrmx5nml6pqiqnimqqqmqrmuqquuKqmrLpqvatumqtuzKsm67sqzbnqrKtqm6sm6qrm27smzrrizbuuR5quqZput6pum6quvasuq6su2ZpuuKqivbpuvKsuvKtq3Ksq5rpum6oqvarqm6su3Krm27sqz7puvqturKuq7Ksu7btq77sq0Lu+i6tq7Krq6rsqzrsi3rtmzbQsnzVNUzTdf1TNN1Vde1bdV1bVszTdc1XVeWRdV1ZdWVdV11ZVv3TNN1TVeVZdNVZVmVZd12ZVeXRde1bVWWfV11ZV+Xbd33ZVnXfdN1dVuVZdtXZVn3ZV33hVm3fd1TVVs3XVfXTdfVfVvXfWG2bd8XXVfXVdnWhVWWdd/WfWWYdZ0wuq6uq7bs66os676u68Yw67owrLpt/K6tC8Or68ax676u3L6Patu+8Oq2Mby6bhy7sBu/7fvGsamqbZuuq+umK+u6bOu+b+u6cYyuq+uqLPu66sq+b+u68Ou+Lwyj6+q6Ksu6sNqyr8u6Lgy7rhvDatvC7tq6cMyyLgy37yvHrwtD1baF4dV1o6vbxm8Lw9I3dr4AAIABBwCAABPKQKEhKwKAOAEABiEIFWMQKsYghBBSCiGkVDEGIWMOSsYclBBKSSGU0irGIGSOScgckxBKaKmU0EoopaVQSkuhlNZSai2m1FoMobQUSmmtlNJaaim21FJsFWMQMuekZI5JKKW0VkppKXNMSsagpA5CKqWk0kpJrWXOScmgo9I5SKmk0lJJqbVQSmuhlNZKSrGl0kptrcUaSmktpNJaSam11FJtrbVaI8YgZIxByZyTUkpJqZTSWuaclA46KpmDkkopqZWSUqyYk9JBKCWDjEpJpbWSSiuhlNZKSrGFUlprrdWYUks1lJJaSanFUEprrbUaUys1hVBSC6W0FkpprbVWa2ottlBCa6GkFksqMbUWY22txRhKaa2kElspqcUWW42ttVhTSzWWkmJsrdXYSi051lprSi3W0lKMrbWYW0y5xVhrDSW0FkpprZTSWkqtxdZaraGU1koqsZWSWmyt1dhajDWU0mIpKbWQSmyttVhbbDWmlmJssdVYUosxxlhzS7XVlFqLrbVYSys1xhhrbjXlUgAAwIADAECACWWg0JCVAEAUAABgDGOMQWgUcsw5KY1SzjknJXMOQggpZc5BCCGlzjkIpbTUOQehlJRCKSmlFFsoJaXWWiwAAKDAAQAgwAZNicUBCg1ZCQBEAQAgxijFGITGIKUYg9AYoxRjECqlGHMOQqUUY85ByBhzzkEpGWPOQSclhBBCKaWEEEIopZQCAAAKHAAAAmzQlFgcoNCQFQFAFAAAYAxiDDGGIHRSOikRhExKJ6WREloLKWWWSoolxsxaia3E2EgJrYXWMmslxtJiRq3EWGIqAADswAEA7MBCKDRkJQCQBwBAGKMUY845ZxBizDkIITQIMeYchBAqxpxzDkIIFWPOOQchhM455yCEEELnnHMQQgihgxBCCKWU0kEIIYRSSukghBBCKaV0EEIIoZRSCgAAKnAAAAiwUWRzgpGgQkNWAgB5AACAMUo5JyWlRinGIKQUW6MUYxBSaq1iDEJKrcVYMQYhpdZi7CCk1FqMtXYQUmotxlpDSq3FWGvOIaXWYqw119RajLXm3HtqLcZac865AADcBQcAsAMbRTYnGAkqNGQlAJAHAEAgpBRjjDmHlGKMMeecQ0oxxphzzinGGHPOOecUY4w555xzjDHnnHPOOcaYc84555xzzjnnoIOQOeecc9BB6JxzzjkIIXTOOecchBAKAAAqcAAACLBRZHOCkaBCQ1YCAOEAAIAxlFJKKaWUUkqoo5RSSimllFICIaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKZVSSimllFJKKaWUUkoppQAg3woHAP8HG2dYSTorHA0uNGQlABAOAAAYwxiEjDknJaWGMQildE5KSSU1jEEopXMSUkopg9BaaqWk0lJKGYSUYgshlZRaCqW0VmspqbWUUigpxRpLSqml1jLnJKSSWkuttpg5B6Wk1lpqrcUQQkqxtdZSa7F1UlJJrbXWWm0tpJRaay3G1mJsJaWWWmupxdZaTKm1FltLLcbWYkutxdhiizHGGgsA4G5wAIBIsHGGlaSzwtHgQkNWAgAhAQAEMko555yDEEIIIVKKMeeggxBCCCFESjHmnIMQQgghhIwx5yCEEEIIoZSQMeYchBBCCCGEUjrnIIRQSgmllFJK5xyEEEIIpZRSSgkhhBBCKKWUUkopIYQQSimllFJKKSWEEEIopZRSSimlhBBCKKWUUkoppZQQQiillFJKKaWUEkIIoZRSSimllFJCCKWUUkoppZRSSighhFJKKaWUUkoJJZRSSimllFJKKSGUUkoppZRSSimlAACAAwcAgAAj6CSjyiJsNOHCAxAAAAACAAJMAIEBgoJRCAKEEQgAAAAAAAgA+AAASAqAiIho5gwOEBIUFhgaHB4gIiQAAAAAAAAAAAAAAAAET2dnUwAEAQAAAAAAAAARBU1rAgAAANausKoCAQEAAA==`,
		`data:audio/mp3;base64,/+MYxAAAAANIAAAAAExBTUUzLjk4LjJVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV/+MYxDsAAANIAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV/+MYxHYAAANIAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV/+MYxLEAAANIAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV`
	][+!new Audio().canPlayType(`audio/ogg`)]
	
	describe(`<audio> tags`, () => {
		it(`when autoplaying, continue to autoplay after transition has finished`, (done) => {
			let a = runPassage(`<audio autoplay loop><source src='${  audioBase64  }'></source></audio>`).find(`audio`)
			setTimeout(() => {
				expect(a[0].paused).toBe(false)
				done()
			}, 1000)
		})
		it(`even inside nested hooks`, (done) => {
			let a = runPassage(`(text-style:'bold')[<audio autoplay loop><source src='${  audioBase64  }'></source></audio>]`).find(`audio`)
			setTimeout(() => {
				expect(a[0].paused).toBe(false)
				done()
			}, 1000)
		})
	})

	describe(`HTML comments`, () => {
		it(`are removed from the rendered HTML`, () => {
			[0,1,2].forEach((i) => {
				expect(
					`A<!--${  `\n`.repeat(i)  }-->B`
				).markupToBecome(
					`AB`
				)
			})
		})
		it(`can handle partial syntax inside`, () => {
			expect(
				`A<!--''-->B`
			).markupToBecome(
				`AB`
			)
		})
		it(`can be nested`, () => {
			expect(
				`A<!--Cool<!-- -->Cool-->B`
			).markupToBecome(
				`AB`
			)
		})
		it(`are not invalidated by incomplete macro syntax`, () => {
			expect(
				`A<!--(set: -->B`
			).markupToBecome(
				`AB`
			)
		})
	})
	describe(`HTML entities`, () => {
		it(`(named) can be used`, () => {
			expect(
				`&para;&sect;&hearts;`
			).markupToBecome(
				`¶§♥`
			)
		})
		it(`(numeric) can be used`, () => {
			expect(
				`&#223;&#xDF;`
			).markupToBecome(
				`ßß`
			)
		})
	})
})
