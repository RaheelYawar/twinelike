describe(`list markup`, () => {
	'use strict'
	
	describe(`bulleted lists`, () => {
		it(`wraps 1 or more adjacent lines starting with, * plus whitespace, in <ul><li>`, () => {
			expect(
				`* A`
			).markupToBecome(
				`<ul><li>A</li></ul>`
			)
			expect(
				`* A\n* B`
			).markupToBecome(
				`<ul><li>A</li><li>B</li></ul>`
			)
		})
		it(`won't work unless it's at the start of a line`, () => {
			expect(
				`A B * C`
			).markupToBecome(
				`A B * C`
			)
			expect(
				`\nA B * C`
			).markupToBecome(
				`<br>A B * C`
			)
		})
		it(`won't work unless whitespace follows the *`, () => {
			expect(
				`*Red`
			).markupToBecome(
				`*Red`
			)
			expect(
				` *Red`
			).markupToBecome(
				` *Red`
			)
		})
		it(`does not consume preceding line breaks`, () => {
			[1,2,3,4].forEach((i) => {
				expect(
					`A${  `\n`.repeat(i)  }* A`
				).markupToBecome(
					`A` + `<br>${  `<tw-consecutive-br></tw-consecutive-br>`.repeat(i-1)  }<ul><li>A</li></ul>`
				)
			})
		})
		it(`won't create <br> elements afterward`, () => {
			expect(
				`* A\nB`
			).markupToBecome(
				`<ul><li>A</li></ul>B`
			)
		})
		it(`work inside hooks`, () => {
			expect(
				runPassage(` |x>[\n* A\n* B]\n`).find(`tw-hook`)[0].innerHTML
			).toBe(
				`<br><ul><li>A</li><li>B</li></ul>`
			)
		})
		it(`(unlike Markdown) allows nested lists by the addition of more consecutive *'s`, () => {
			expect(
				`* A\n** B\n** C\n* D`
			).markupToBecome(
				`<ul><li>A</li><ul><li>B</li><li>C</li></ul><li>D</li></ul>`
			)
			expect(
				`* A\n*** B\n*** C\n* D`
			).markupToBecome(
				`<ul><li>A</li><ul><ul><li>B</li><li>C</li></ul></ul><li>D</li></ul>`
			)
			expect(
				`*** A\n*** B`
			).markupToBecome(
				`<ul><ul><ul><li>A</li><li>B</li></ul></ul></ul>`
			)
			expect(
				`*** A\n* B\n*** C`
			).markupToBecome(
				`<ul><ul><ul><li>A</li></ul></ul><li>B</li><ul><ul><li>C</li></ul></ul></ul>`
			)
		})
		it(`(unlike Markdown) permits whitespace between the start of the line and *`, () => {
			expect(
				` \t* A`
			).markupToBecome(
				`<ul><li>A</li></ul>`
			)
			expect(
				`   * A   \n   * B   `
			).markupToBecome(
				`<ul><li>A   </li><li>B   </li></ul>`
			)
		})
	})

	describe(`numbered lists`, () => {
		it(`wraps 1 or more adjacent lines starting with 0., plus whitespace, in <ul><li>`, () => {
			expect(
				`0. A`
			).markupToBecome(
				`<ol><li>A</li></ol>`
			)
			expect(
				`0. A\n0. B`
			).markupToBecome(
				`<ol><li>A</li><li>B</li></ol>`
			)
			expect(
				`0.A`
			).markupToBecome(
				`0.A`
			)
		})
		it(`won't work unless it's at the start of a line`, () => {
			expect(
				`A B 0.C`
			).markupToBecome(
				`A B 0.C`
			)
			expect(
				`00. \n`
			).markupToBecome(
				`00. <br>`
			)
			expect(
				`\nA B 0.C`
			).markupToBecome(
				`<br>A B 0.C`
			)
		})
		it(`does not consume preceding line breaks`, () => {
			[1,2,3,4].forEach((i) => {
				expect(
					`A${  `\n`.repeat(i)  }0. A`
				).markupToBecome(
					`A` + `<br>${  `<tw-consecutive-br></tw-consecutive-br>`.repeat(i-1)  }<ol><li>A</li></ol>`
				)
			})
		})
		it(`won't create <br> elements afterward`, () => {
			expect(
				`0. A\nB`
			).markupToBecome(
				`<ol><li>A</li></ol>B`
			)
		})
		it(`work inside hooks`, () => {
			expect(
				runPassage(` |x>[\n0. A\n0. B]\n`).find(`tw-hook`)[0].innerHTML
			).toBe(
				`<br><ol><li>A</li><li>B</li></ol>`
			)
		})
		it(`(unlike Markdown) allows nested lists by the addition of more consecutive *'s`, () => {
			expect(
				`0. A\n0.0. B\n0.0. C\n0. D`
			).markupToBecome(
				`<ol><li>A</li><ol><li>B</li><li>C</li></ol><li>D</li></ol>`
			)
			expect(
				`0. A\n0.0.0. B\n0.0.0. C\n0. D`
			).markupToBecome(
				`<ol><li>A</li><ol><ol><li>B</li><li>C</li></ol></ol><li>D</li></ol>`
			)
			expect(
				`0.0.0. A\n0.0.0. B`
			).markupToBecome(
				`<ol><ol><ol><li>A</li><li>B</li></ol></ol></ol>`
			)
			expect(
				`0.0.0. A\n0. B\n0.0.0. C`
			).markupToBecome(
				`<ol><ol><ol><li>A</li></ol></ol><li>B</li><ol><ol><li>C</li></ol></ol></ol>`
			)
		})
		it(`(unlike Markdown) permits whitespace between the start of the line and 0.`, () => {
			expect(
				` \t0. A`
			).markupToBecome(
				`<ol><li>A</li></ol>`
			)
			expect(
				`   0. A   \n   0. B   `
			).markupToBecome(
				`<ol><li>A   </li><li>B   </li></ol>`
			)
		})
	})
})
