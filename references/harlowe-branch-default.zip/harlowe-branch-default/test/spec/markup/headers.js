describe(`headers and rules`, () => {
	'use strict'
	describe(`header markup`, () => {
		[1,2,3,4,5,6].forEach((i) => {
			it(`wraps a line starting with ${  `#`.repeat(i)  } with a <h${  i  }> element`, () => {
				expect(
					`${`#`.repeat(i)  }Haruyasumi natsuyasumi akiyasumi fuyuyasumi`
				).markupToBecome(
					`<h${  i  }>Haruyasumi natsuyasumi akiyasumi fuyuyasumi</h${  i  }>`
				)
				expect(
					`${`#`.repeat(i)  }Haruyasumi natsuyasumi akiyasumi fuyuyasumi\n`
				).markupToBecome(
					`<h${  i  }>Haruyasumi natsuyasumi akiyasumi fuyuyasumi</h${  i  }>`
				)
			})
		})
		it(`won't work if it's preceded by text`, () => {
			expect(
				`A B #C`
			).markupToBecome(
				`A B #C`
			)
			expect(
				`\nA B #C`
			).markupToBecome(
				`<br>A B #C`
			)
		})
		it(`works if there is a header passage before it`, () => {
			createPassage(`Hello\n`,``,[`header`])
			let p = runPassage(`#A`)
			expect(p.find(`h1`).text()).toBe(`A`)
		})
		it(`does not consume preceding line breaks`, () => {
			[1,2,3,4].forEach((i) => {
				expect(
					`A${  `\n`.repeat(i)  }#A`
				).markupToBecome(
					`A` + `<br>${  `<tw-consecutive-br></tw-consecutive-br>`.repeat(i-1)  }<h1>A</h1>`
				)
			})
		})
		it(`does not create a <br> afterward`, () => {
			expect(
				`#A\nB`
			).markupToBecome(
				`<h1>A</h1>B`
			)
		})
		it(`(unlike Markdown) permits whitespace between the start of the line and #`, () => {
			expect(
				` \f\v\t#A`
			).markupToBecome(
				`<h1>A</h1>`
			)
		})
	})

	describe(`horizontal rules`, () => {
		it(`turns 3 or more hyphens solely occupying a single line into a <hr>`, () => {
			[3,4,5,8,16].forEach((i) => {
				expect(
					`-`.repeat(i)
				).markupToBecome(
					`<hr>`
				)
			})
		})
		it(`works consecutively`, () => {
			expect(
				`---\n`.repeat(3)
			).markupToBecome(
				`<hr><hr><hr>`
			)
		})
		it(`won't work if it's preceded by text`, () => {
			expect(
				`A ---`
			).markupToBecome(
				`A ---`
			)
			expect(
				`\nA B ---`
			).markupToBecome(
				`<br>A B ---`
			)
		})
		it(`ignores preceding and trailing whitespace`, () => {
			expect(
				`   ---   \ngarply`
			).markupToBecome(
				`<hr>garply`
			)
		})
		it(`does not consume preceding line breaks`, () => {
			[1,2,3,4].forEach((i) => {
				expect(
					`A${  `\n`.repeat(i)  }---`
				).markupToBecome(
					`A` + `<br>${  `<tw-consecutive-br></tw-consecutive-br>`.repeat(i-1)  }<hr>`
				)
			})
		})
		it(`won't create <br> elements afterward`, () => {
			expect(
				`---\ngarply`
			).markupToBecome(
				`<hr>garply`
			)
		})
		it(`(unlike Markdown) permits whitespace between the start of the line and ---`, () => {
			expect(
				` \t---`
			).markupToBecome(
				`<hr>`
			)
		})
	})
})
