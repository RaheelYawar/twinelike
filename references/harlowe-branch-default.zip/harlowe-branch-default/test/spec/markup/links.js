describe(`link syntax`, () => {
	'use strict'
	describe(`simple link syntax`, () => {
		it(`consists of [[, text, then ]], and desugars to a (link-goto:) macro`, () => {
			let expression = runPassage(`[[flea]]`).find(`tw-expression`)
		
			expect(expression.attr(`type`)).toBe(`macro`)
			expect(expression.attr(`name`)).toBe(`link-goto`)
			expect(expression.text()).toBe(`flea`)
		})
		it(`can be used in macro expression position`, () => {
			let expression = runPassage(`(set: $x to [[flea]])$x`).find(`tw-expression`)
			
			expect(expression.text()).toBe(`flea`)
		})
		it(`may have non-sequential ]s in the text`, () => {
			let expression = runPassage(`[[fl]e]a]]`).find(`tw-expression`)
		
			expect(expression.attr(`type`)).toBe(`macro`)
			expect(expression.attr(`name`)).toBe(`link-goto`)
			expect(expression.text()).toBe(`fl]e]a`)
		})
		it(`may contain markup, and links to the correct passage based on the plain text`, () => {
			createPassage(``,`mire`)
			let link = runPassage(`[[mi''r''e]]`).find(`tw-link`)
		
			expect(link.html()).toBe(`mi<b>r</b>e`)
			expect(link.parent().data(`linkPassageName`)).toBe(`mire`)
		})
		it(`may contain line breaks`, () => {
			createPassage(``,`mire`)
			let link = runPassage(`[[\nmire\n]]`).find(`tw-link`)
		
			expect(link.html()).toBe(`<br>mire<br>`)
			expect(link.parent().data(`linkPassageName`)).toBe(`mire`)
		})
		it(`won't be confused with nested hooks`, () => {
			expect(runPassage(`|a>[|b>[c]]`).find(`tw-expression, tw-error`).length).toBe(0)
			expect(runPassage(`[[b]<c|]<a|`).find(`tw-expression, tw-error`).length).toBe(0)
			expect(runPassage(`|a>[[b]]`).find(`tw-expression, tw-error`).length).toBe(0)
			expect(runPassage(`[[b]]<a|`).find(`tw-expression`).length).toBe(1)
		})
		it(`won't be confused with attached hooks`, () => {
			createPassage(``,`Hello`)
			expect(runPassage(`(if:true)[[[Hello]]]`).find(`tw-hook tw-link`).length).toBe(1)
		})
		it(`works correctly with double-quotes`, () => {
			createPassage(``,`"do it"`)
			let link = runPassage(`[["do it"]]`).find(`tw-link`)
			expect(link.html()).toBe(`"do it"`)
			expect(link.parent().data(`linkPassageName`)).toBe(`"do it"`)
		})
		it(`works correctly with single-quotes`, () => {
			createPassage(``,`'do it'`)
			let link = runPassage(`[['do it']]`).find(`tw-link`)
			expect(link.html()).toBe(`'do it'`)
			expect(link.parent().data(`linkPassageName`)).toBe(`'do it'`)
		})
	})
	describe(`proper link syntax`, () => {
		it(`consists of a simple link with <- or ->`, () => {
			let expression = runPassage(`[[in->out]]`).find(`tw-expression`)
		
			expect(expression.attr(`type`)).toBe(`macro`)
			expect(expression.attr(`name`)).toBe(`link-goto`)
		})
		it(`only displays the text on the other side of the arrow`, () => {
			let expression = runPassage(`[[in->out]]`).find(`tw-expression`)
		
			expect(expression.text()).toBe(`in`)
		})
		it(`errors if there's no link text`, () => {
			expect(`[[->out]]`).markupToError()
			expect(`[[out<-]]`).markupToError()
		})
		xit(`errors if there's no passage name`, () => {
			expect(`[[out->]]`).markupToError()
			expect(`[[<-out]]`).markupToError()
		})
		it(`links to the passage pointed to by the arrow`, () => {
			createPassage(`Foo`, `out`)
		
			let link = runPassage(`[[in->out]]`).find(`tw-link`)
		
			expect(link.parent().is(`tw-expression`)).toBe(true)
			expect(link.parent().data(`linkPassageName`)).toBe(`out`)
		
			link = runPassage(`[[out<-in]]`).find(`tw-link`)
		
			expect(link.parent().is(`tw-expression`)).toBe(true)
			expect(link.parent().data(`linkPassageName`)).toBe(`out`)
		})
		it(`uses the rightmost right arrow (or, in its absence, leftmost left arrow) as the separator`, () => {
			createPassage(`Foo`, `E`)
		
			let link = runPassage(`[[A->B->C->D->E]]`).find(`tw-link`)
		
			expect(link.text()).toBe(`A->B->C->D`)
			expect(link.parent().data(`linkPassageName`)).toBe(`E`)
		
			link = runPassage(`[[E<-D<-C<-B<-A]]`).find(`tw-link`)
		
			expect(link.text()).toBe(`D<-C<-B<-A`)
			expect(link.parent().data(`linkPassageName`)).toBe(`E`)
		
			link = runPassage(`[[A<-B<-C->D->E]]`).find(`tw-link`)
		
			expect(link.parent().data(`linkPassageName`)).toBe(`E`)
		
			createPassage(`Foo`, `C<-D<-E`)
			link = runPassage(`[[A->B->C<-D<-E]]`).find(`tw-link`)
		
			expect(link.parent().data(`linkPassageName`)).toBe(`C<-D<-E`)
		})
	})
})
