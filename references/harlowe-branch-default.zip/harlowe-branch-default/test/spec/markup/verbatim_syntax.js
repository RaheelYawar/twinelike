describe(`verbatim syntax`, () => {
	'use strict'
	it(`suppresses all other syntax between \` and \``, () => {
		expect(
			`\`A''B''   //C//\``
		).markupToBecome(
			`<tw-verbatim>A''B''   //C//</tw-verbatim>`
		)
	})
	it(`preserves whitespace`, () => {
		expect(
			`\`        \``
		).markupToBecome(
			`<tw-verbatim>        </tw-verbatim>`
		)
	})
	it(`spans multiple lines`, () => {
		expect(
			`\`A\n\n''B''\``
		).markupToBecome(
			`<tw-verbatim>A<br><br>''B''</tw-verbatim>`
		)
	})
	it(`cannot be nested with just single \`s`, () => {
		expect(
			`\`''A''\`''B''\`C`
		).markupToBecome(
			`<tw-verbatim>''A''</tw-verbatim><b>B</b>\`C`
		)
	})
	it(`can enclose a single \` with additional \`\`s`, () => {
		expect(
			`\`\`''A''\`''B''\`\`C`
		).markupToBecome(
			`<tw-verbatim>''A''\`''B''</tw-verbatim>C`
		)
	})
	it(`can enclose closing hook syntax`, () => {
		expect(
			runPassage(`[\`]\`]`).find(`tw-verbatim`).text()
		).toBe(`]`)
	})
	it(`can enclose closing style syntax`, () => {
		[`''`,`//`,`^^`,`~~`].forEach((e) => {
			expect(
				runPassage(`${e  }\`${  e  }\`${  e}`).find(`tw-verbatim`).text()
			).toBe(e)
		})
	})
	it(`can enclose closing collapsing syntax`, () => {
		expect(
			runPassage(`{\`}\`}`).find(`tw-verbatim`).text()
		).toBe(`}`)
	})
})
