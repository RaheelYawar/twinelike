describe(`basic text style markup`, () => {
	'use strict';
	
	[
		{
			name:   `bold markup`,
			markup: [`''`,`''`],
			html:   [`<b>`,`</b>`],
		},
		{
			name:   `italic markup`,
			markup: [`//`,`//`],
			html:   [`<i>`,`</i>`],
		},
		{
			name:   `superscript markup`,
			markup: [`^^`,`^^`],
			html:   [`<sup>`,`</sup>`],
		},
		{
			name:   `strikethrough markup`,
			markup: [`~~`,`~~`],
			html:   [`<s>`,`</s>`],
		},
	]
	.forEach((e) => {
		describe(e.name, () => {
			it(`wraps text enclosed in ${  e.markup.join(` and `)
				} with ${  e.html.join(` and `)  } tags.`, () => {
				expect(
					`A ${  e.markup.join(` B `)  } C`
				).markupToBecome(
					`A ${  e.html.join(` B `)  } C`
				)
			})
			it(`spans multiple lines`, () => {
				expect(
					`A ${  e.markup.join(` B\n `)    } C`
				).markupToBecome(
					`A ${  e.html.join(` B<br> `)  } C`
				)
			})
			it(`can't be nested`, () => {
				expect(
					`A ${  e.markup.join(e.markup.join(` B `))    } C`
				).markupToBecome(
					`A  B  C`
				)
			})
			it(`is ignored if there's no closing pair`, () => {
				expect(
					`A ${  e.markup[0]  } B`
				).markupToBecome(
					`A ${  e.markup[0]  } B`
				)
			})
			it(`works even when empty`, () => {
				expect(
					`A${  e.markup.join(``)  }B`
				).markupToBecome(
					`AB`
				)
			})
		})
	})
	
	describe(`emphasis markup`, () => {
		it(`wraps text enclosed in single * ` +
			` with <em> and </em> tags.`, () => {
			expect(
				`A * B * C`
			).markupToBecome(
				`A <em> B </em> C`
			)
		})
		it(`spans multiple lines (in a way that doesn't conflict with bulleted lists)`, () => {
			expect(
				`A * B\n C * D`
			).markupToBecome(
				`A <em> B<br> C </em> D`
			)
		})
		it(`is ignored if there's no closing pair`, () => {
			expect(
				`A * B`
			).markupToBecome(
				`A * B`
			)
		})
	})
	
	describe(`strong emphasis markup`, () => {
		it(`wraps text enclosed in double ** ` +
			` with <strong> and </strong> tags.`, () => {
			expect(
				`A ** B ** C`
			).markupToBecome(
				`A <strong> B </strong> C`
			)
		})
		it(`spans multiple lines (in a way that doesn't conflict with bulleted lists)`, () => {
			expect(
				`A ** B\n C ** D`
			).markupToBecome(
				`A <strong> B<br> C </strong> D`
			)
		})
		it(`is ignored if there's no closing pair`, () => {
			expect(
				`A ** B`
			).markupToBecome(
				`A ** B`
			)
		})
		it(`works even when empty`, () => {
			expect(
				`A****B`
			).markupToBecome(
				`AB`
			)
		})
		it(`can combine with emphasis markup`, () => {
			expect(
				`A *** B *** C`
			).markupToBecome(
				`A <strong><em> B </em></strong> C`
			)
		})
	})

	describe(`nested markup`, () => {
		it(`exists`, () => {
			expect(
				`''//bold italic//''.`
			).markupToBecome(
				`<b><i>bold italic</i></b>.`
			)
		})
		it(`won't work unless it's correctly nested`, () => {
			expect(
				`//''error//''`
			).markupToBecome(
				`<i>''error</i>''`
			)
		})
	})
})
