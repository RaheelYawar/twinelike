describe(`restricted syntax`, () => {
	'use strict'
	describe(`Twine 1 macro syntax`, () => {
		it(`will simply print an error`, () => {
			expect(`<<set $red to 1>>`).markupToError()
		})
	})
})
