describe(`hooks`, () => {
	'use strict'
	describe(`anonymous hooks`, () => {
		it(`consist of text inside single square brackets, which become <tw-hook> elements`, () =>{
			runPassage(`Hey[foo]Whoa!`)
			expect($(`tw-passage`).find(`tw-hook`).text()).toBe(`foo`)
		})
		it(`hooks can nest if they don't interfere with the link syntax`, () =>{
			runPassage(`[foo[bar]]`)
			expect($(`tw-passage`).find(`tw-hook > tw-hook`).text()).toBe(`bar`)
			runPassage(`[[foo]bar]`)
			expect($(`tw-passage`).find(`tw-hook > tw-hook`).text()).toBe(`foo`)
		})
		it(`<tw-hook> elements have no name attributes`, () =>{
			runPassage(`[foo]`)
			expect($(`tw-passage`).find(`tw-hook`).is(`[name]`)).toBe(false)
		})
	})
	describe(`named hooks`, () => {
		it(`consist of a |, a name, and a >, attached to a hook`, () =>{
			expect(`|hook>[foo]`).markupToPrint(`foo`)
		})
		it(`may also alternatively have a mirrored nametag on the other side`, () =>{
			expect(`[foo]<hook|`).markupToPrint(`foo`)
		})
		it(`names may not be empty`, () =>{
			expect(`|>[foo]`).markupToPrint(`|>foo`)
		})
		it(`names may not contain whitespace`, () =>{
			expect(`|hook >[foo]`).markupToPrint(`|hook >foo`)
		})
		it(`names may contain only underscores or numbers`, () => {
			expect(`|2_>[foo]`).markupToPrint(`foo`)
			expect(`|_2>[foo]`).markupToPrint(`foo`)
			expect(`|_>[foo]`).markupToPrint(`foo`)
			expect(`|2>[foo]`).markupToPrint(`foo`)
		})
		it(`can be nested`, () =>{
			expect(`[[Hello!]<b|]<a|`).markupToPrint(`Hello!`)
			expect(`[|b>[Hello!]]<a|`).markupToPrint(`Hello!`)
			expect(`|a>[|b>[Hello!]]`).markupToPrint(`Hello!`)
			expect(`|a>[[Hello!]<b|]`).markupToPrint(`Hello!`)
		})
		it(`become <tw-hook> elements`, () =>{
			runPassage(`[foo]<hook|`)
			expect($(`tw-passage`).find(`tw-hook`).text()).toBe(`foo`)
		})
		it(`<tw-hook> elements have name attributes`, () =>{
			runPassage(`[foo]<grault|`)
			expect($(`tw-passage`).find(`tw-hook`).attr(`name`)).toBe(`grault`)
		})
		it(`names are insensitive`, () => {
			let p = runPassage(`[foo]<GRAULT| `)
			expect(p.find(`tw-hook`).attr(`name`)).toBe(`grault`)
			p = runPassage(`[foo]<_gra_u-lt| `)
			expect(p.find(`tw-hook`).attr(`name`)).toBe(`grault`)
		})
	})
	describe(`changer macro attached hooks`, () => {
		it(`consist of a macro, then a hook`, () =>{
			expect(`(if:true)[foo]`).markupToPrint(`foo`)
		})
		it(`will simply print the value if the macro isn't a changer or boolean`, () =>{
			expect(`(either:'A')[Hey]`).markupToPrint(`AHey`)
			expect(`(either:1)[Hey]`).markupToPrint(`1Hey`)
			expect(`(a:)[Hey]`).markupToPrint(`Hey`)
			expect(`(datamap:)[Hey]`).markupToPrint(`Hey`)
			expect(`(dataset:)[Hey]`).markupToPrint(`Hey`)
			expect(`(set:$x to 1)[Hey]`).not.markupToError() // The (set:) command doesn't attach
			expect(`(either:(if:true))[Hey]`).not.markupToError()
		})
		it(`may have any amount of whitespace between the macro and the hook`, () =>{
			expect(`(if:true) [foo]`).markupToPrint(`foo`)
			expect(`(if:true)\n[foo]`).markupToPrint(`foo`)
			expect(`(if:true) \n \n [foo]`).markupToPrint(`foo`)
		})
		it(`may have a nametag on the left side`, () =>{
			expect(`(if:true)|hook>[foo]`).not.markupToError()
		})
		it(`may have a mirrored nametag on the right side`, () =>{
			expect(`(if:true)[foo]<hook|`).not.markupToError()
		})
		it(`will error if the hook has no closing bracket`, () =>{
			expect(`(if:true)[(if:true)[Good golly]`, 2).markupToError()
		})
		it(`can chain changers with +`, () =>{
			expect(`(text-color:#639)+(text-style:'bold')[foo]`).markupToPrint(`foo`)
		})
		it(`can chain changers with any amount of whitespace around the +`, () =>{
			expect(`(text-color:#639)  +  (text-style:'bold')    [foo]`).markupToPrint(`foo`)
			expect(`(text-color:#639)\n+(text-style:'bold')\n[foo]`).markupToPrint(`foo`)
		})
		it(`won't initiate chains with non-changer values`, () =>{
			expect(`(either:7)+(text-style:'bold')[foo]`).markupToPrint(`7+foo`)
		})
		it(`will error when chaining with non-changers`, () =>{
			expect(`(text-style:'bold')+(either:7,8)+(text-style:'italic')[foo]`).markupToError()
		})
	})
	describe(`changer variable attached hooks`, () => {
		beforeEach(() =>{
			runPassage(`(set: $foo to (if:true))`)
		})
		it(`consist of a variable, then a hook`, () =>{
			expect(`$foo[foo]`).markupToPrint(`foo`)
		})
		it(`will simply print the variable if it doesn't contain a changer or boolean`, () =>{
			runPassage(`(set: $str to "A")`
				+ `(set: $num to 2)`
				+ `(set: $arr to (a:))`
				+ `(set: $dm to (datamap:))`
				+ `(set: $ds to (dataset:))`)
			expect(`$str[Hey]`).markupToPrint(`AHey`)
			expect(`$num[Hey]`).markupToPrint(`2Hey`)
			expect(`$arr[Hey]`).markupToPrint(`Hey`)
			expect(`$dm[Hey]`).markupToPrint(`Hey`)
			expect(`$ds[Hey]`).markupToPrint(`Hey`)
		})
		it(`may have any amount of whitespace between the variable and the hook`, () =>{
			expect(`$foo [foo]`).markupToPrint(`foo`)
			expect(`$foo\n[foo]`).markupToPrint(`foo`)
			expect(`$foo \n \n [foo]`).markupToPrint(`foo`)
		})
		it(`may have a nametag on the left side`, () =>{
			expect(`$foo|hook>[foo]`).not.markupToError()
		})
		it(`may have a mirrored nametag on the right side`, () =>{
			expect(`$foo[foo]<hook|`).not.markupToError()
		})
		it(`will error if the hook has no closing bracket`, () =>{
			expect(`$foo[$foo[Good golly]`, 2).markupToError()
		})
		it(`can chain changers`, () =>{
			runPassage(`(set: $bar to (text-color:#639))(set: $baz to (text-style:'bold'))`)
			expect(`$bar+$baz[foo]`).markupToPrint(`foo`)
		})
		it(`can chain changers with any amount of whitespace`, () =>{
			runPassage(`(set: $bar to (text-color:#639))(set: $baz to (text-style:'bold'))`)
			expect(`$bar  \n+  $baz    [foo]`).markupToPrint(`foo`)
			expect(`$bar  +\n  $baz    [foo]`).markupToPrint(`foo`)
		})
		it(`won't initiate chains with non-changer values`, () =>{
			runPassage(`(set: $bar to 7)(set: $baz to (text-style:'bold'))`)
			expect(`$bar+$baz[foo]`).markupToPrint(`7+foo`)
		})
		it(`will error when chaining with non-changers`, () =>{
			runPassage(`(set: $bar to 7)(set: $baz to (text-style:'bold'))`)
			expect(`$bar+$baz+$bar[foo]`).markupToError()
		})
	})
	describe(`hidden named hooks`, () => {
		it(`are named hooks with the square bracket replaced with a parenthesis`, () =>{
			runPassage(`|hook)[foo]`)
			expect($(`tw-story`).find(`tw-hook`).attr(`name`)).toBe(`hook`)
			runPassage(`[foo](hook|`)
			expect($(`tw-story`).find(`tw-hook`).attr(`name`)).toBe(`hook`)
		})
		it(`are hidden when the passage initially renders`, () =>{
			expect(`[foo](hook|`).markupToPrint(``)
		})
		it(`are not revealed if (if:) is attached`, () =>{
			expect(`(if:true)[foo](hook|`).markupToPrint(``)
		})
		it(`are not revealed if true is attached`, () =>{
			expect(`(set:$a to true)$a[foo](hook|`).markupToPrint(``)
		})
	})
	describe(`unclosed hooks`, () => {
		it(`consist of [ followed by any number of =`, () =>{
			[1,2,3,5,9].forEach((i) => {
				runPassage(`foo[${  `=`.repeat(i)  }bar`)
				expect($(`tw-passage`).find(`tw-hook`).text()).toBe(`bar`)
			})
		})
		it(`all text following it, until the end of the containing hook, is enclosed in the hook`, () =>{
			runPassage(`foo[==bar`)
			expect($(`tw-passage`).find(`tw-hook`).text()).toBe(`bar`)
			runPassage(`foo[[==bar]baz`)
			expect($(`tw-passage`).find(`tw-hook > tw-hook`).text()).toBe(`bar`)
			runPassage(`[foo[==bar]baz`)
			expect($(`tw-passage`).find(`tw-hook > tw-hook`).text()).toBe(`bar`)
		})
		it(`work with changers`, () =>{
			expect(`[foo(if:false)[==bar]baz`).markupToPrint(`foobaz`)
		})
		it(`work with the named hook syntax`, () =>{
			runPassage(`foo|grault>[==barbaz`)
			expect($(`tw-passage`).find(`tw-hook`).attr(`name`)).toBe(`grault`)
			expect(`foo[|grault>[==barbaz](replace:?grault)[qux]`).markupToPrint(`fooqux`)
		})
		it(`work with the hidden named hook syntax`, () =>{
			expect(`foo|foo)[==barbaz`).markupToPrint(`foo`)
			expect(`foo[|foo)[==bar]baz`).markupToPrint(`foobaz`)
		})
		it(`<tw-hook> elements have no name attributes`, () =>{
			runPassage(`[==foo`)
			expect($(`tw-passage`).find(`tw-hook`).is(`[name]`)).toBe(false)
		})
	})
	describe(`comments`, () => {
		it(`are two hyphens; the next token following it is excluded from rendering`, () =>{
			expect(`This is displayed\n--This is not displayed at all`).markupToPrint(`This is displayed\n`)
			expect(`This is displayed\n--This is not displayed at all(print:'And so is this') and this`).markupToPrint(`This is displayed\nAnd so is this and this`)
			expect(`(print: 512 --+ * 2)`).markupToPrint(`1024`)
			expect(`(print: 512 * --3 2)`).markupToPrint(`1024`)
		})
		it(`can exclude macro calls`, () =>{
			expect(`This is displayed\n--(print: 'This is not displayed at' + ' all')`).markupToPrint(`This is displayed\n`)
		})
		it(`can exclude hooks`, () =>{
			expect(`|1>[This is displayed]\n--[This is not displayed at all(replace:?1)[Bazoom]]`).markupToPrint(`This is displayed\n`)
		})
	})
})
