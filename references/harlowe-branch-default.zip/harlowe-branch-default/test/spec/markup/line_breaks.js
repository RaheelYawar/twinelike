describe(`line break syntax`, () => {
	'use strict'

	describe(`line breaks`, () => {
		it(`turn into <br> elements`, () => {
			expect(
				`Hey\nhi\nhello`
			).markupToBecome(
				`Hey<br>hi<br>hello`
			)
		})
		it(`become <br> elements even in the absence of other text`, () => {
			expect(
				`\n`.repeat(4)
			).markupToBecome(
				`<br>${  `<tw-consecutive-br></tw-consecutive-br>`.repeat(3)}`
			)
		})
	})

	describe(`escaped line syntax`, () => {
		it(`eliminates the following line break when a \\ ends a line`, () => {
			expect(
				`A\\\nB`
			).markupToPrint(
				`AB`
			)
		})
		it(`eliminates the preceding line break when a \\ starts a line`, () => {
			expect(
				`A\n\\B`
			).markupToPrint(
				`AB`
			)
		})
		it(`still works if both backslashes are used`, () => {
			expect(
				`A\\\n\\B`
			).markupToPrint(
				`AB`
			)
		})
		it(`works to extend the heading syntax`, () => {
			expect(
				`#A\n\\B`
			).markupToBecome(
				`<h1>AB</h1>`
			)
			expect(
				`#A\\\nB`
			).markupToBecome(
				`<h1>AB</h1>`
			)
		})
		it(`works to extend the bulleted list syntax`, () => {
			expect(
				`* A\n\\B`
			).markupToBecome(
				`<ul><li>AB</li></ul>`
			)
			expect(
				`* A\\\nB`
			).markupToBecome(
				`<ul><li>AB</li></ul>`
			)
		})
		it(`works to extend the numbered list syntax`, () => {
			expect(
				`0. A\n\\B`
			).markupToBecome(
				`<ol><li>AB</li></ol>`
			)
			expect(
				`0. A\\\nB`
			).markupToBecome(
				`<ol><li>AB</li></ol>`
			)
		})
	})
})
