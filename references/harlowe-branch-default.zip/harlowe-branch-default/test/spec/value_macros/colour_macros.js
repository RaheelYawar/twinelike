describe(`colour macros`, () => {
	'use strict'

	function twColour(str) {
		return runPassage(`(print:${  str  })`).find(`tw-colour`)
	}
	function expectColourToBe(str, colour) {
		expect(twColour(str)).toHaveBackgroundColour(colour)
	}
	function expectColourFnToBe(str, fn, n1, n2, n3, n4) {
		expect(twColour(str)).toHaveBackgroundColourFn(fn, n1, n2, n3, n4 ?? 1)
	}
	describe(`the (rgb:) macro`, () => {
		it(`takes three numbers between 0 and 255 inclusive, and an optional fractional A value between 0 and 1 inclusive`, () => {
			expect(`(rgb: 1)`).markupToError()
			expect(`(rgb: 1,1)`).markupToError()
			expect(`(rgb: 1, 300, 1)`).markupToError()
			expect(`(rgb: 1, 300, 1, 2)`).markupToError()
			expect(`(rgb: 12, 12, 12.1)`).not.markupToError()
		})
		it(`produces a colour using the three numbers and alpha`, () => {
			expectColourToBe(`(rgb:255,0,255)`, `#FF00FF`)
			expectColourToBe(`(rgb:47,25,12)`, `#2F190C`)
			expectColourToBe(`(rgb:255,0,255,0.7)`, `rgba(255, 0, 255, 0.7)`)
			expectColourToBe(`(rgb:47.1,25,12,0.4)`, `rgba(47.1, 25, 12, 0.4)`)
		})
		it(`is aliased as (rgba:)`, () => {
			expectColourToBe(`(rgba:255,0,255)`, `#FF00FF`)
			expectColourToBe(`(rgba:47,25,12)`, `#2F190C`)
			expectColourToBe(`(rgba:255,0,255,0.7)`, `rgba(255, 0, 255, 0.7)`)
			expectColourToBe(`(rgba:47,25,12,0.4)`, `rgba(47, 25, 12, 0.4)`)
		})
	})
	describe(`the (hsl:) macro`, () => {
		it(`takes fractional S and L values between 0 and 1 inclusive, and an optional fractional A value between 0 and 1 inclusive`, () => {
			expect(`(hsl: 1)`).markupToError()
			expect(`(hsl: 1,1)`).markupToError()
			expect(`(hsl: 1,1,1.2)`).markupToError()
			expect(`(hsl: 1,-1,0)`).markupToError()
			expect(`(hsla: 1,1,1,2)`).markupToError()
		})
		it(`takes any kind of finite numeric H value`, () => {
			expect(`(hsl: 1,1,1)`).not.markupToError()
			expect(`(hsl: 900,1,1)`).not.markupToError()
			expect(`(hsl: -8,1,1)`).not.markupToError()
			expect(`(hsl: 1.00006,1,1)`).not.markupToError()
		})
		it(`fractional H values are rounded`, () => {
			expect(`(print:(hsl: 170, 1, 0.5)'s h)`).markupToPrint(`170`)
			expect(`(print:(hsl: 59.1, 1, 0.5)'s h)`).markupToPrint(`59`)
			expect(`(print:(hsl: 3.999, 1, 0.5)'s h)`).markupToPrint(`4`)
		})
		it(`produces a colour using the three numbers and alpha`, () => {
			expectColourToBe(`(hsl:30,0.5,0.9)`, `#f2e6d9`)
			expectColourToBe(`(hsl:270,0.1,0.5)`, `#80738c`)
			expectColourToBe(`(hsl:30,0.5,0.9,0.4)`, `rgba(242, 230, 217, 0.4)`)
			expectColourToBe(`(hsl:270,0.1,0.5,0.7)`, `rgba(128, 115, 140, 0.7)`)
		})
		it(`is aliased as (hsla:)`, () => {
			expectColourToBe(`(hsla:30,0.5,0.9)`, `#f2e6d9`)
			expectColourToBe(`(hsla:270,0.1,0.5)`, `#80738c`)
			expectColourToBe(`(hsla:30,0.5,0.9,0.4)`, `rgba(242, 230, 217, 0.4)`)
			expectColourToBe(`(hsla:270,0.1,0.5,0.7)`, `rgba(128, 115, 140, 0.7)`)
		})
	})
	describe(`the (complement:) macro`, () => {
		it(`takes a single colour`, () => {
			expect(`(complement: 1)`).markupToError()
			expect(`(complement: 'red')`).markupToError()
			expect(`(complement: red)`).not.markupToError()
		})
		it(`returns the colour rotated 180 degrees through the OKLCH circle`, () => {
			runPassage(`(set:$a to (complement: (oklch:0.9,0.2,120)))`)
			expect(`(print: $a's oklch's h)`).markupToPrint(`300`)
			expect(`(print: $a's oklch's c)`).markupToPrint(`0.2`)
			expect(`(print: $a's oklch's l)`).markupToPrint(`0.9`)
			expect(`(print: (complement: (oklch:0.9,0.2,120)) is (oklch:0.9,0.2,300))`).markupToPrint(`true`)
		})
		it(`doesn't change the alpha`, () => {
			expect(`(print: (complement: (oklch:0.9,0.2,120,0.15)) is (oklch:0.9,0.2,300,0.15))`).markupToPrint(`true`)
		})
	})
	describe(`the (lch:) macro`, () => {
		it(`takes a fractional L value between 0 and 1 inclusive, a C value between 0 and 150, a H value, and an optional fractional A value between 0 and 1 inclusive`, () => {
			expect(`(lch: 1)`).markupToError()
			expect(`(lch: 1,1)`).markupToError()
			expect(`(lch: 2,40,1)`).markupToError()
			expect(`(lch: 1,160,1)`).markupToError()
			expect(`(lch: -1,40,1)`).markupToError()
			expect(`(lch: 1,-1,1)`).markupToError()
			expect(`(lch: 1,0,1,2)`).markupToError()
		})
		it(`takes any kind of finite numeric H value`, () => {
			expect(`(lch: 0.5,90,1)`).not.markupToError()
			expect(`(lch: 0.5,90,900)`).not.markupToError()
			expect(`(lch: 0.5,90,-8)`).not.markupToError()
			expect(`(lch: 0.5,90,1.00006)`).not.markupToError()
		})
		it(`fractional H values are rounded`, () => {
			expect(`(print:(lch: 0.5, 90, 170)'s lch's h)`).markupToPrint(`170`)
			expect(`(print:(lch: 0.5, 90, 59.1)'s lch's h)`).markupToPrint(`59`)
			expect(`(print:(lch: 0.5, 90, 3.999)'s lch's h)`).markupToPrint(`4`)
		})
		it(`produces a lcha() colour using the three numbers and alpha`, () => {
			expectColourToBe(`(lch:0.61,80,10)`, `lch(61 80 10 / 1)`)
			expectColourToBe(`(lch:0.61,80,10,0.63)`, `lch(61 80 10 / 0.63)`)
		})
		it(`can round-trip through (rgb:)`, () => {
			runPassage(`(set: _RGB to (rgb: 210.2195, 132.4104, 63.5196))`
				+ `(set: $RGBtoLCH to (lch: _RGB's lch's l, _RGB's lch's c, _RGB's lch's h))`
				+ `(set: $LCHtoRGB to (rgb: $RGBtoLCH's r, $RGBtoLCH's g, $RGBtoLCH's b))`)
			expect(`(print:$RGBtoLCH is $LCHtoRGB)`).markupToPrint(`true`)
			runPassage(`(set: $lch to (lch: 0.5,50,50))`
				+ `(set: $LCHtoRGB to (rgb: $lch's r, $lch's g, $lch's b))`
				+ `(set: $RGBtoLCH to (lch: $LCHtoRGB's lch's l, $LCHtoRGB's lch's c, $LCHtoRGB's lch's h))`)
			expect(`(print:$RGBtoLCH is $LCHtoRGB)`).markupToPrint(`true`)
		})
		it(`produces colours with valid rgb values`, () => {
			expect(`(rgb:(lch: 0.6, 80, 10)'s r, 1,1)`).not.markupToError()
		})
		it(`is aliased as (lcha:)`, () => {
			expectColourToBe(`(lcha:0.61,80,10,0.63)`, `lch(61 80 10 / 0.63)`)
		})
	})
	describe(`the (oklch:) macro`, () => {
		it(`takes a fractional L value between 0 and 1 inclusive, a C value between 0 and 1 inclusive, a H value, and an optional fractional A value between 0 and 1 inclusive`, () => {
			expect(`(oklch: 1)`).markupToError()
			expect(`(oklch: 1,1)`).markupToError()
			expect(`(oklch: 2,0.4,1)`).markupToError()
			expect(`(oklch: 0.1,3,1)`).markupToError()
			expect(`(oklch: -1,0.4,1)`).markupToError()
			expect(`(oklch: 1,-1,1)`).markupToError()
			expect(`(oklch: 1,0.16,1,2)`).markupToError()
		})
		it(`is aliased as (oklcha:)`, () => {
			expectColourToBe(`(oklcha:0.61,0.2,10,0.63)`, `oklch(0.61 0.2 10 / 0.63)`)
		})
		it(`takes any kind of finite numeric H value`, () => {
			expect(`(oklch: 0.5,0.09,1)`).not.markupToError()
			expect(`(oklch: 0.5,0.09,900)`).not.markupToError()
			expect(`(oklch: 0.5,0.09,-8)`).not.markupToError()
			expect(`(oklch: 0.5,0.09,1.00006)`).not.markupToError()
		})
		it(`fractional H values are rounded`, () => {
			expect(`(print:(oklch: 0.5, 0.09, 170)'s oklch's h)`).markupToPrint(`170`)
			expect(`(print:(oklch: 0.5, 0.09, 59.1)'s oklch's h)`).markupToPrint(`59`)
			expect(`(print:(oklch: 0.5, 0.09, 3.999)'s oklch's h)`).markupToPrint(`4`)
		})
		it(`can round-trip through (rgb:)`, () => {
			runPassage(`(set: _RGB to (rgb: 210.2195, 132.4104, 63.5196))`
				+ `(set: $RGBtoOKLCH to (lch: _RGB's oklch's l, _RGB's oklch's c, _RGB's oklch's h))`
				+ `(set: $OKLCHtoRGB to (rgb: $RGBtoOKLCH's r, $RGBtoOKLCH's g, $RGBtoOKLCH's b))`)
			expect(`(print: $RGBtoOKLCH is $OKLCHtoRGB)`).markupToPrint(`true`)
			runPassage(`(set: $ok to (oklch: 0.5,0.09,50))`
				+ `(set: $OKLCHtoRGB to (rgb: $ok's r, $ok's g, $ok's b))`
				+ `(set: $RGBtoOKLCH to (oklch: $OKLCHtoRGB's oklch's l, $OKLCHtoRGB's oklch's c, $OKLCHtoRGB's oklch's h))`)
			expect(`(print: $RGBtoOKLCH is $OKLCHtoRGB)`).markupToPrint(`true`)
		})
	})
	describe(`the (mix:) macro`, () => {
		it(`takes two pairs of percents and colours, plus an optional string value of either "rgb", "hsl", "lch", or "lcha" (case-insensitive)`, () => {
			expect(`(mix: 1)`).markupToError()
			expect(`(mix: red)`).markupToError()
			expect(`(mix: 1, red)`).markupToError()
			expect(`(mix: 1, red, 1, blue)`).not.markupToError()
			expect(`(mix: 1.1, red, 1, blue)`).markupToError()
			;[`rgb`,`lch`,`oklch`,`hsl`].forEach(e => {
				expect(`(mix: "${e}",1, (rgb:128,40,90), 1, (oklch:0.5,0.3,120))`).not.markupToError()
				expect(`(mix: "${e.toUpperCase()}",1, (rgb:128,40,90), 1, (oklch:0.5,0.3,120))`).not.markupToError()
			})
			expect(`(mix: "foo",1, (rgb:128,40,90), 1, blue)`).markupToError()
		})
		it(`if no string is given or "oklch" is given, mixes the colours in the oklch colourspace`, () => {
			expectColourFnToBe(`(mix: 0.5, red, 0.5, blue)`, `oklch`, 0.6, 0.2, 321.1)
			expectColourToBe(`(mix: 0.5, white, 0.5, #00f)`, `oklch`, 0.72, 0.15, 264.05)
			expectColourToBe(`(mix: 0.4, red, 0.1, white)`, `oklch`, 0.67, 0.18, 28.3)
			expectColourToBe(`(mix: 0.5, blue, 0.5, #fff+transparent)`, `oklch`, 0.62, 0.11, 254, 0.75)
			expectColourToBe(`(mix: "oklch", 0.5, red, 0.5, blue)`, `oklch`, 0.6, 0.2, 321.1)
			expectColourToBe(`(mix: "oklch", 0.5, white, 0.5, #00f)`, `oklch`, 0.72, 0.15, 264.05)
			expectColourToBe(`(mix: "oklch", 0.4, red, 0.1, white)`, `oklch`, 0.67, 0.18, 28.3)
			expectColourToBe(`(mix: "oklch", 0.5, blue, 0.5, #fff+transparent)`,`oklch`, 0.62, 0.11, 254, 0.75)
		})
		it(`if a string is given, mixes the colours in the indicated colourspace`, () => {
			expectColourFnToBe(`(mix: "lch", 0.5, blue, 0.5, red)`, `lch`, 51.01, 76.61, 335.01, 1)
			expectColourFnToBe(`(mix: "hsl", 0.5, blue, 0.5, red)`, `rgb`, 179, 25, 230, 1)
			expectColourFnToBe(`(mix: "rgb", 0.5, blue, 0.5, red)`, `rgb`, 128, 76, 128, 1)
			expectColourFnToBe(`(mix: "oklch", 0.5, blue, 0.5, red)`, `oklch`, 0.59, 0.20, 321.1, 1)
			expectColourFnToBe(`(mix: "hsl", 0.5, (rgb:25,127,230,0.2), 0.5, (rgb:230,25,25,0.7))`, `rgb`, 179, 25, 230, 0.45)
		})
	})
	describe(`the (palette:) macro`, () => {
		it(`takes a valid palette type string, and a colour`, () => {
			expect(`(palette: 1)`).markupToError()
			expect(`(palette: 'red')`).markupToError()
			expect(`(palette: red)`).markupToError();
			[`mono`,`adjacent`,`triad`].forEach((e) => {
				expect(`(palette: '${ e }', red)`).not.markupToError()
			})
		})
		it(`returns an array of four colours, including the input colour`, () => {
			expect(`(print: (palette: 'mono', red) is an array)`).markupToPrint(`true`)
			expect(`(print: (palette: 'mono', red)'s length)`).markupToPrint(`4`)
			expect(`(print:(all-pass: _a where _a is a colour, ...(palette:'mono', red)))`).markupToPrint(`true`)
		})
	})
	describe(`the (gradient:) macro`, () => {
		it(`takes a degree number, followed by two or more pairs of percentages and colours`, () => {
			expect(`(gradient: 45)`).markupToError()
			expect(`(gradient: 45,0)`).markupToError()
			expect(`(gradient: 45,0,red)`).markupToError()
			expect(`(gradient: 45,0,red,0.25,white,1,green)`).not.markupToError()
			expect(`(gradient: -1,0,red)`).markupToError()
			expect(`(gradient: 45,0,'#ffffff',1,white)`).markupToError()
			expect(`(gradient: 45,0,white)`).markupToError()
			expect(`(gradient: 45,0,red,0.25,white,1.1,green)`).markupToError()
			expect(`(gradient: 45,0,red,-0.25,white,1,green)`).markupToError()
		})
		it(`takes any kind of finite numeric degree value`, () => {
			expect(`(gradient: 900,0,red,0.25,white,1,green)`).not.markupToError()
			expect(`(gradient: -0.1,0,red,0.25,white,1,green)`).not.markupToError()
			expect(`(gradient: 1.006,0,red,0.25,white,1,green)`).not.markupToError()
		})
		it(`produces a gradient using the given degree and colour stops`, () => {
			expect(runPassage(`(print:(gradient:45,0,(rgb:0,255,0),1,(rgb:0,0,0)))`).find(`tw-colour`))
				.toHaveBackgroundGradient(45, [{stop:0,colour:`#00FF00`},{stop:1,colour:`#000000`}])

			expect(runPassage(`(print:(gradient:105,`
				+`0,(rgb:0,255,0),`
				+`0.2,(rgb:0,0,0),`
				+`0.6,(rgb:0,0,255),`
				+`1,white,`
				+`))`).find(`tw-colour`))
				.toHaveBackgroundGradient(105, [
					{stop:0,colour:`#00FF00`},
					{stop:0.2,colour:`#000000`},
					{stop:0.6,colour:`#0000FF`},
					{stop:1,colour:`#FFFFFF`},
				])

			expect(runPassage(`(print:(gradient:90,`
				+`0,#bf3f3f,`
				+`0.2,#a5bf3f,`
				+`0.4,#3fbf72,`
				+`0.6,#3f72bf,`
				+`0.8,#a53fbf,`
				+`1,#bf3f3f,`
				+`))`).find(`tw-colour`))
				.toHaveBackgroundGradient(90, [
					{stop:0,colour:`#bf3f3f`},
					{stop:0.2,colour:`#a5bf3f`},
					{stop:0.4,colour:`#3fbf72`},
					{stop:0.6,colour:`#3f72bf`},
					{stop:0.8,colour:`#a53fbf`},
					{stop:1,colour:`#bf3f3f`},
				])
		})
	})
	describe(`the (stripes:) macro`, () => {
		it(`errors if given w or h measures`, () => {
			expect(`(stripes:90,15w,red,orange)`).markupToError()
			expect(`(stripes:90,15h,red,orange)`).markupToError()
			expect(`(stripes:90,20px + 15h,red,orange)[]`).markupToError()
		})
	})
})
