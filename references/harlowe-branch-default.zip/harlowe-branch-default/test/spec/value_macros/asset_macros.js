describe(`asset macros`, () => {
	'use strict'
	describe(`the (image:) macro`, () => {
		afterEach(() => {
			clearState()
		})
		it(`cannot be used outside of (define:)`, () => {
			expect(`(set: $a to (image:'a'))`).markupToError()
			expect(`(set: $a to (a:(image:'a')))`).markupToError()
			expect(`(set: $a to (dm:'1',(image:'a')))`).markupToError()
			expect(`(put: (image:'a') into $a)`).markupToError()
			expect(`(image:'a')`).markupToError()
			expect(`(altered: via (image:'a'), 0, 1, 2))`).markupToError()
			expect(`(storylet: when visits is 0 and (image:'a') is an image))(open-storylets:)`).markupToError()
		})
		it(`accepts any number of strings, and an optional final gradient or colour`, () => {
			expect(`(define: $a to (image:))`).markupToMetadataError()
			expect(`(define: $a to (image:22))`).markupToMetadataError()
			expect(`(define: $a to (image:#fff))`).markupToMetadataError()
			expect(`(define: $b to (image:'a.jpg'))`).not.markupToMetadataError()
			expect(`(define: $c to (image:'a.jpg','b.jpg','c.jpg','d.jpg'))`).not.markupToMetadataError()
			expect(`(define: $d to (image:'a.jpg','b.jpg','c.jpg','d.jpg', #fff))`).not.markupToMetadataError()
			expect(`(define: $e to (image:'a.jpg','b.jpg', (gradient:90,0.1,#fff,0.9,#000)))`).not.markupToMetadataError()
		})
		it(`can be used in arrays or datamaps in (define:) calls`, () => {
			expect(`(define: $foo to (a:(image:'404.png'), (image:'410.png')))`).not.markupToMetadataError()
			expect(`(define: $bar to (dm:'bar',(image:'a.png'),'baz',(image:'b.png')))`).not.markupToMetadataError()
		})
		it(`errors if strings are identical`, () => {
			expect(`(define: $a to (image:'404.png','404.png'))`).markupToMetadataError()
			expect(`(define: $a to (image:'a.png','b.png','c.jpg','b.jpg','c.jpg','d.jpg'))`).markupToMetadataError()
		})
		it(`creates an image data value`, () => {
			runPassage(`(define: $a to (image:'404.png'), $b to (a:(image:'testImage.png')), $c to (dm:'foo', (image:'404.gif')))`)
			expect(`(print: $a is an image and $b's 1st is an image and $c's foo is an image)`).markupToPrint(`true`)
			expect(`(print: (a:$a)'s 1st is an image and (a:0,$b)'s 2nd's 1st is an image)`).markupToPrint(`true`)
		})
	})
	describe(`the (pic:) macro`, () => {
		afterEach(() => {
			clearState()
		})
		it(`accepts one image data value`, () => {
			createPassage(`(define: $a to (image:'404.png'), $b to (image:'testImage.png'))`)
			expect(`(pic:$a)`).not.markupToError()
			expect(`(pic:$b)`).not.markupToError()
		})
		it(`displays the image as an <img>`, (done) => {
			createPassage(`(define: $a to (image:'testImage.png'))`)
			loadAssets()
			let p = runPassage(`(pic:$a)`)
			setTimeout(() => {
				expect(p.find(`img[src^="blob"]`).length).toBe(1)
				done()
			},60)
		})
		it(`uses the fallback if the image can't be loaded`, (done) => {
			createPassage(`(define: $a to (image:'404.png'))`)
			loadAssets()
			let p = runPassage(`(pic:$a)`)
			setTimeout(() => {
				expect(p.find(`[data-img-fallback]`).length).toBe(1)
				done()
			},60)
		})
	})
})
